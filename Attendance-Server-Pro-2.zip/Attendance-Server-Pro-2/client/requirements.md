## Packages
recharts | Dashboard analytics charts and data visualization
framer-motion | Page transitions and smooth UI animations
date-fns | Date formatting and manipulation

## Notes
Authentication uses Replit Auth (provided by environment)
API endpoints follow /api/* pattern defined in shared/routes
Attendance marking requires specific bulk format
