import { Switch, Route, Redirect } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Layout } from "@/components/layout";
import { useAuth } from "@/hooks/use-auth";
import { useUserRole } from "@/hooks/use-role";
import { Loader2 } from "lucide-react";
import { lazy, Suspense } from "react";

import Login from "@/pages/login";

const Dashboard = lazy(() => import("@/pages/dashboard"));
const Classes = lazy(() => import("@/pages/classes"));
const Students = lazy(() => import("@/pages/students"));
const Devices = lazy(() => import("@/pages/devices"));
const Attendance = lazy(() => import("@/pages/attendance"));
const UsersPage = lazy(() => import("@/pages/users"));
const Reports = lazy(() => import("@/pages/reports"));
const AssignFingerprints = lazy(() => import("@/pages/assign-fingerprints"));
const SettingsPage = lazy(() => import("@/pages/settings"));
const Departments = lazy(() => import("@/pages/departments"));
const NotFound = lazy(() => import("@/pages/not-found"));

function PageLoader() {
  return (
    <div className="h-[50vh] w-full flex items-center justify-center">
      <Loader2 className="h-8 w-8 animate-spin text-primary" />
    </div>
  );
}

function ProtectedRoute({ component: Component, roles }: { component: React.ComponentType; roles?: string[] }) {
  const { isAuthenticated, isLoading } = useAuth();
  const { role, isLoading: roleLoading } = useUserRole();

  if (isLoading || roleLoading) {
    return (
      <div className="h-screen w-full flex items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Login />;
  }

  if (roles && !roles.includes(role)) {
    return <Redirect to="/" />;
  }

  return (
    <Layout>
      <Suspense fallback={<PageLoader />}>
        <Component />
      </Suspense>
    </Layout>
  );
}

function Router() {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="h-screen w-full flex items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <Switch>
        <Route component={Login} />
      </Switch>
    );
  }

  return (
    <Switch>
      <Route path="/" component={() => <ProtectedRoute component={Dashboard} />} />
      <Route path="/classes" component={() => <ProtectedRoute component={Classes} />} />
      <Route path="/students" component={() => <ProtectedRoute component={Students} />} />
      <Route path="/attendance" component={() => <ProtectedRoute component={Attendance} roles={["admin", "manager", "class_admin"]} />} />
      <Route path="/devices" component={() => <ProtectedRoute component={Devices} roles={["admin"]} />} />
      <Route path="/reports" component={() => <ProtectedRoute component={Reports} />} />
      <Route path="/assign-fingerprints" component={() => <ProtectedRoute component={AssignFingerprints} roles={["admin", "manager"]} />} />
      <Route path="/users" component={() => <ProtectedRoute component={UsersPage} roles={["admin"]} />} />
      <Route path="/departments" component={() => <ProtectedRoute component={Departments} />} />
      <Route path="/settings" component={() => <ProtectedRoute component={SettingsPage} roles={["admin"]} />} />
      <Route component={() => (
        <Suspense fallback={<PageLoader />}>
          <NotFound />
        </Suspense>
      )} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
