import { useQuery } from "@tanstack/react-query";
import { useAuth } from "./use-auth";

export function useUserRole() {
  const { isAuthenticated } = useAuth();

  const { data, isLoading } = useQuery<{ role: string }>({
    queryKey: ["/api/auth/role"],
    queryFn: async () => {
      const res = await fetch("/api/auth/role", { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch role");
      return res.json();
    },
    enabled: isAuthenticated,
    staleTime: 1000 * 60 * 5,
  });

  return {
    role: data?.role || "viewer",
    isLoading,
    isAdmin: data?.role === "admin",
    isManager: data?.role === "manager",
    isClassAdmin: data?.role === "class_admin",
    isViewer: data?.role === "viewer" || !data?.role,
  };
}
