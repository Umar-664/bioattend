import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";

interface AttendanceFilters {
  classId?: number;
  date?: string;
}

export function useAttendance(filters?: AttendanceFilters) {
  return useQuery({
    queryKey: [api.attendance.list.path, filters],
    queryFn: async () => {
      const url = new URL(window.location.origin + api.attendance.list.path);
      if (filters?.classId) url.searchParams.set("classId", String(filters.classId));
      if (filters?.date) url.searchParams.set("date", filters.date);

      const res = await fetch(url.toString(), { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch attendance");
      return api.attendance.list.responses[200].parse(await res.json());
    },
    enabled: !!filters?.date || !!filters?.classId,
  });
}

export function useBulkMarkAttendance() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: {
      classId: number;
      date: string;
      records: Array<{ studentId: number; status: 'present' | 'absent' | 'late' | 'excused' | 'leave' }>;
    }) => {
      const res = await fetch(api.attendance.bulkMark.path, {
        method: api.attendance.bulkMark.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to mark attendance");
      return api.attendance.bulkMark.responses[200].parse(await res.json());
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: [api.attendance.list.path] });
      toast({ title: "Success", description: `Marked attendance for ${data.count} students` });
    },
    onError: (error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });
}
