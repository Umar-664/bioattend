import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export function useUnassignedFingerprints() {
  return useQuery({
    queryKey: [api.fingerprints.unassigned.path],
  });
}

export function useAssignFingerprint() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: { scannedFingerprintId: number; studentId: number }) => {
      const res = await apiRequest("POST", api.fingerprints.assign.path, data);
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: [api.fingerprints.unassigned.path] });
      queryClient.invalidateQueries({ queryKey: [api.students.list.path] });
      toast({ title: "Fingerprint Assigned", description: data.message });
    },
    onError: (error) => {
      toast({ title: "Assignment Failed", description: error.message, variant: "destructive" });
    },
  });
}

export function useDismissFingerprint() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/fingerprints/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.fingerprints.unassigned.path] });
      toast({ title: "Fingerprint Dismissed", description: "The scanned fingerprint has been removed" });
    },
    onError: (error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });
}
