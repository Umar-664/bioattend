import { useState } from "react";
import { useClasses } from "@/hooks/use-classes";
import { useStudents } from "@/hooks/use-students";
import { useAttendance, useBulkMarkAttendance } from "@/hooks/use-attendance";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";
import { CheckCircle2, XCircle, Clock, Save, CalendarCheck, Search } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const STATUS_OPTIONS = [
  { value: 'present', label: 'Present', bg: 'bg-green-50 dark:bg-green-950/40', border: 'border-green-100 dark:border-green-900', text: 'text-green-700 dark:text-green-400', radio: 'text-green-600 border-green-600' },
  { value: 'absent', label: 'Absent', bg: 'bg-red-50 dark:bg-red-950/40', border: 'border-red-100 dark:border-red-900', text: 'text-red-700 dark:text-red-400', radio: 'text-red-600 border-red-600' },
  { value: 'late', label: 'Late', bg: 'bg-orange-50 dark:bg-orange-950/40', border: 'border-orange-100 dark:border-orange-900', text: 'text-orange-700 dark:text-orange-400', radio: 'text-orange-600 border-orange-600' },
  { value: 'leave', label: 'Leave', bg: 'bg-purple-50 dark:bg-purple-950/40', border: 'border-purple-100 dark:border-purple-900', text: 'text-purple-700 dark:text-purple-400', radio: 'text-purple-600 border-purple-600' },
  { value: 'excused', label: 'Excused', bg: 'bg-blue-50 dark:bg-blue-950/40', border: 'border-blue-100 dark:border-blue-900', text: 'text-blue-700 dark:text-blue-400', radio: 'text-blue-600 border-blue-600' },
] as const;

type AttendanceStatus = 'present' | 'absent' | 'late' | 'excused' | 'leave';

function getStatusBadge(status: string) {
  const map: Record<string, string> = {
    present: 'bg-green-100 text-green-800 dark:bg-green-950/40 dark:text-green-400',
    absent: 'bg-red-100 text-red-800 dark:bg-red-950/40 dark:text-red-400',
    late: 'bg-orange-100 text-orange-800 dark:bg-orange-950/40 dark:text-orange-400',
    leave: 'bg-purple-100 text-purple-800 dark:bg-purple-950/40 dark:text-purple-400',
    excused: 'bg-blue-100 text-blue-800 dark:bg-blue-950/40 dark:text-blue-400',
  };
  return map[status] || 'bg-muted text-muted-foreground';
}

export default function Attendance() {
  const [date, setDate] = useState<string>(format(new Date(), "yyyy-MM-dd"));
  const [selectedClass, setSelectedClass] = useState<string>("");
  
  const { data: classes } = useClasses();
  const { data: students } = useStudents({ 
    classId: selectedClass ? Number(selectedClass) : undefined 
  });
  
  const bulkMark = useBulkMarkAttendance();
  
  const [records, setRecords] = useState<Record<number, AttendanceStatus>>({});

  const handleStatusChange = (studentId: number, status: AttendanceStatus) => {
    setRecords(prev => ({ ...prev, [studentId]: status }));
  };

  const handleSubmit = () => {
    if (!selectedClass) return;
    
    const submissionData = Object.entries(records).map(([studentId, status]) => ({
      studentId: Number(studentId),
      status,
    }));

    if (submissionData.length === 0) {
      alert("Please mark attendance for at least one student");
      return;
    }

    bulkMark.mutate({
      classId: Number(selectedClass),
      date,
      records: submissionData,
    });
  };

  const markAllPresent = () => {
    if (!students) return;
    const newRecords: typeof records = {};
    students.forEach(s => {
      newRecords[s.id] = 'present';
    });
    setRecords(newRecords);
  };

  return (
    <div className="space-y-4 sm:space-y-6">
      <div>
        <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold tracking-tight text-foreground">Attendance</h1>
        <p className="text-muted-foreground mt-2">Mark and view daily attendance records</p>
      </div>

      <Tabs defaultValue="mark" className="space-y-4 sm:space-y-6">
        <TabsList>
          <TabsTrigger value="mark" data-testid="tab-mark-attendance">Mark Attendance</TabsTrigger>
          <TabsTrigger value="history" data-testid="tab-view-history">View History</TabsTrigger>
        </TabsList>

        <TabsContent value="mark" className="space-y-4 sm:space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Attendance Register</CardTitle>
              <CardDescription>Select a class and date to mark attendance.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-6 mb-8">
                <div className="space-y-2">
                  <Label>Date</Label>
                  <Input 
                    type="date" 
                    value={date} 
                    onChange={(e) => setDate(e.target.value)}
                    data-testid="input-attendance-date"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Class</Label>
                  <Select value={selectedClass} onValueChange={setSelectedClass}>
                    <SelectTrigger data-testid="select-attendance-class">
                      <SelectValue placeholder="Select Class" />
                    </SelectTrigger>
                    <SelectContent>
                      {classes?.map((c) => (
                        <SelectItem key={c.id} value={String(c.id)}>
                          {c.name} ({c.scheduleType})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-end">
                  <Button 
                    variant="outline" 
                    className="w-full" 
                    onClick={markAllPresent}
                    disabled={!selectedClass || !students?.length}
                    data-testid="button-mark-all-present"
                  >
                    Mark All Present
                  </Button>
                </div>
              </div>

              {!selectedClass ? (
                <div className="text-center py-12 border-2 border-dashed border-border rounded-xl bg-muted/50">
                  <CalendarCheck className="h-12 w-12 text-muted-foreground/50 mx-auto mb-4" />
                  <p className="text-muted-foreground font-medium">Please select a class to begin</p>
                </div>
              ) : !students?.length ? (
                <div className="text-center py-12">
                  <p className="text-muted-foreground">No students found in this class.</p>
                </div>
              ) : (
                <div className="space-y-6">
                  <div className="border border-border rounded-xl overflow-hidden">
                    {students.map((student) => (
                      <div 
                        key={student.id} 
                        className="flex flex-col sm:flex-row sm:items-center justify-between p-4 border-b border-border last:border-0"
                        data-testid={`row-attendance-${student.id}`}
                      >
                        <div className="mb-4 sm:mb-0">
                          <p className="font-semibold text-foreground">{student.name}</p>
                          <p className="text-sm text-muted-foreground font-mono">{student.rollNumber}</p>
                        </div>
                        
                        <RadioGroup 
                          value={records[student.id]} 
                          onValueChange={(val) => handleStatusChange(student.id, val as AttendanceStatus)}
                          className="flex flex-wrap gap-2"
                        >
                          {STATUS_OPTIONS.map(opt => (
                            <div key={opt.value} className={`flex items-center space-x-2 ${opt.bg} px-3 py-2 rounded-md border ${opt.border} cursor-pointer`}>
                              <RadioGroupItem value={opt.value} id={`${opt.value}-${student.id}`} className={opt.radio} />
                              <Label htmlFor={`${opt.value}-${student.id}`} className={`${opt.text} cursor-pointer font-medium text-sm`}>{opt.label}</Label>
                            </div>
                          ))}
                        </RadioGroup>
                      </div>
                    ))}
                  </div>
                  
                  <div className="flex justify-end pt-4">
                    <Button 
                      onClick={handleSubmit} 
                      disabled={bulkMark.isPending}
                      className="w-full sm:w-auto"
                      data-testid="button-save-attendance"
                    >
                      <Save className="mr-2 h-4 w-4" />
                      {bulkMark.isPending ? "Saving..." : "Save Attendance"}
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history">
          <AttendanceHistory />
        </TabsContent>
      </Tabs>
    </div>
  );
}

function AttendanceHistory() {
  const [historyDate, setHistoryDate] = useState<string>(format(new Date(), "yyyy-MM-dd"));
  const [historyClass, setHistoryClass] = useState<string>("");
  const { data: classes } = useClasses();

  const { data: historyRecords, isLoading } = useAttendance({
    classId: historyClass && historyClass !== "all" ? Number(historyClass) : undefined,
    date: historyDate || undefined,
  });

  return (
    <Card>
      <CardHeader>
        <CardTitle>Attendance History</CardTitle>
        <CardDescription>View past attendance records by class and date.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Date</Label>
            <Input
              type="date"
              value={historyDate}
              onChange={(e) => setHistoryDate(e.target.value)}
              data-testid="input-history-date"
            />
          </div>
          <div className="space-y-2">
            <Label>Class (optional)</Label>
            <Select value={historyClass} onValueChange={setHistoryClass}>
              <SelectTrigger data-testid="select-history-class">
                <SelectValue placeholder="All Classes" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Classes</SelectItem>
                {classes?.map((c) => (
                  <SelectItem key={c.id} value={String(c.id)}>
                    {c.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {!historyDate ? (
          <div className="text-center py-12 border-2 border-dashed border-border rounded-xl bg-muted/50">
            <Search className="h-12 w-12 text-muted-foreground/50 mx-auto mb-4" />
            <p className="text-muted-foreground font-medium">Select a date to view records</p>
          </div>
        ) : isLoading ? (
          <div className="space-y-2">
            {[1, 2, 3].map(i => <div key={i} className="h-12 bg-muted rounded-md animate-pulse" />)}
          </div>
        ) : !historyRecords?.length ? (
          <div className="text-center py-12 border-2 border-dashed border-border rounded-xl bg-muted/50">
            <CalendarCheck className="h-12 w-12 text-muted-foreground/50 mx-auto mb-4" />
            <p className="text-muted-foreground font-medium">No attendance records found for this date</p>
          </div>
        ) : (
          <>
            <div className="flex flex-wrap gap-3 mb-2">
              {['present', 'absent', 'late', 'leave', 'excused'].map(status => {
                const count = historyRecords.filter((r: any) => r.status === status).length;
                if (count === 0) return null;
                return (
                  <span key={status} className={`inline-flex items-center px-2.5 py-1 rounded-md text-xs font-medium ${getStatusBadge(status)}`}>
                    {status.charAt(0).toUpperCase() + status.slice(1)}: {count}
                  </span>
                );
              })}
              <span className="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-medium bg-muted text-muted-foreground">
                Total: {historyRecords.length}
              </span>
            </div>

            <div className="hidden md:block">
              <div className="border border-border rounded-md overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="font-semibold">Student</TableHead>
                      <TableHead className="font-semibold">Roll No.</TableHead>
                      <TableHead className="font-semibold">Status</TableHead>
                      <TableHead className="font-semibold">Time</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {historyRecords.map((record: any) => (
                      <TableRow key={record.id} data-testid={`row-history-${record.id}`}>
                        <TableCell className="font-medium">{record.student?.name || 'Unknown'}</TableCell>
                        <TableCell className="font-mono text-muted-foreground text-sm">{record.student?.rollNumber || '-'}</TableCell>
                        <TableCell>
                          <span className={`inline-flex items-center px-2 py-0.5 rounded-md text-xs font-medium ${getStatusBadge(record.status)}`}>
                            {record.status.charAt(0).toUpperCase() + record.status.slice(1)}
                          </span>
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground">
                          {record.date ? format(new Date(record.date), "hh:mm a") : '-'}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>

            <div className="md:hidden space-y-2">
              {historyRecords.map((record: any) => (
                <Card key={record.id} className="p-3" data-testid={`card-history-${record.id}`}>
                  <div className="flex items-center justify-between gap-2">
                    <div className="min-w-0">
                      <p className="font-medium text-foreground text-sm truncate">{record.student?.name || 'Unknown'}</p>
                      <p className="text-xs text-muted-foreground font-mono">{record.student?.rollNumber || '-'}</p>
                    </div>
                    <span className={`inline-flex items-center px-2 py-0.5 rounded-md text-xs font-medium flex-shrink-0 ${getStatusBadge(record.status)}`}>
                      {record.status.charAt(0).toUpperCase() + record.status.slice(1)}
                    </span>
                  </div>
                </Card>
              ))}
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}
