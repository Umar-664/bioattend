import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useClasses } from "@/hooks/use-classes";
import { useStudents } from "@/hooks/use-students";
import { useDevices } from "@/hooks/use-devices";
import { useUserRole } from "@/hooks/use-role";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Users, BookOpen, Server, CheckCircle2, Clock, XCircle, AlertTriangle, Activity } from "lucide-react";
import { format, formatDistanceToNow } from "date-fns";
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";

interface DashboardStats {
  dailyTrends: { date: string; present: number; absent: number; late: number; excused: number; leave: number }[];
  classSummary: { classId: number; className: string; present: number; absent: number; late: number; total: number }[];
  statusBreakdown: { status: string; count: number }[];
  recentActivity: { id: number; studentName: string; status: string; className: string | null; date: string | null; deviceId: number | null }[];
}

const STATUS_COLORS: Record<string, string> = {
  present: "#22c55e",
  absent: "#ef4444",
  late: "#f59e0b",
  leave: "#a855f7",
  excused: "#6366f1",
};

const STATUS_ICONS: Record<string, typeof CheckCircle2> = {
  present: CheckCircle2,
  absent: XCircle,
  late: Clock,
  leave: AlertTriangle,
  excused: AlertTriangle,
};

function useDashboardStats(days: number) {
  return useQuery<DashboardStats>({
    queryKey: ["/api/dashboard/stats", days],
    queryFn: async () => {
      const res = await fetch(`/api/dashboard/stats?days=${days}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch dashboard stats");
      return res.json();
    },
  });
}

export default function Dashboard() {
  const [days, setDays] = useState(30);
  const { data: students } = useStudents();
  const { data: classes } = useClasses();
  const { isAdmin } = useUserRole();
  const { data: devices } = useDevices(isAdmin);
  const { data: stats, isLoading: statsLoading } = useDashboardStats(days);

  const totalRecords = stats?.statusBreakdown.reduce((sum, s) => sum + s.count, 0) || 0;

  const overallStats = [
    {
      title: "Total Students",
      value: students?.length || 0,
      icon: Users,
      color: "text-blue-600",
      bg: "bg-blue-50 dark:bg-blue-950/40",
    },
    {
      title: "Active Classes",
      value: classes?.length || 0,
      icon: BookOpen,
      color: "text-purple-600",
      bg: "bg-purple-50 dark:bg-purple-950/40",
    },
    ...(isAdmin ? [{
      title: "Online Devices",
      value: devices?.filter((d: any) => d.connectionStatus === "online").length || 0,
      icon: Server,
      color: "text-emerald-600",
      bg: "bg-emerald-50 dark:bg-emerald-950/40",
    }] : []),
    {
      title: "Attendance Rate",
      value: totalRecords > 0
        ? `${Math.round(((stats?.statusBreakdown.find(s => s.status === "present")?.count || 0) + (stats?.statusBreakdown.find(s => s.status === "late")?.count || 0)) / totalRecords * 100)}%`
        : "N/A",
      icon: CheckCircle2,
      color: "text-orange-600",
      bg: "bg-orange-50 dark:bg-orange-950/40",
    },
  ];

  const pieData = stats?.statusBreakdown.map(s => ({
    name: s.status.charAt(0).toUpperCase() + s.status.slice(1),
    value: s.count,
    color: STATUS_COLORS[s.status] || "#94a3b8",
  })) || [];

  const trendData = stats?.dailyTrends.map(d => ({
    ...d,
    date: format(new Date(d.date), "MMM dd"),
    total: d.present + d.absent + d.late + d.excused + (d.leave || 0),
  })) || [];

  const classData = stats?.classSummary.map(c => ({
    ...c,
    rate: c.total > 0 ? Math.round((c.present + c.late) / c.total * 100) : 0,
  })) || [];

  return (
    <div className="space-y-4 sm:space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold tracking-tight text-foreground" data-testid="text-dashboard-title">Dashboard</h1>
          <p className="text-muted-foreground text-sm mt-1">Attendance analytics and trends</p>
        </div>
        <Select value={String(days)} onValueChange={(v) => setDays(Number(v))}>
          <SelectTrigger className="w-full sm:w-[160px]" data-testid="select-days-range">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="7">Last 7 days</SelectItem>
            <SelectItem value="14">Last 14 days</SelectItem>
            <SelectItem value="30">Last 30 days</SelectItem>
            <SelectItem value="90">Last 90 days</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="grid gap-3 grid-cols-2 lg:grid-cols-4">
        {overallStats.map((stat) => (
          <Card key={stat.title}>
            <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
              <CardTitle className="text-xs sm:text-sm font-medium text-muted-foreground">
                {stat.title}
              </CardTitle>
              <div className={`p-1.5 sm:p-2 rounded-md ${stat.bg}`}>
                <stat.icon className={`h-3.5 w-3.5 sm:h-4 sm:w-4 ${stat.color}`} />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-lg sm:text-2xl font-bold text-foreground" data-testid={`stat-${stat.title.toLowerCase().replace(/\s+/g, '-')}`}>
                {stat.value}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {statsLoading ? (
        <div className="grid gap-4 lg:grid-cols-7">
          <div className="lg:col-span-5 h-[300px] sm:h-[350px] bg-muted rounded-md animate-pulse" />
          <div className="lg:col-span-2 h-[300px] sm:h-[350px] bg-muted rounded-md animate-pulse" />
        </div>
      ) : (
        <>
          <div className="grid gap-4 lg:grid-cols-7">
            <Card className="lg:col-span-5">
              <CardHeader>
                <CardTitle className="text-sm sm:text-base">Daily Attendance Trends</CardTitle>
              </CardHeader>
              <CardContent className="px-2 sm:px-6">
                {trendData.length > 0 ? (
                  <div className="h-[250px] sm:h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={trendData}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                        <XAxis
                          dataKey="date"
                          stroke="hsl(var(--muted-foreground))"
                          fontSize={10}
                          tickLine={false}
                          axisLine={false}
                        />
                        <YAxis
                          stroke="hsl(var(--muted-foreground))"
                          fontSize={10}
                          tickLine={false}
                          axisLine={false}
                          allowDecimals={false}
                          width={30}
                        />
                        <Tooltip
                          contentStyle={{ borderRadius: '8px', border: '1px solid hsl(var(--border))', background: 'hsl(var(--card))', color: 'hsl(var(--card-foreground))', fontSize: 12 }}
                        />
                        <Legend iconSize={8} wrapperStyle={{ fontSize: 11 }} />
                        <Line type="monotone" dataKey="present" stroke="#22c55e" strokeWidth={2} dot={{ r: 2 }} name="Present" />
                        <Line type="monotone" dataKey="absent" stroke="#ef4444" strokeWidth={2} dot={{ r: 2 }} name="Absent" />
                        <Line type="monotone" dataKey="late" stroke="#f59e0b" strokeWidth={2} dot={{ r: 2 }} name="Late" />
                        <Line type="monotone" dataKey="leave" stroke="#a855f7" strokeWidth={2} dot={{ r: 2 }} name="Leave" />
                        <Line type="monotone" dataKey="excused" stroke="#6366f1" strokeWidth={2} dot={{ r: 2 }} name="Excused" />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                ) : (
                  <div className="h-[250px] sm:h-[300px] flex items-center justify-center text-muted-foreground text-sm">
                    No attendance data for this period
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle className="text-sm sm:text-base">Status Breakdown</CardTitle>
              </CardHeader>
              <CardContent>
                {pieData.length > 0 ? (
                  <div className="space-y-4">
                    <div className="h-[160px] sm:h-[180px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={pieData}
                            cx="50%"
                            cy="50%"
                            innerRadius={40}
                            outerRadius={65}
                            paddingAngle={3}
                            dataKey="value"
                          >
                            {pieData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={entry.color} />
                            ))}
                          </Pie>
                          <Tooltip
                            contentStyle={{ borderRadius: '8px', border: '1px solid hsl(var(--border))', background: 'hsl(var(--card))', color: 'hsl(var(--card-foreground))', fontSize: 12 }}
                            formatter={(value: number) => [`${value} records`, '']}
                          />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                    <div className="space-y-2">
                      {pieData.map((item) => (
                        <div key={item.name} className="flex items-center justify-between gap-2 text-sm">
                          <div className="flex items-center gap-2">
                            <div className="h-3 w-3 rounded-full flex-shrink-0" style={{ backgroundColor: item.color }} />
                            <span className="text-muted-foreground">{item.name}</span>
                          </div>
                          <span className="font-medium text-foreground">{item.value}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="h-[180px] flex items-center justify-center text-muted-foreground text-sm">
                    No data
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-4 lg:grid-cols-7">
            <Card className="lg:col-span-4">
              <CardHeader>
                <CardTitle className="text-sm sm:text-base">Attendance by Class</CardTitle>
              </CardHeader>
              <CardContent className="px-2 sm:px-6">
                {classData.length > 0 ? (
                  <div className="h-[250px] sm:h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={classData} layout="vertical" margin={{ left: 10 }}>
                        <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="hsl(var(--border))" />
                        <XAxis type="number" stroke="hsl(var(--muted-foreground))" fontSize={10} tickLine={false} axisLine={false} allowDecimals={false} />
                        <YAxis
                          type="category"
                          dataKey="className"
                          stroke="hsl(var(--muted-foreground))"
                          fontSize={10}
                          tickLine={false}
                          axisLine={false}
                          width={80}
                        />
                        <Tooltip
                          contentStyle={{ borderRadius: '8px', border: '1px solid hsl(var(--border))', background: 'hsl(var(--card))', color: 'hsl(var(--card-foreground))', fontSize: 12 }}
                        />
                        <Legend iconSize={8} wrapperStyle={{ fontSize: 11 }} />
                        <Bar dataKey="present" fill="#22c55e" stackId="a" name="Present" radius={[0, 0, 0, 0]} />
                        <Bar dataKey="late" fill="#f59e0b" stackId="a" name="Late" />
                        <Bar dataKey="absent" fill="#ef4444" stackId="a" name="Absent" radius={[0, 4, 4, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                ) : (
                  <div className="h-[250px] sm:h-[300px] flex items-center justify-center text-muted-foreground text-sm">
                    No class data for this period
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className="lg:col-span-3">
              <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0">
                <CardTitle className="text-sm sm:text-base">Recent Activity</CardTitle>
                <Activity className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                {stats?.recentActivity && stats.recentActivity.length > 0 ? (
                  <div className="space-y-3 max-h-[280px] overflow-y-auto pr-1">
                    {stats.recentActivity.slice(0, 10).map((item) => {
                      const StatusIcon = STATUS_ICONS[item.status] || CheckCircle2;
                      const statusColor = STATUS_COLORS[item.status] || "#94a3b8";
                      return (
                        <div key={item.id} className="flex items-start gap-3" data-testid={`activity-${item.id}`}>
                          <div className="mt-0.5 flex-shrink-0">
                            <StatusIcon className="h-4 w-4" style={{ color: statusColor }} />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-foreground truncate">
                              {item.studentName}
                            </p>
                            <div className="flex flex-wrap items-center gap-1 mt-0.5">
                              <Badge
                                variant="secondary"
                                className="text-[10px] px-1.5 py-0"
                                style={{ backgroundColor: `${statusColor}15`, color: statusColor }}
                              >
                                {item.status}
                              </Badge>
                              {item.className && (
                                <span className="text-[11px] text-muted-foreground">{item.className}</span>
                              )}
                            </div>
                          </div>
                          <span className="text-[11px] text-muted-foreground whitespace-nowrap flex-shrink-0">
                            {item.date
                              ? formatDistanceToNow(new Date(item.date), { addSuffix: true })
                              : ""}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="h-[200px] flex items-center justify-center text-muted-foreground text-sm">
                    No recent activity
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </>
      )}
    </div>
  );
}
