import { useState } from "react";
import { useDevices, useCreateDevice, useUpdateDevice, useDeleteDevice, useTestDeviceConnection } from "@/hooks/use-devices";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Server, Plus, Trash2, Pencil, Key, Wifi, WifiOff, Activity, Zap, Loader2, Fingerprint, CalendarCheck, Circle, Building2 } from "lucide-react";
import { useDepartments } from "@/hooks/use-departments";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertDeviceSchema, type InsertDevice, type Device } from "@shared/schema";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { formatDistanceToNow } from "date-fns";
import { nanoid } from "nanoid";

export default function Devices() {
  const { data: devices, isLoading } = useDevices();
  const { data: allDepartments } = useDepartments();
  const deleteDevice = useDeleteDevice();
  const testConnection = useTestDeviceConnection();
  const updateDevice = useUpdateDevice();
  const [createOpen, setCreateOpen] = useState(false);
  const [editDevice, setEditDevice] = useState<Device | null>(null);
  const [revealedKeys, setRevealedKeys] = useState<Record<number, boolean>>({});

  const toggleKey = (id: number) => {
    setRevealedKeys(prev => ({ ...prev, [id]: !prev[id] }));
  };

  return (
    <div className="space-y-4 sm:space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold tracking-tight text-foreground" data-testid="text-devices-title">Devices</h1>
          <p className="text-muted-foreground mt-2">Manage ESP32 biometric scanners</p>
        </div>
        <Dialog open={createOpen} onOpenChange={setCreateOpen}>
          <DialogTrigger asChild>
            <Button className="w-full sm:w-auto" data-testid="button-add-device">
              <Plus className="mr-2 h-4 w-4" /> Add Device
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Register New Device</DialogTitle>
            </DialogHeader>
            <CreateDeviceForm onSuccess={() => setCreateOpen(false)} />
          </DialogContent>
        </Dialog>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-64 bg-muted rounded-xl animate-pulse" />
          ))}
        </div>
      ) : devices?.length === 0 ? (
        <Card className="p-8 text-center">
          <CardContent className="pt-2">
            <div className="bg-muted p-4 rounded-full w-fit mx-auto mb-4">
              <Server className="h-10 w-10 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-semibold text-foreground" data-testid="text-no-devices">No devices registered</h3>
            <p className="text-muted-foreground text-sm mt-1 max-w-md mx-auto">
              Register your first ESP32 fingerprint scanner to start collecting biometric attendance.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
          {devices?.map((device) => (
            <Card key={device.id} data-testid={`card-device-${device.id}`}>
              <CardHeader className="flex flex-row items-start justify-between gap-2 space-y-0 pb-2">
                <div>
                  <CardTitle className="text-lg font-bold text-foreground flex items-center gap-2">
                    <Server className="h-4 w-4 text-primary" />
                    {device.name}
                  </CardTitle>
                  <CardDescription className="mt-1">{device.location || "Unknown Location"}</CardDescription>
                  {device.departmentId && (
                    <div className="flex items-center gap-1.5 text-xs text-muted-foreground mt-1" data-testid={`text-device-department-${device.id}`}>
                      <Building2 className="h-3 w-3 flex-shrink-0" />
                      <span>{allDepartments?.find(d => d.id === device.departmentId)?.name || "Unknown"}</span>
                    </div>
                  )}
                </div>
                <div className="flex flex-wrap gap-1">
                  <Badge variant={device.isActive ? "default" : "secondary"} className={device.isActive ? "bg-emerald-500" : ""}>
                    {device.isActive ? "Active" : "Inactive"}
                  </Badge>
                  <Badge variant="outline" className={device.mode === "enroll" ? "border-amber-500 text-amber-600 dark:text-amber-400" : ""} data-testid={`badge-mode-${device.id}`}>
                    {device.mode === "enroll" ? "Enroll Mode" : "Attendance Mode"}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="pt-4 space-y-4">
                <div className="space-y-2">
                  <div className="text-xs font-medium text-muted-foreground uppercase tracking-wider">API Key</div>
                  <div className="flex items-center gap-2 bg-muted p-2 rounded-md border border-border">
                    <Key className="h-4 w-4 text-muted-foreground" />
                    <code className="flex-1 text-xs font-mono text-foreground break-all">
                      {revealedKeys[device.id] ? device.apiKey : "••••••••••••••••••••••••"}
                    </code>
                    <Button variant="ghost" size="sm" className="h-6 text-xs" data-testid={`button-toggle-key-${device.id}`} onClick={() => toggleKey(device.id)}>
                      {revealedKeys[device.id] ? "Hide" : "Show"}
                    </Button>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Mode</div>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant={device.mode === "attendance" ? "default" : "outline"}
                      className="flex-1"
                      data-testid={`button-mode-attendance-${device.id}`}
                      disabled={updateDevice.isPending}
                      onClick={() => {
                        if (device.mode !== "attendance") {
                          updateDevice.mutate({ id: device.id, data: { mode: "attendance" } });
                        }
                      }}
                    >
                      <CalendarCheck className="h-4 w-4 mr-1" />
                      Attendance
                    </Button>
                    <Button
                      size="sm"
                      variant={device.mode === "enroll" ? "default" : "outline"}
                      className={device.mode === "enroll" ? "flex-1 bg-amber-600" : "flex-1"}
                      data-testid={`button-mode-enroll-${device.id}`}
                      disabled={updateDevice.isPending}
                      onClick={() => {
                        if (device.mode !== "enroll") {
                          updateDevice.mutate({ id: device.id, data: { mode: "enroll" } });
                        }
                      }}
                    >
                      <Fingerprint className="h-4 w-4 mr-1" />
                      Enroll
                    </Button>
                  </div>
                </div>

                <div className="space-y-2 pt-2">
                  <div className="flex items-center gap-2 text-sm" data-testid={`status-connection-${device.id}`}>
                    {(device as any).connectionStatus === "online" ? (
                      <>
                        <Circle className="h-3 w-3 fill-emerald-500 text-emerald-500" />
                        <span className="text-emerald-600 dark:text-emerald-400 text-xs font-medium">Online</span>
                      </>
                    ) : (device as any).connectionStatus === "offline" ? (
                      <>
                        <Circle className="h-3 w-3 fill-red-500 text-red-500" />
                        <span className="text-red-600 dark:text-red-400 text-xs font-medium">Offline</span>
                      </>
                    ) : (
                      <>
                        <Circle className="h-3 w-3 fill-muted-foreground text-muted-foreground" />
                        <span className="text-muted-foreground text-xs font-medium">Never Connected</span>
                      </>
                    )}
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Activity className="h-4 w-4" />
                    <span className="text-xs">
                      Last seen: {device.lastSeen 
                        ? formatDistanceToNow(new Date(device.lastSeen), { addSuffix: true }) 
                        : "Never"}
                    </span>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="bg-muted/50 p-4 border-t border-border flex flex-wrap justify-end gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  data-testid={`button-test-device-${device.id}`}
                  disabled={testConnection.isPending}
                  onClick={() => testConnection.mutate(device.apiKey)}
                >
                  {testConnection.isPending ? (
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <Zap className="h-4 w-4 mr-2" />
                  )}
                  Test Connection
                </Button>
                <Button 
                  variant="ghost" 
                  size="sm"
                  data-testid={`button-edit-device-${device.id}`}
                  onClick={() => setEditDevice(device)}
                >
                  <Pencil className="h-4 w-4 mr-2" /> Edit
                </Button>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="text-destructive"
                  data-testid={`button-delete-device-${device.id}`}
                  onClick={() => {
                    if (confirm('Delete this device? This will revoke its API access.')) {
                      deleteDevice.mutate(device.id);
                    }
                  }}
                >
                  <Trash2 className="h-4 w-4 mr-2" /> Delete
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={!!editDevice} onOpenChange={(open) => { if (!open) setEditDevice(null); }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Device</DialogTitle>
          </DialogHeader>
          {editDevice && (
            <EditDeviceForm
              key={editDevice.id}
              device={editDevice}
              onSuccess={() => setEditDevice(null)}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function CreateDeviceForm({ onSuccess }: { onSuccess: () => void }) {
  const createDevice = useCreateDevice();
  const { data: departments } = useDepartments();
  const form = useForm<InsertDevice>({
    resolver: zodResolver(insertDeviceSchema),
    defaultValues: {
      name: "",
      location: "",
      apiKey: nanoid(32),
      isActive: true,
      departmentId: null,
    },
  });

  function onSubmit(data: InsertDevice) {
    createDevice.mutate({ ...data, departmentId: data.departmentId || null }, {
      onSuccess: () => {
        form.reset();
        onSuccess();
      },
    });
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Device Name</FormLabel>
              <FormControl>
                <Input data-testid="input-device-name" placeholder="Main Entrance Scanner" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="location"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Location</FormLabel>
              <FormControl>
                <Input data-testid="input-device-location" placeholder="Building A, Room 101" {...field} value={field.value || ''} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="departmentId"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Department</FormLabel>
              <Select
                onValueChange={(val) => field.onChange(val ? Number(val) : null)}
                value={field.value ? String(field.value) : undefined}
              >
                <FormControl>
                  <SelectTrigger data-testid="select-device-department">
                    <SelectValue placeholder="Select Department" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {departments?.map((d) => (
                    <SelectItem key={d.id} value={String(d.id)}>{d.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="apiKey"
          render={({ field }) => (
            <FormItem>
              <FormLabel>API Key (Auto-generated)</FormLabel>
              <FormControl>
                <Input {...field} readOnly className="bg-muted font-mono text-xs" data-testid="input-device-apikey" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <Button 
          type="submit" 
          className="w-full" 
          disabled={createDevice.isPending}
          data-testid="button-submit-device"
        >
          {createDevice.isPending ? "Registering..." : "Register Device"}
        </Button>
      </form>
    </Form>
  );
}

function EditDeviceForm({ device, onSuccess }: { device: Device; onSuccess: () => void }) {
  const updateDevice = useUpdateDevice();
  const { data: departments } = useDepartments();
  const form = useForm({
    resolver: zodResolver(insertDeviceSchema.partial()),
    defaultValues: {
      name: device.name,
      location: device.location || "",
      isActive: device.isActive ?? true,
      mode: device.mode || "attendance",
      departmentId: device.departmentId || null,
    },
  });

  function onSubmit(data: Partial<InsertDevice>) {
    updateDevice.mutate(
      { id: device.id, data: { ...data, departmentId: data.departmentId || null } },
      {
        onSuccess: () => {
          onSuccess();
        },
      }
    );
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Device Name</FormLabel>
              <FormControl>
                <Input data-testid="input-edit-device-name" placeholder="Main Entrance Scanner" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="location"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Location</FormLabel>
              <FormControl>
                <Input data-testid="input-edit-device-location" placeholder="Building A, Room 101" {...field} value={field.value || ''} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="departmentId"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Department</FormLabel>
              <Select
                onValueChange={(val) => field.onChange(val ? Number(val) : null)}
                value={field.value ? String(field.value) : undefined}
              >
                <FormControl>
                  <SelectTrigger data-testid="select-edit-device-department">
                    <SelectValue placeholder="Select Department" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {departments?.map((d) => (
                    <SelectItem key={d.id} value={String(d.id)}>{d.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="mode"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Device Mode</FormLabel>
              <Select onValueChange={field.onChange} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger data-testid="select-edit-device-mode">
                    <SelectValue placeholder="Select mode" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  <SelectItem value="attendance">Attendance Mode</SelectItem>
                  <SelectItem value="enroll">Enroll / Scan Fingerprints</SelectItem>
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="isActive"
          render={({ field }) => (
            <FormItem className="flex items-center justify-between rounded-md border p-3">
              <FormLabel className="cursor-pointer">Active Status</FormLabel>
              <FormControl>
                <Switch
                  data-testid="switch-edit-device-active"
                  checked={field.value}
                  onCheckedChange={field.onChange}
                />
              </FormControl>
            </FormItem>
          )}
        />

        <Button
          type="submit"
          className="w-full"
          disabled={updateDevice.isPending}
          data-testid="button-submit-edit-device"
        >
          {updateDevice.isPending ? "Saving..." : "Save Changes"}
        </Button>
      </form>
    </Form>
  );
}
