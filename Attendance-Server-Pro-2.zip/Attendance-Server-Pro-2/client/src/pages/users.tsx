import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useUsers, useUpdateUserRole, useDeleteUserRole, useDeleteUser, useInviteUser, useInvitations, useDeleteInvitation } from "@/hooks/use-users";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, Mail, Clock, Pencil, Trash2, Shield, ShieldCheck, Eye, UserCheck } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { format } from "date-fns";

const inviteFormSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  role: z.enum(["admin", "manager", "class_admin", "viewer"]),
});

type InviteFormValues = z.infer<typeof inviteFormSchema>;

function roleBadge(role: string) {
  const variant = role === "admin" ? "default" : role === "manager" ? "secondary" : "outline";
  const label = role === "class_admin" ? "Class Admin" : role;
  return <Badge variant={variant} className="capitalize">{label}</Badge>;
}

const roleConfig: Record<string, { label: string; icon: any; description: string; color: string; borderColor: string; bgColor: string }> = {
  admin: {
    label: "Admins",
    icon: ShieldCheck,
    description: "Full access to all features and settings",
    color: "text-primary",
    borderColor: "border-primary/20",
    bgColor: "bg-primary/5",
  },
  manager: {
    label: "Managers",
    icon: Shield,
    description: "Can manage classes, students, and attendance",
    color: "text-blue-600 dark:text-blue-400",
    borderColor: "border-blue-200 dark:border-blue-900",
    bgColor: "bg-blue-50 dark:bg-blue-950/30",
  },
  class_admin: {
    label: "Class Admins",
    icon: UserCheck,
    description: "Can mark attendance, read-only for other data",
    color: "text-green-600 dark:text-green-400",
    borderColor: "border-green-200 dark:border-green-900",
    bgColor: "bg-green-50 dark:bg-green-950/30",
  },
  viewer: {
    label: "Viewers",
    icon: Eye,
    description: "Read-only access to data",
    color: "text-muted-foreground",
    borderColor: "border-border",
    bgColor: "bg-muted/30",
  },
};

function RoleSection({
  role,
  users,
  currentUserId,
  onEdit,
  onDelete,
}: {
  role: string;
  users: any[];
  currentUserId?: string;
  onEdit: (user: { id: string; role: string }) => void;
  onDelete: (id: string) => void;
}) {
  const config = roleConfig[role] || roleConfig.viewer;
  const Icon = config.icon;

  return (
    <Card className={config.borderColor} data-testid={`section-${role}`}>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Icon className={`h-5 w-5 ${config.color}`} />
            <CardTitle className="text-base">{config.label}</CardTitle>
            <Badge variant="outline" className="ml-1 text-xs">{users.length}</Badge>
          </div>
        </div>
        <p className="text-xs text-muted-foreground">{config.description}</p>
      </CardHeader>
      <CardContent className="pt-0">
        {users.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-4" data-testid={`text-empty-${role}`}>
            No {config.label.toLowerCase()} assigned
          </p>
        ) : (
          <>
            <div className="hidden md:block">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="font-semibold text-muted-foreground">User</TableHead>
                    <TableHead className="font-semibold text-muted-foreground">Email</TableHead>
                    <TableHead className="text-right font-semibold text-muted-foreground">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {users.map((user) => {
                    const isSelf = user.id === currentUserId;
                    return (
                    <TableRow key={user.id} data-testid={`row-user-${user.id}`}>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <Avatar className="h-8 w-8">
                            <AvatarFallback className="bg-muted text-muted-foreground font-bold text-xs">
                              {user.firstName?.[0]}{user.lastName?.[0]}
                            </AvatarFallback>
                          </Avatar>
                          <span className="font-medium text-foreground">
                            {user.firstName} {user.lastName}
                          </span>
                          {isSelf && <Badge variant="outline" className="text-xs">You</Badge>}
                        </div>
                      </TableCell>
                      <TableCell className="text-muted-foreground">{user.email}</TableCell>
                      <TableCell className="text-right">
                        {isSelf ? (
                          <span className="text-xs text-muted-foreground">Cannot modify own role</span>
                        ) : (
                        <div className="flex items-center justify-end gap-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            data-testid={`button-edit-user-${user.id}`}
                            onClick={() => onEdit({ id: user.id, role: user.role })}
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="text-destructive"
                            data-testid={`button-delete-user-${user.id}`}
                            onClick={() => {
                              if (confirm("Are you sure you want to permanently remove this user from the system?")) {
                                onDelete(user.id);
                              }
                            }}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                        )}
                      </TableCell>
                    </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>

            <div className="md:hidden space-y-2">
              {users.map((user) => {
                const isSelf = user.id === currentUserId;
                return (
                <div key={user.id} className="p-3 rounded-lg border border-border space-y-2" data-testid={`card-user-${user.id}`}>
                  <div className="flex items-center gap-3">
                    <Avatar className="h-9 w-9 flex-shrink-0">
                      <AvatarFallback className="bg-muted text-muted-foreground font-bold text-xs">
                        {user.firstName?.[0]}{user.lastName?.[0]}
                      </AvatarFallback>
                    </Avatar>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <p className="font-medium text-foreground text-sm truncate">{user.firstName} {user.lastName}</p>
                        {isSelf && <Badge variant="outline" className="text-[10px] px-1.5 py-0">You</Badge>}
                      </div>
                      <p className="text-xs text-muted-foreground truncate">{user.email}</p>
                    </div>
                  </div>
                  {!isSelf && (
                    <div className="flex items-center justify-end gap-1 pt-1 border-t border-border">
                      <Button
                        variant="ghost"
                        size="sm"
                        data-testid={`button-edit-user-mobile-${user.id}`}
                        onClick={() => onEdit({ id: user.id, role: user.role })}
                      >
                        <Pencil className="h-3.5 w-3.5 mr-1" /> Edit Role
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-destructive"
                        data-testid={`button-delete-user-mobile-${user.id}`}
                        onClick={() => {
                          if (confirm("Are you sure you want to permanently remove this user from the system?")) {
                            onDelete(user.id);
                          }
                        }}
                      >
                        <Trash2 className="h-3.5 w-3.5 mr-1" /> Remove
                      </Button>
                    </div>
                  )}
                </div>
                );
              })}
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}

export default function UsersPage() {
  const { data: users, isLoading } = useUsers();
  const { user: currentUser } = useAuth();
  const updateRole = useUpdateUserRole();
  const deleteRole = useDeleteUserRole();
  const deleteUser = useDeleteUser();
  const deleteInvitation = useDeleteInvitation();
  const { data: invitations } = useInvitations();
  const [inviteOpen, setInviteOpen] = useState(false);
  const [editUser, setEditUser] = useState<{ id: string; role: string } | null>(null);

  const admins = users?.filter(u => u.role === "admin") || [];
  const managers = users?.filter(u => u.role === "manager") || [];
  const classAdmins = users?.filter(u => u.role === "class_admin") || [];
  const viewers = users?.filter(u => u.role === "viewer" || !u.role) || [];

  return (
    <div className="space-y-4 md:space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold tracking-tight text-foreground" data-testid="text-users-title">User Management</h1>
          <p className="text-muted-foreground mt-2">Manage system access and user roles</p>
        </div>
        <Dialog open={inviteOpen} onOpenChange={setInviteOpen}>
          <DialogTrigger asChild>
            <Button className="w-full sm:w-auto" data-testid="button-add-user">
              <Plus className="mr-2 h-4 w-4" /> Add User
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Invite New User</DialogTitle>
            </DialogHeader>
            <InviteUserForm onSuccess={() => setInviteOpen(false)} />
          </DialogContent>
        </Dialog>
      </div>

      {isLoading ? (
        <div className="text-center py-12 text-muted-foreground">Loading users...</div>
      ) : (
        <div className="space-y-4">
          <RoleSection
            role="admin"
            users={admins}
            currentUserId={currentUser?.id}
            onEdit={setEditUser}
            onDelete={(id) => deleteUser.mutate(id)}
          />
          <RoleSection
            role="manager"
            users={managers}
            currentUserId={currentUser?.id}
            onEdit={setEditUser}
            onDelete={(id) => deleteUser.mutate(id)}
          />
          <RoleSection
            role="class_admin"
            users={classAdmins}
            currentUserId={currentUser?.id}
            onEdit={setEditUser}
            onDelete={(id) => deleteUser.mutate(id)}
          />
          <RoleSection
            role="viewer"
            users={viewers}
            currentUserId={currentUser?.id}
            onEdit={setEditUser}
            onDelete={(id) => deleteUser.mutate(id)}
          />

        </div>
      )}

      {invitations && invitations.length > 0 && (
        <div className="space-y-4">
          <h2 className="text-lg font-semibold text-foreground">Pending Invitations</h2>

          <div className="hidden md:block bg-card rounded-xl border border-border shadow-sm overflow-x-auto">
            <Table className="min-w-[500px]">
              <TableHeader className="bg-muted">
                <TableRow>
                  <TableHead className="font-semibold text-muted-foreground">Email</TableHead>
                  <TableHead className="font-semibold text-muted-foreground">Role</TableHead>
                  <TableHead className="font-semibold text-muted-foreground">Invited</TableHead>
                  <TableHead className="text-right font-semibold text-muted-foreground">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {invitations.map((inv: any) => (
                  <TableRow key={inv.id} data-testid={`row-invitation-${inv.id}`}>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Mail className="h-4 w-4 text-muted-foreground" />
                        <span className="text-foreground">{inv.email}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      {roleBadge(inv.role)}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2 text-muted-foreground text-sm">
                        <Clock className="h-3 w-3" />
                        {inv.createdAt ? format(new Date(inv.createdAt), "MMM d, yyyy") : "Unknown"}
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-destructive"
                        data-testid={`button-delete-invitation-${inv.id}`}
                        onClick={() => {
                          if (confirm("Delete this invitation?")) {
                            deleteInvitation.mutate(inv.id);
                          }
                        }}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          <div className="md:hidden space-y-3">
            {invitations.map((inv: any) => (
              <Card key={inv.id} data-testid={`card-invitation-${inv.id}`}>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <Mail className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                        <p className="text-sm font-medium text-foreground truncate">{inv.email}</p>
                      </div>
                      <div className="flex items-center gap-2 mt-1.5 text-xs text-muted-foreground">
                        <Clock className="h-3 w-3" />
                        {inv.createdAt ? format(new Date(inv.createdAt), "MMM d, yyyy") : "Unknown"}
                      </div>
                    </div>
                    {roleBadge(inv.role)}
                  </div>
                  <div className="flex items-center justify-end mt-3 pt-3 border-t border-border">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-destructive"
                      data-testid={`button-delete-invitation-mobile-${inv.id}`}
                      onClick={() => {
                        if (confirm("Delete this invitation?")) {
                          deleteInvitation.mutate(inv.id);
                        }
                      }}
                    >
                      <Trash2 className="h-4 w-4 mr-1" /> Remove
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      <Dialog open={!!editUser} onOpenChange={(open) => { if (!open) setEditUser(null); }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit User Role</DialogTitle>
          </DialogHeader>
          {editUser && (
            <EditRoleForm
              key={editUser.id}
              userId={editUser.id}
              currentRole={editUser.role}
              onSuccess={() => setEditUser(null)}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function EditRoleForm({ userId, currentRole, onSuccess }: { userId: string; currentRole: string; onSuccess: () => void }) {
  const updateRole = useUpdateUserRole();
  const [role, setRole] = useState(currentRole);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateRole.mutate(
      { id: userId, role: role as any },
      { onSuccess }
    );
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <label className="text-sm font-medium">Role</label>
        <Select value={role} onValueChange={setRole}>
          <SelectTrigger data-testid="select-edit-role">
            <SelectValue placeholder="Select role" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="viewer">Viewer</SelectItem>
            <SelectItem value="class_admin">Class Admin</SelectItem>
            <SelectItem value="manager">Manager</SelectItem>
            <SelectItem value="admin">Admin</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <Button
        type="submit"
        className="w-full"
        disabled={updateRole.isPending || role === currentRole}
        data-testid="button-submit-edit-role"
      >
        {updateRole.isPending ? "Saving..." : "Save Role"}
      </Button>
    </form>
  );
}

function InviteUserForm({ onSuccess }: { onSuccess: () => void }) {
  const inviteUser = useInviteUser();

  const form = useForm<InviteFormValues>({
    resolver: zodResolver(inviteFormSchema),
    defaultValues: {
      email: "",
      role: "viewer",
    },
  });

  function onSubmit(data: InviteFormValues) {
    inviteUser.mutate(data, {
      onSuccess: () => {
        form.reset();
        onSuccess();
      },
    });
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="email"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Email Address</FormLabel>
              <FormControl>
                <Input
                  type="email"
                  placeholder="user@example.com"
                  data-testid="input-invite-email"
                  {...field}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="role"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Role</FormLabel>
              <Select onValueChange={field.onChange} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger data-testid="select-invite-role">
                    <SelectValue placeholder="Select role" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  <SelectItem value="viewer">Viewer</SelectItem>
                  <SelectItem value="class_admin">Class Admin</SelectItem>
                  <SelectItem value="manager">Manager</SelectItem>
                  <SelectItem value="admin">Admin</SelectItem>
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        <Button
          type="submit"
          className="w-full"
          disabled={inviteUser.isPending}
          data-testid="button-submit-invite"
        >
          {inviteUser.isPending ? "Inviting..." : "Invite User"}
        </Button>
      </form>
    </Form>
  );
}
