import { useState } from "react";
import { useUnassignedFingerprints, useAssignFingerprint, useDismissFingerprint } from "@/hooks/use-fingerprints";
import { useQuery } from "@tanstack/react-query";
import { api } from "@shared/routes";
import type { Student } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Fingerprint, UserPlus, Trash2, Loader2, Server, Clock, AlertCircle } from "lucide-react";
import { format } from "date-fns";

export default function AssignFingerprints() {
  const { data: fingerprints, isLoading } = useUnassignedFingerprints() as { data: any[] | undefined; isLoading: boolean };
  const { data: students } = useQuery<Student[]>({ queryKey: [api.students.list.path] });
  const assignFingerprint = useAssignFingerprint();
  const dismissFingerprint = useDismissFingerprint();

  const [assignDialog, setAssignDialog] = useState<{ id: number; fingerprintId: number } | null>(null);
  const [selectedStudentId, setSelectedStudentId] = useState<string>("");

  const unassignedStudents = students?.filter(s => !s.fingerprintId) || [];

  const handleAssign = () => {
    if (!assignDialog || !selectedStudentId) return;
    assignFingerprint.mutate(
      { scannedFingerprintId: assignDialog.id, studentId: Number(selectedStudentId) },
      {
        onSuccess: () => {
          setAssignDialog(null);
          setSelectedStudentId("");
        },
      }
    );
  };

  return (
    <div className="space-y-4 sm:space-y-6">
      <div>
        <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold text-foreground" data-testid="text-page-title">Assign Fingerprints</h1>
        <p className="text-muted-foreground mt-1" data-testid="text-page-description">
          Fingerprints scanned by ESP32 devices that haven't been assigned to students yet.
          Select a student to link each fingerprint.
        </p>
      </div>

      {isLoading ? (
        <div className="flex items-center justify-center py-16">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : !fingerprints?.length ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-16 text-center">
            <div className="bg-muted p-4 rounded-full mb-4">
              <Fingerprint className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-semibold text-foreground" data-testid="text-empty-title">No Unassigned Fingerprints</h3>
            <p className="text-muted-foreground mt-1 max-w-md" data-testid="text-empty-description">
              When an ESP32 device scans a fingerprint that isn't linked to any student,
              it will appear here for you to assign.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {fingerprints.map((fp: any) => (
            <Card key={fp.id} data-testid={`card-fingerprint-${fp.id}`}>
              <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-3">
                <CardTitle className="text-base font-semibold flex items-center gap-2">
                  <Fingerprint className="h-5 w-5 text-primary" />
                  Fingerprint #{fp.fingerprintId}
                </CardTitle>
                <Badge variant="secondary" data-testid={`badge-unassigned-${fp.id}`}>
                  Unassigned
                </Badge>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Server className="h-4 w-4" />
                  <span data-testid={`text-device-${fp.id}`}>
                    {fp.device?.name || "Unknown device"}
                    {fp.device?.location ? ` (${fp.device.location})` : ""}
                  </span>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Clock className="h-4 w-4" />
                  <span data-testid={`text-scanned-at-${fp.id}`}>
                    {fp.scannedAt ? format(new Date(fp.scannedAt), "MMM d, yyyy h:mm a") : "Unknown"}
                  </span>
                </div>
                <div className="flex flex-wrap gap-2 pt-2">
                  <Button
                    size="sm"
                    data-testid={`button-assign-${fp.id}`}
                    onClick={() => {
                      setAssignDialog({ id: fp.id, fingerprintId: fp.fingerprintId });
                      setSelectedStudentId("");
                    }}
                  >
                    <UserPlus className="h-4 w-4 mr-2" />
                    Assign to Student
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-destructive"
                    data-testid={`button-dismiss-${fp.id}`}
                    onClick={() => {
                      if (confirm("Dismiss this fingerprint? It will be removed from the list.")) {
                        dismissFingerprint.mutate(fp.id);
                      }
                    }}
                  >
                    <Trash2 className="h-4 w-4 mr-2" />
                    Dismiss
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={!!assignDialog} onOpenChange={(open) => { if (!open) setAssignDialog(null); }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Assign Fingerprint #{assignDialog?.fingerprintId}</DialogTitle>
            <DialogDescription>
              Select a student to link this fingerprint to. Only students without an existing fingerprint are shown.
            </DialogDescription>
          </DialogHeader>

          {unassignedStudents.length === 0 ? (
            <div className="flex items-center gap-3 p-4 rounded-md bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900 text-amber-800 dark:text-amber-400 text-sm">
              <AlertCircle className="h-5 w-5 flex-shrink-0" />
              <span>All students already have fingerprints assigned. Add new students first.</span>
            </div>
          ) : (
            <Select value={selectedStudentId} onValueChange={setSelectedStudentId}>
              <SelectTrigger data-testid="select-student">
                <SelectValue placeholder="Select a student..." />
              </SelectTrigger>
              <SelectContent>
                {unassignedStudents.map((student) => (
                  <SelectItem key={student.id} value={String(student.id)} data-testid={`option-student-${student.id}`}>
                    {student.name} ({student.rollNumber})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setAssignDialog(null)} data-testid="button-cancel-assign">
              Cancel
            </Button>
            <Button
              onClick={handleAssign}
              disabled={!selectedStudentId || assignFingerprint.isPending}
              data-testid="button-confirm-assign"
            >
              {assignFingerprint.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Assign Fingerprint
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
