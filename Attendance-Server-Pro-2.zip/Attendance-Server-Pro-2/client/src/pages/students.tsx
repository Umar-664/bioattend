import { useState } from "react";
import { useStudents, useCreateStudent, useUpdateStudent, useDeleteStudent } from "@/hooks/use-students";
import { useClasses } from "@/hooks/use-classes";
import { useDepartments } from "@/hooks/use-departments";
import { useUserRole } from "@/hooks/use-role";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus, Search, Trash2, Pencil, Fingerprint, Building2, CheckCircle2, XCircle, Clock, UserPlus, Users } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertStudentSchema, type InsertStudent, type Student } from "@shared/schema";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { z } from "zod";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

function usePendingStudents() {
  return useQuery({
    queryKey: ["/api/students/pending"],
    queryFn: async () => {
      const res = await fetch("/api/students/pending", { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch pending students");
      return res.json() as Promise<Student[]>;
    },
  });
}

function useApproveStudent() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  return useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(`/api/students/${id}/approve`, {
        method: "POST",
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to approve student");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/students/pending"] });
      queryClient.invalidateQueries({ queryKey: ["/api/students"] });
      toast({ title: "Approved", description: "Student has been approved" });
    },
    onError: (error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });
}

function useRejectStudent() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  return useMutation({
    mutationFn: async (id: number) => {
      const res = await fetch(`/api/students/${id}/reject`, {
        method: "POST",
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to reject student");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/students/pending"] });
      queryClient.invalidateQueries({ queryKey: ["/api/students"] });
      toast({ title: "Rejected", description: "Student registration rejected" });
    },
    onError: (error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });
}

export default function Students() {
  const [search, setSearch] = useState("");
  const [selectedClass, setSelectedClass] = useState<string>("all");
  const { data: students, isLoading } = useStudents({ 
    search: search || undefined,
    classId: selectedClass !== "all" ? Number(selectedClass) : undefined 
  });
  const { data: classes } = useClasses();
  const { data: allDepartments } = useDepartments();
  const { isViewer, isAdmin } = useUserRole();
  const deleteStudent = useDeleteStudent();
  const [open, setOpen] = useState(false);
  const [editStudent, setEditStudent] = useState<Student | null>(null);

  const { data: pendingStudents } = usePendingStudents();
  const approveStudent = useApproveStudent();
  const rejectStudent = useRejectStudent();

  const activeStudents = students || [];
  const pendingCount = pendingStudents?.length || 0;

  return (
    <div className="space-y-4 sm:space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold tracking-tight text-foreground">Students</h1>
          <p className="text-muted-foreground text-sm mt-1">Manage student enrollments and biometrics</p>
        </div>
        {!isViewer && (
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button data-testid="button-add-student" className="w-full sm:w-auto">
                <Plus className="mr-2 h-4 w-4" /> Register Student
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Register New Student</DialogTitle>
              </DialogHeader>
              <CreateStudentForm onSuccess={() => setOpen(false)} />
            </DialogContent>
          </Dialog>
        )}
      </div>

      {isAdmin && pendingCount > 0 && (
        <Card className="border-amber-200 dark:border-amber-800 bg-amber-50/50 dark:bg-amber-950/20">
          <CardContent className="p-4 sm:p-6">
            <div className="flex items-center gap-2 mb-4">
              <div className="h-8 w-8 rounded-full bg-amber-100 dark:bg-amber-900/50 flex items-center justify-center">
                <UserPlus className="h-4 w-4 text-amber-600 dark:text-amber-400" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground" data-testid="text-pending-title">
                  Pending Approvals ({pendingCount})
                </h3>
                <p className="text-xs text-muted-foreground">Students waiting for your approval to join</p>
              </div>
            </div>
            <div className="space-y-2">
              {pendingStudents?.map((student) => {
                const studentClass = classes?.find(c => c.id === student.classId);
                const studentDept = allDepartments?.find(d => d.id === student.departmentId);
                return (
                  <div
                    key={student.id}
                    className="flex items-center justify-between gap-3 p-3 bg-card rounded-lg border"
                    data-testid={`pending-student-${student.id}`}
                  >
                    <div className="min-w-0 flex-1">
                      <p className="font-medium text-foreground text-sm truncate">{student.name}</p>
                      <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                        <span className="text-xs text-muted-foreground font-mono">{student.rollNumber}</span>
                        {studentClass && (
                          <Badge variant="secondary" className="text-xs">{studentClass.name}</Badge>
                        )}
                        {studentDept && (
                          <Badge variant="outline" className="text-xs">{studentDept.name}</Badge>
                        )}
                      </div>
                    </div>
                    <div className="flex gap-1.5 flex-shrink-0">
                      <Button
                        size="sm"
                        variant="outline"
                        className="text-emerald-600 border-emerald-200 hover:bg-emerald-50 dark:text-emerald-400 dark:border-emerald-800 dark:hover:bg-emerald-950/30 h-8"
                        onClick={() => approveStudent.mutate(student.id)}
                        disabled={approveStudent.isPending}
                        data-testid={`button-approve-student-${student.id}`}
                      >
                        <CheckCircle2 className="h-3.5 w-3.5 mr-1" />
                        Approve
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="text-destructive border-destructive/30 hover:bg-destructive/5 h-8"
                        onClick={() => {
                          if (confirm("Reject this student registration?")) {
                            rejectStudent.mutate(student.id);
                          }
                        }}
                        disabled={rejectStudent.isPending}
                        data-testid={`button-reject-student-${student.id}`}
                      >
                        <XCircle className="h-3.5 w-3.5 mr-1" />
                        Reject
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search by name or roll number..."
            className="pl-9"
            data-testid="input-search-students"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <Select value={selectedClass} onValueChange={setSelectedClass}>
          <SelectTrigger className="w-full sm:w-[200px]" data-testid="select-filter-class">
            <SelectValue placeholder="Filter by Class" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Classes</SelectItem>
            {classes?.map((cls) => (
              <SelectItem key={cls.id} value={String(cls.id)}>
                {cls.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="hidden md:block">
        <Card>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="font-semibold">Name</TableHead>
                  <TableHead className="font-semibold">Roll Number</TableHead>
                  <TableHead className="font-semibold">Department</TableHead>
                  <TableHead className="font-semibold">Class</TableHead>
                  <TableHead className="font-semibold">Status</TableHead>
                  <TableHead className="font-semibold">Fingerprint ID</TableHead>
                  {isAdmin && <TableHead className="text-right font-semibold">Actions</TableHead>}
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <>
                    {[1, 2, 3].map(i => (
                      <TableRow key={i}>
                        {Array.from({ length: isAdmin ? 7 : 6 }).map((_, j) => (
                          <TableCell key={j}><div className="h-4 bg-muted rounded animate-pulse" /></TableCell>
                        ))}
                      </TableRow>
                    ))}
                  </>
                ) : activeStudents.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={isAdmin ? 7 : 6} className="h-32 text-center">
                      <div className="flex flex-col items-center justify-center py-4">
                        <Users className="h-8 w-8 text-muted-foreground/50 mb-2" />
                        <p className="text-muted-foreground font-medium" data-testid="text-no-students">No students found</p>
                        <p className="text-muted-foreground text-xs mt-1">
                          {search || selectedClass !== "all" ? "Try adjusting your filters." : "Register your first student to get started."}
                        </p>
                      </div>
                    </TableCell>
                  </TableRow>
                ) : (
                  activeStudents.map((student) => {
                    const studentClass = classes?.find(c => c.id === student.classId);
                    const studentDept = allDepartments?.find(d => d.id === student.departmentId);
                    return (
                      <TableRow key={student.id} data-testid={`row-student-${student.id}`}>
                        <TableCell className="font-medium">{student.name}</TableCell>
                        <TableCell className="font-mono text-muted-foreground">{student.rollNumber}</TableCell>
                        <TableCell>
                          {studentDept ? (
                            <Badge variant="outline">{studentDept.name}</Badge>
                          ) : (
                            <span className="text-muted-foreground text-xs">—</span>
                          )}
                        </TableCell>
                        <TableCell>
                          <Badge variant="secondary">{studentClass?.name || "Unassigned"}</Badge>
                        </TableCell>
                        <TableCell>
                          {student.status === "pending" ? (
                            <Badge variant="outline" className="text-amber-600 border-amber-300 dark:text-amber-400 dark:border-amber-700">
                              <Clock className="h-3 w-3 mr-1" /> Pending
                            </Badge>
                          ) : (
                            <Badge variant="outline" className="text-emerald-600 border-emerald-300 dark:text-emerald-400 dark:border-emerald-700">
                              <CheckCircle2 className="h-3 w-3 mr-1" /> Active
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell>
                          {student.fingerprintId ? (
                            <div className="flex items-center text-emerald-600 dark:text-emerald-400 text-xs font-medium">
                              <Fingerprint className="h-3 w-3 mr-1" />
                              ID: {student.fingerprintId}
                            </div>
                          ) : (
                            <span className="text-muted-foreground text-xs">Not Registered</span>
                          )}
                        </TableCell>
                        {isAdmin && (
                          <TableCell className="text-right">
                            <div className="flex items-center justify-end gap-1">
                              <Button
                                variant="ghost"
                                size="icon"
                                data-testid={`button-edit-student-${student.id}`}
                                onClick={() => setEditStudent(student)}
                              >
                                <Pencil className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="text-destructive"
                                data-testid={`button-delete-student-${student.id}`}
                                onClick={() => {
                                  if (confirm('Delete this student?')) {
                                    deleteStudent.mutate(student.id);
                                  }
                                }}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        )}
                      </TableRow>
                    );
                  })
                )}
              </TableBody>
            </Table>
          </div>
        </Card>
      </div>

      <div className="md:hidden space-y-3">
        {isLoading ? (
          <div className="space-y-3">
            {[1, 2, 3].map(i => <div key={i} className="h-24 bg-muted rounded-md animate-pulse" />)}
          </div>
        ) : activeStudents.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-8 text-center">
              <Users className="h-8 w-8 text-muted-foreground/50 mb-2" />
              <p className="text-muted-foreground font-medium">No students found</p>
              <p className="text-muted-foreground text-xs mt-1">
                {search || selectedClass !== "all" ? "Try adjusting your filters." : "Register your first student to get started."}
              </p>
            </CardContent>
          </Card>
        ) : (
          activeStudents.map((student) => {
            const studentClass = classes?.find(c => c.id === student.classId);
            const studentDept = allDepartments?.find(d => d.id === student.departmentId);
            return (
              <Card key={student.id} className="p-4" data-testid={`card-student-${student.id}`}>
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0 flex-1">
                    <p className="font-medium text-foreground truncate">{student.name}</p>
                    <p className="text-sm text-muted-foreground font-mono">{student.rollNumber}</p>
                    <div className="flex flex-wrap items-center gap-2 mt-2">
                      {studentDept && <Badge variant="outline" className="text-xs">{studentDept.name}</Badge>}
                      <Badge variant="secondary" className="text-xs">{studentClass?.name || "Unassigned"}</Badge>
                      {student.fingerprintId ? (
                        <span className="text-emerald-600 dark:text-emerald-400 text-xs font-medium flex items-center">
                          <Fingerprint className="h-3 w-3 mr-1" />
                          ID: {student.fingerprintId}
                        </span>
                      ) : (
                        <span className="text-muted-foreground text-xs">No fingerprint</span>
                      )}
                    </div>
                  </div>
                  {isAdmin && (
                    <div className="flex gap-1 flex-shrink-0">
                      <Button variant="ghost" size="icon" onClick={() => setEditStudent(student)}>
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-destructive"
                        onClick={() => {
                          if (confirm('Delete this student?')) deleteStudent.mutate(student.id);
                        }}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  )}
                </div>
              </Card>
            );
          })
        )}
      </div>

      {isAdmin && (
        <Dialog open={!!editStudent} onOpenChange={(open) => { if (!open) setEditStudent(null); }}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Edit Student</DialogTitle>
            </DialogHeader>
            {editStudent && (
              <EditStudentForm
                key={editStudent.id}
                student={editStudent}
                onSuccess={() => setEditStudent(null)}
              />
            )}
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}

function EditStudentForm({ student, onSuccess }: { student: Student; onSuccess: () => void }) {
  const updateStudent = useUpdateStudent();
  const { data: classes } = useClasses();
  const { data: departments } = useDepartments();

  const formSchema = insertStudentSchema.extend({
    classId: z.coerce.number().nullable(),
    fingerprintId: z.coerce.number().nullable(),
    departmentId: z.coerce.number().nullable(),
  });

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: student.name,
      rollNumber: student.rollNumber,
      classId: student.classId,
      fingerprintId: student.fingerprintId,
      departmentId: student.departmentId || null,
    },
  });

  function onSubmit(data: z.infer<typeof formSchema>) {
    updateStudent.mutate(
      { id: student.id, ...data, departmentId: data.departmentId || null },
      { onSuccess }
    );
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Full Name</FormLabel>
              <FormControl>
                <Input data-testid="input-edit-student-name" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="rollNumber"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Roll Number</FormLabel>
              <FormControl>
                <Input data-testid="input-edit-student-roll" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="departmentId"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Department</FormLabel>
              <Select
                onValueChange={(val) => field.onChange(val ? Number(val) : null)}
                value={field.value ? String(field.value) : undefined}
              >
                <FormControl>
                  <SelectTrigger data-testid="select-edit-student-department">
                    <SelectValue placeholder="Select Department" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {departments?.map((d) => (
                    <SelectItem key={d.id} value={String(d.id)}>{d.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="classId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Class</FormLabel>
                <Select
                  onValueChange={(val) => field.onChange(val ? Number(val) : null)}
                  value={field.value ? String(field.value) : undefined}
                >
                  <FormControl>
                    <SelectTrigger data-testid="select-edit-student-class">
                      <SelectValue placeholder="Select Class" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {classes?.map((c) => (
                      <SelectItem key={c.id} value={String(c.id)}>
                        {c.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="fingerprintId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Fingerprint ID</FormLabel>
                <FormControl>
                  <Input
                    type="number"
                    data-testid="input-edit-student-fingerprint"
                    {...field}
                    value={field.value || ''}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <Button
          type="submit"
          className="w-full"
          disabled={updateStudent.isPending}
          data-testid="button-submit-edit-student"
        >
          {updateStudent.isPending ? "Saving..." : "Save Changes"}
        </Button>
      </form>
    </Form>
  );
}

function CreateStudentForm({ onSuccess }: { onSuccess: () => void }) {
  const createStudent = useCreateStudent();
  const { data: classes } = useClasses();
  const { data: departments } = useDepartments();
  
  const formSchema = insertStudentSchema.extend({
    classId: z.coerce.number().nullable(),
    fingerprintId: z.coerce.number().nullable(),
    departmentId: z.coerce.number().nullable(),
  });

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      rollNumber: "",
      classId: null,
      fingerprintId: null,
      departmentId: null,
    },
  });

  function onSubmit(data: z.infer<typeof formSchema>) {
    createStudent.mutate({ ...data, departmentId: data.departmentId || null }, {
      onSuccess: () => {
        form.reset();
        onSuccess();
      },
    });
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Full Name</FormLabel>
              <FormControl>
                <Input placeholder="John Doe" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="rollNumber"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Roll Number</FormLabel>
              <FormControl>
                <Input placeholder="2024-001" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="departmentId"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Department</FormLabel>
              <Select
                onValueChange={(val) => field.onChange(val ? Number(val) : null)}
                value={field.value ? String(field.value) : undefined}
              >
                <FormControl>
                  <SelectTrigger data-testid="select-create-student-department">
                    <SelectValue placeholder="Select Department" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {departments?.map((d) => (
                    <SelectItem key={d.id} value={String(d.id)}>{d.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="classId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Class</FormLabel>
                <Select 
                  onValueChange={(val) => field.onChange(val ? Number(val) : null)} 
                  value={field.value ? String(field.value) : undefined}
                >
                  <FormControl>
                    <SelectTrigger data-testid="select-create-student-class">
                      <SelectValue placeholder="Select Class" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {classes?.map((c) => (
                      <SelectItem key={c.id} value={String(c.id)}>
                        {c.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="fingerprintId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Fingerprint ID</FormLabel>
                <FormControl>
                  <Input type="number" placeholder="Optional" {...field} value={field.value || ''} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <Button 
          type="submit" 
          className="w-full" 
          disabled={createStudent.isPending}
          data-testid="button-submit-create-student"
        >
          {createStudent.isPending ? "Creating..." : "Create Student"}
        </Button>
      </form>
    </Form>
  );
}
