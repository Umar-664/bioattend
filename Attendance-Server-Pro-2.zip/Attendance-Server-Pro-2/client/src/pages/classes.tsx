import { useState } from "react";
import { useClasses, useCreateClass, useUpdateClass, useDeleteClass } from "@/hooks/use-classes";
import { useStudents } from "@/hooks/use-students";
import { useDepartments } from "@/hooks/use-departments";
import { useUserRole } from "@/hooks/use-role";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Trash2, Edit2, Users, Clock, CalendarDays, Building2, KeyRound, Copy, RefreshCw, GraduationCap } from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card } from "@/components/ui/card";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertClassSchema, type InsertClass, type Class } from "@shared/schema";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";

export default function Classes() {
  const { data: classes, isLoading } = useClasses();
  const { data: allStudents } = useStudents();
  const { data: allDepartments } = useDepartments();
  const { isViewer, isAdmin } = useUserRole();
  const deleteClass = useDeleteClass();
  const [open, setOpen] = useState(false);
  const [editClass, setEditClass] = useState<Class | null>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const generateInviteCode = useMutation({
    mutationFn: async (classId: number) => {
      const res = await fetch(`/api/classes/${classId}/invite-code`, {
        method: "POST",
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to generate invite code");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/classes"] });
      toast({ title: "Invite code generated" });
    },
    onError: (error) => {
      toast({ title: "Error", description: error.message || "Failed to generate invite code", variant: "destructive" });
    },
  });

  const studentCountByClass = (classId: number) => {
    return allStudents?.filter(s => s.classId === classId).length || 0;
  };

  return (
    <div className="space-y-4 sm:space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold tracking-tight text-foreground">Classes</h1>
          <p className="text-muted-foreground text-sm mt-1">Manage class schedules and timings</p>
        </div>
        {!isViewer && (
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button data-testid="button-add-class" className="w-full sm:w-auto">
                <Plus className="mr-2 h-4 w-4" /> Add Class
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Class</DialogTitle>
              </DialogHeader>
              <ClassForm onSuccess={() => setOpen(false)} />
            </DialogContent>
          </Dialog>
        )}
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-48 bg-muted rounded-md animate-pulse" />
          ))}
        </div>
      ) : classes?.length === 0 ? (
        <Card className="p-8 text-center">
          <div className="bg-muted p-4 rounded-full w-fit mx-auto mb-4">
            <GraduationCap className="h-10 w-10 text-muted-foreground" />
          </div>
          <h3 className="text-lg font-semibold text-foreground" data-testid="text-no-classes">No classes yet</h3>
          <p className="text-muted-foreground text-sm mt-1 max-w-md mx-auto">
            {isViewer ? "No classes have been created yet." : "Create your first class to start managing schedules and attendance."}
          </p>
        </Card>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {classes?.map((cls) => (
            <Card key={cls.id} className="p-4 sm:p-6 group" data-testid={`card-class-${cls.id}`}>
              <div className="flex justify-between items-start mb-3 gap-2">
                <div className="min-w-0">
                  <h3 className="text-base sm:text-lg font-bold text-foreground truncate">{cls.name}</h3>
                  <span className={`inline-flex items-center px-2 py-0.5 rounded-md text-xs font-medium mt-1.5 ${
                    cls.scheduleType === 'morning' 
                      ? 'bg-amber-100 text-amber-800 dark:bg-amber-950/40 dark:text-amber-400' 
                      : 'bg-indigo-100 text-indigo-800 dark:bg-indigo-950/40 dark:text-indigo-400'
                  }`}>
                    {cls.scheduleType.charAt(0).toUpperCase() + cls.scheduleType.slice(1)} Shift
                  </span>
                </div>
                {isAdmin && (
                  <div className="flex gap-1 flex-shrink-0">
                    <Button
                      variant="ghost"
                      size="icon"
                      data-testid={`button-edit-class-${cls.id}`}
                      onClick={() => setEditClass(cls)}
                    >
                      <Edit2 className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="text-destructive"
                      data-testid={`button-delete-class-${cls.id}`}
                      onClick={() => {
                        if (confirm('Are you sure you want to delete this class?')) {
                          deleteClass.mutate(cls.id);
                        }
                      }}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                )}
              </div>
              
              <div className="space-y-2">
                {cls.departmentId && (
                  <div className="flex items-center gap-1.5 text-sm text-muted-foreground" data-testid={`text-department-${cls.id}`}>
                    <Building2 className="h-3.5 w-3.5 flex-shrink-0" />
                    <span className="truncate">{allDepartments?.find(d => d.id === cls.departmentId)?.name || "Unknown"}</span>
                  </div>
                )}
                {cls.instructor && (
                  <p className="text-sm text-muted-foreground" data-testid={`text-instructor-${cls.id}`}>
                    Instructor: <span className="font-medium text-foreground">{cls.instructor}</span>
                  </p>
                )}

                <div className="pt-3 border-t border-border space-y-2 text-sm">
                  <div className="flex items-center justify-between gap-2 flex-wrap">
                    <div className="flex items-center text-muted-foreground">
                      <Users className="h-4 w-4 mr-2 flex-shrink-0" />
                      <span>{studentCountByClass(cls.id)} Students</span>
                    </div>
                    <div className="font-mono text-xs bg-muted px-2 py-1 rounded-md text-muted-foreground">
                      {cls.startTime.slice(0, 5)} - {cls.endTime.slice(0, 5)}
                    </div>
                  </div>
                  {cls.lateTime && (
                    <div className="flex items-center text-amber-600 dark:text-amber-400 text-xs" data-testid={`text-late-time-${cls.id}`}>
                      <Clock className="h-3 w-3 mr-1 flex-shrink-0" />
                      Late after {cls.lateTime.slice(0, 5)}
                    </div>
                  )}
                  {(cls.sessionStartDate || cls.sessionEndDate) && (
                    <div className="flex items-center text-muted-foreground text-xs" data-testid={`text-session-dates-${cls.id}`}>
                      <CalendarDays className="h-3 w-3 mr-1 flex-shrink-0" />
                      {cls.sessionStartDate || '?'} to {cls.sessionEndDate || '?'}
                    </div>
                  )}

                  {isAdmin && (
                    <div className="pt-2 mt-2 border-t border-border">
                      {cls.inviteCode ? (
                        <div className="flex items-center justify-between gap-2">
                          <div className="flex items-center gap-1.5 text-xs">
                            <KeyRound className="h-3 w-3 text-primary flex-shrink-0" />
                            <span className="font-mono font-medium text-foreground" data-testid={`text-invite-code-${cls.id}`}>
                              {cls.inviteCode}
                            </span>
                          </div>
                          <div className="flex gap-1">
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-6 w-6"
                              data-testid={`button-copy-invite-${cls.id}`}
                              onClick={() => {
                                navigator.clipboard.writeText(cls.inviteCode!);
                                toast({ title: "Copied!", description: "Invite code copied to clipboard" });
                              }}
                            >
                              <Copy className="h-3 w-3" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-6 w-6"
                              data-testid={`button-regenerate-invite-${cls.id}`}
                              onClick={() => generateInviteCode.mutate(cls.id)}
                              disabled={generateInviteCode.isPending}
                            >
                              <RefreshCw className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                      ) : (
                        <Button
                          variant="outline"
                          size="sm"
                          className="w-full h-7 text-xs"
                          data-testid={`button-generate-invite-${cls.id}`}
                          onClick={() => generateInviteCode.mutate(cls.id)}
                          disabled={generateInviteCode.isPending}
                        >
                          <KeyRound className="h-3 w-3 mr-1" />
                          Generate Invite Code
                        </Button>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      {isAdmin && (
        <Dialog open={!!editClass} onOpenChange={(open) => { if (!open) setEditClass(null); }}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Edit Class</DialogTitle>
            </DialogHeader>
            {editClass && (
              <ClassForm
                key={editClass.id}
                editClass={editClass}
                onSuccess={() => setEditClass(null)}
              />
            )}
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}

function ClassForm({ onSuccess, editClass }: { onSuccess: () => void; editClass?: Class }) {
  const createClass = useCreateClass();
  const updateClass = useUpdateClass();
  const { data: departments } = useDepartments();
  const isEditing = !!editClass;

  const form = useForm<InsertClass>({
    resolver: zodResolver(insertClassSchema),
    defaultValues: {
      name: editClass?.name || "",
      instructor: editClass?.instructor || "",
      scheduleType: editClass?.scheduleType || "morning",
      startTime: editClass?.startTime || "09:00",
      endTime: editClass?.endTime || "10:00",
      lateTime: editClass?.lateTime || "",
      sessionStartDate: editClass?.sessionStartDate || "",
      sessionEndDate: editClass?.sessionEndDate || "",
      departmentId: editClass?.departmentId || null,
    },
  });

  function onSubmit(data: InsertClass) {
    const cleaned = {
      ...data,
      instructor: data.instructor || null,
      lateTime: data.lateTime || null,
      sessionStartDate: data.sessionStartDate || null,
      sessionEndDate: data.sessionEndDate || null,
      departmentId: data.departmentId || null,
    };

    if (isEditing) {
      updateClass.mutate({ id: editClass.id, ...cleaned }, {
        onSuccess: () => onSuccess(),
      });
    } else {
      createClass.mutate(cleaned, {
        onSuccess: () => {
          form.reset();
          onSuccess();
        },
      });
    }
  }

  const isPending = isEditing ? updateClass.isPending : createClass.isPending;

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Class Name</FormLabel>
              <FormControl>
                <Input placeholder="e.g. CS-101" {...field} data-testid="input-class-name" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="instructor"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Instructor</FormLabel>
              <FormControl>
                <Input placeholder="e.g. Dr. Ahmed" data-testid="input-class-instructor" {...field} value={field.value || ''} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="departmentId"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Department</FormLabel>
              <Select
                onValueChange={(val) => field.onChange(val ? Number(val) : null)}
                value={field.value ? String(field.value) : undefined}
              >
                <FormControl>
                  <SelectTrigger data-testid="select-class-department">
                    <SelectValue placeholder="Select Department" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {departments?.map((d) => (
                    <SelectItem key={d.id} value={String(d.id)}>{d.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="scheduleType"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Schedule</FormLabel>
              <Select onValueChange={field.onChange} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger data-testid="select-class-schedule">
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  <SelectItem value="morning">Morning</SelectItem>
                  <SelectItem value="evening">Evening</SelectItem>
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="grid grid-cols-3 gap-3">
          <FormField
            control={form.control}
            name="startTime"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Start Time</FormLabel>
                <FormControl>
                  <Input type="time" data-testid="input-class-start" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="endTime"
            render={({ field }) => (
              <FormItem>
                <FormLabel>End Time</FormLabel>
                <FormControl>
                  <Input type="time" data-testid="input-class-end" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="lateTime"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Late After</FormLabel>
                <FormControl>
                  <Input type="time" data-testid="input-class-late" {...field} value={field.value || ''} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <FormField
            control={form.control}
            name="sessionStartDate"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Session Start Date</FormLabel>
                <FormControl>
                  <Input type="date" data-testid="input-session-start" {...field} value={field.value || ''} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="sessionEndDate"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Session End Date</FormLabel>
                <FormControl>
                  <Input type="date" data-testid="input-session-end" {...field} value={field.value || ''} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <Button 
          type="submit" 
          className="w-full" 
          disabled={isPending}
        >
          {isPending ? (isEditing ? "Saving..." : "Creating...") : (isEditing ? "Save Changes" : "Create Class")}
        </Button>
      </form>
    </Form>
  );
}
