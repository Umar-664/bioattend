import { useState } from "react";
import { useDepartments, useCreateDepartment, useUpdateDepartment, useDeleteDepartment } from "@/hooks/use-departments";
import { useUserRole } from "@/hooks/use-role";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Trash2, Edit2, Building2, User } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Card } from "@/components/ui/card";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertDepartmentSchema, type InsertDepartment, type Department } from "@shared/schema";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";

function DepartmentForm({ onSuccess, editDept }: { onSuccess: () => void; editDept?: Department | null }) {
  const createDepartment = useCreateDepartment();
  const updateDepartment = useUpdateDepartment();

  const form = useForm<InsertDepartment>({
    resolver: zodResolver(insertDepartmentSchema),
    defaultValues: {
      name: editDept?.name || "",
      description: editDept?.description || "",
      headOfDepartment: editDept?.headOfDepartment || "",
    },
  });

  const onSubmit = async (data: InsertDepartment) => {
    if (editDept) {
      await updateDepartment.mutateAsync({ id: editDept.id, ...data });
    } else {
      await createDepartment.mutateAsync(data);
    }
    form.reset();
    onSuccess();
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Department Name</FormLabel>
              <FormControl>
                <Input data-testid="input-department-name" placeholder="e.g. Computer Science" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="description"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Description</FormLabel>
              <FormControl>
                <Textarea
                  data-testid="input-department-description"
                  placeholder="Brief description of the department"
                  {...field}
                  value={field.value || ""}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="headOfDepartment"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Head of Department</FormLabel>
              <FormControl>
                <Input
                  data-testid="input-department-head"
                  placeholder="e.g. Dr. Smith"
                  {...field}
                  value={field.value || ""}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <Button
          type="submit"
          className="w-full"
          data-testid="button-submit-department"
          disabled={createDepartment.isPending || updateDepartment.isPending}
        >
          {createDepartment.isPending || updateDepartment.isPending ? "Saving..." : editDept ? "Update Department" : "Create Department"}
        </Button>
      </form>
    </Form>
  );
}

export default function Departments() {
  const { data: departments, isLoading } = useDepartments();
  const { isViewer, isAdmin } = useUserRole();
  const deleteDepartment = useDeleteDepartment();
  const [open, setOpen] = useState(false);
  const [editDept, setEditDept] = useState<Department | null>(null);

  return (
    <div className="space-y-4 sm:space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold tracking-tight text-foreground">Departments</h1>
          <p className="text-muted-foreground text-sm mt-1">Manage departments in the institution</p>
        </div>
        {!isViewer && (
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button data-testid="button-add-department" className="w-full sm:w-auto">
                <Plus className="mr-2 h-4 w-4" /> Add Department
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Department</DialogTitle>
              </DialogHeader>
              <DepartmentForm onSuccess={() => setOpen(false)} />
            </DialogContent>
          </Dialog>
        )}
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-40 bg-muted rounded-md animate-pulse" />
          ))}
        </div>
      ) : departments?.length === 0 ? (
        <Card className="p-8 text-center">
          <Building2 className="h-12 w-12 mx-auto text-muted-foreground mb-3" />
          <h3 className="text-lg font-semibold text-foreground">No departments yet</h3>
          <p className="text-muted-foreground text-sm mt-1">
            {isViewer ? "No departments have been added yet." : "Get started by adding your first department."}
          </p>
        </Card>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {departments?.map((dept) => (
            <Card key={dept.id} className="p-4 sm:p-6 group" data-testid={`card-department-${dept.id}`}>
              <div className="flex justify-between items-start mb-3 gap-2">
                <div className="min-w-0">
                  <h3 className="text-base sm:text-lg font-bold text-foreground truncate">{dept.name}</h3>
                </div>
                {isAdmin && (
                  <div className="flex gap-1 flex-shrink-0">
                    <Button
                      variant="ghost"
                      size="icon"
                      data-testid={`button-edit-department-${dept.id}`}
                      onClick={() => setEditDept(dept)}
                    >
                      <Edit2 className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="text-destructive"
                      data-testid={`button-delete-department-${dept.id}`}
                      onClick={() => {
                        if (confirm("Delete this department?")) {
                          deleteDepartment.mutate(dept.id);
                        }
                      }}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                )}
              </div>

              {dept.description && (
                <p className="text-sm text-muted-foreground mb-3 line-clamp-2">{dept.description}</p>
              )}

              {dept.headOfDepartment && (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <User className="h-4 w-4 flex-shrink-0" />
                  <span className="truncate">{dept.headOfDepartment}</span>
                </div>
              )}
            </Card>
          ))}
        </div>
      )}

      <Dialog open={!!editDept} onOpenChange={(v) => !v && setEditDept(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Department</DialogTitle>
          </DialogHeader>
          {editDept && (
            <DepartmentForm
              editDept={editDept}
              onSuccess={() => setEditDept(null)}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
