import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Download,
  Upload,
  Cpu,
  Zap,
  AlertTriangle,
  Copy,
  Check,
  Database,
  Trash2,
  FileCode,
  CircuitBoard,
  Loader2,
  Mail,
  Send,
  KeyRound,
  Eye,
  EyeOff,
} from "lucide-react";

const ESP32_CODE = `#include <WiFi.h>
#include <HTTPClient.h>
#include <Adafruit_Fingerprint.h>
#include <Adafruit_GFX.h>
#include <Adafruit_ST7735.h>
#include <SPI.h>

// ============================================================
// BioTrack ESP32 - Fingerprint Attendance System
// Hardware: ESP32 + R307 Fingerprint Sensor + ST7735S LCD + LEDs
// ============================================================

// ----- WiFi Configuration -----
const char* WIFI_SSID     = "YOUR_WIFI_SSID";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";

// ----- Server Configuration -----
const char* SERVER_URL = "https://YOUR_REPLIT_APP.replit.app";
const char* API_KEY    = "YOUR_DEVICE_API_KEY";

// ----- LED Pin Definitions -----
#define GREEN_LED_PIN  2
#define RED_LED_PIN    4
#define STATUS_LED_PIN 15

// ----- R307 Fingerprint Sensor (UART2) -----
#define FINGER_RX 16
#define FINGER_TX 17

HardwareSerial fingerSerial(2);
Adafruit_Fingerprint finger = Adafruit_Fingerprint(&fingerSerial);

// ----- ST7735S LCD (SPI) -----
#define TFT_CS   5
#define TFT_RST  27
#define TFT_DC   26
#define TFT_MOSI 23
#define TFT_SCLK 18

Adafruit_ST7735 tft = Adafruit_ST7735(TFT_CS, TFT_DC, TFT_MOSI, TFT_SCLK, TFT_RST);

// ----- LCD Color Palette -----
#define CLR_BG       ST77XX_BLACK
#define CLR_TEXT     ST77XX_WHITE
#define CLR_OK       ST77XX_GREEN
#define CLR_ERR      ST77XX_RED
#define CLR_WARN     ST77XX_YELLOW
#define CLR_INFO     ST77XX_CYAN
#define CLR_HEADER   0x001F
#define CLR_MUTED    0x7BEF

// ----- NTP Configuration -----
const char* NTP_SERVER1 = "pool.ntp.org";
const char* NTP_SERVER2 = "time.nist.gov";
const long  GMT_OFFSET  = 0;
const int   DST_OFFSET  = 0;

// ----- Timing Intervals (ms) -----
const unsigned long MODE_CHECK_INTERVAL    = 10000;
const unsigned long HEARTBEAT_INTERVAL     = 30000;
const unsigned long NTP_RETRY_INTERVAL     = 60000;
const unsigned long WIFI_CHECK_INTERVAL    = 5000;
const unsigned long LCD_CLOCK_INTERVAL     = 1000;
const unsigned long ENROLL_WAIT_TIMEOUT    = 8000;
const unsigned long WIFI_RECONNECT_TIMEOUT = 15000;

// ----- Timing State -----
unsigned long lastModeCheck    = 0;
unsigned long lastHeartbeat    = 0;
unsigned long lastNtpRetry     = 0;
unsigned long lastWifiCheck    = 0;
unsigned long lastClockUpdate  = 0;

// ----- Application State -----
String currentMode        = "attendance";
bool isConnected          = false;
bool timeReady            = false;
bool fingerSensorReady    = false;

// ----- Non-blocking WiFi Reconnection -----
bool     wifiReconnecting   = false;
unsigned long wifiReconnStart = 0;

// ----- Non-blocking LED Blink State -----
struct LedBlink {
  int      pin;
  int      remaining;
  bool     isOn;
  unsigned long lastToggle;
};

LedBlink greenBlink = { GREEN_LED_PIN, 0, false, 0 };
LedBlink redBlink   = { RED_LED_PIN,   0, false, 0 };
const unsigned long BLINK_DURATION = 150;

// ----- Non-blocking Enrollment State Machine -----
enum EnrollState {
  ENROLL_IDLE,
  ENROLL_WAIT_LIFT,
  ENROLL_WAIT_SECOND,
  ENROLL_PROCESS
};

EnrollState enrollState    = ENROLL_IDLE;
int         enrollTargetId = -1;
unsigned long enrollTimer  = 0;

// ============================================================
// SETUP
// ============================================================
void setup() {
  Serial.begin(115200);

  pinMode(GREEN_LED_PIN, OUTPUT);
  pinMode(RED_LED_PIN, OUTPUT);
  pinMode(STATUS_LED_PIN, OUTPUT);
  digitalWrite(GREEN_LED_PIN, LOW);
  digitalWrite(RED_LED_PIN, LOW);
  digitalWrite(STATUS_LED_PIN, LOW);

  initLCD();
  lcdShowSplash();

  fingerSerial.begin(57600, SERIAL_8N1, FINGER_RX, FINGER_TX);
  finger.begin(57600);

  if (finger.verifyPassword()) {
    fingerSensorReady = true;
    Serial.println("[OK] R307 fingerprint sensor detected");
    lcdStatus("Sensor OK", CLR_OK);
  } else {
    fingerSensorReady = false;
    Serial.println("[ERROR] R307 NOT found!");
    lcdStatus("Sensor MISSING!", CLR_ERR);
    startRedBlink(5);
  }

  WiFi.mode(WIFI_STA);
  WiFi.setAutoReconnect(true);
  WiFi.onEvent(onWiFiEvent);

  lcdStatus("Connecting WiFi...", CLR_INFO);
  startWiFiConnect();
}

// ============================================================
// MAIN LOOP — fully non-blocking
// ============================================================
void loop() {
  unsigned long now = millis();

  updateLedBlinks(now);

  if (wifiReconnecting) {
    handleWiFiReconnect(now);
  }

  if (enrollState != ENROLL_IDLE) {
    handleEnrollStateMachine(now);
    return;
  }

  if (now - lastWifiCheck >= WIFI_CHECK_INTERVAL) {
    lastWifiCheck = now;
    if (WiFi.status() != WL_CONNECTED && !wifiReconnecting) {
      isConnected = false;
      digitalWrite(STATUS_LED_PIN, LOW);
      lcdStatus("WiFi lost!", CLR_ERR);
      startWiFiConnect();
    }
  }

  if (isConnected && !timeReady && now - lastNtpRetry >= NTP_RETRY_INTERVAL) {
    lastNtpRetry = now;
    attemptNtpSync();
  }

  if (isConnected && now - lastModeCheck >= MODE_CHECK_INTERVAL) {
    lastModeCheck = now;
    checkMode();
  }

  if (isConnected && now - lastHeartbeat >= HEARTBEAT_INTERVAL) {
    lastHeartbeat = now;
    sendHeartbeat();
  }

  if (now - lastClockUpdate >= LCD_CLOCK_INTERVAL) {
    lastClockUpdate = now;
    lcdUpdateClock();
  }

  if (fingerSensorReady) {
    int fingerprintId = scanFingerprint();
    if (fingerprintId >= 0) {
      handleScan(fingerprintId);
    }
  }
}

// ============================================================
// WiFi — event-driven + non-blocking reconnection
// ============================================================
void onWiFiEvent(WiFiEvent_t event) {
  switch (event) {
    case ARDUINO_EVENT_WIFI_STA_GOT_IP:
      isConnected = true;
      wifiReconnecting = false;
      digitalWrite(STATUS_LED_PIN, HIGH);
      Serial.println("[WiFi] Connected: " + WiFi.localIP().toString());
      lcdStatus("WiFi connected", CLR_OK);
      attemptNtpSync();
      break;

    case ARDUINO_EVENT_WIFI_STA_DISCONNECTED:
      isConnected = false;
      digitalWrite(STATUS_LED_PIN, LOW);
      Serial.println("[WiFi] Disconnected");
      break;

    default:
      break;
  }
}

void startWiFiConnect() {
  Serial.println("[WiFi] Connecting to " + String(WIFI_SSID));
  WiFi.disconnect(true);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  wifiReconnecting = true;
  wifiReconnStart  = millis();
}

void handleWiFiReconnect(unsigned long now) {
  if (WiFi.status() == WL_CONNECTED) {
    wifiReconnecting = false;
    return;
  }
  if (now - wifiReconnStart >= WIFI_RECONNECT_TIMEOUT) {
    Serial.println("[WiFi] Reconnect timeout, will retry");
    wifiReconnecting = false;
    startRedBlink(2);
    lcdStatus("WiFi failed", CLR_ERR);
  }
}

// ============================================================
// NTP Time Sync — with retry logic
// ============================================================
void attemptNtpSync() {
  Serial.println("[NTP] Syncing...");
  configTime(GMT_OFFSET, DST_OFFSET, NTP_SERVER1, NTP_SERVER2);

  struct tm timeinfo;
  if (getLocalTime(&timeinfo, 3000)) {
    timeReady = true;
    char buf[30];
    strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S", &timeinfo);
    Serial.println("[NTP] Synced: " + String(buf));
    lcdStatus("Time synced", CLR_OK);
  } else {
    timeReady = false;
    Serial.println("[NTP] Sync failed, will retry");
    lcdStatus("Time not synced", CLR_WARN);
  }
}

String getISOTimestamp() {
  struct tm timeinfo;
  if (timeReady && getLocalTime(&timeinfo, 100)) {
    char buf[25];
    strftime(buf, sizeof(buf), "%Y-%m-%dT%H:%M:%S", &timeinfo);
    return String(buf);
  }
  return "";
}

// ============================================================
// Mode Check — API key in header
// ============================================================
void checkMode() {
  if (!isConnected) return;

  HTTPClient http;
  String url = String(SERVER_URL) + "/api/device/mode";
  http.begin(url);
  http.addHeader("X-API-Key", String(API_KEY));
  http.setTimeout(5000);

  int httpCode = http.GET();
  if (httpCode == 200) {
    String payload = http.getString();

    int modeStart = payload.indexOf("\\"mode\\":\\"") + 8;
    int modeEnd   = payload.indexOf("\\"", modeStart);
    if (modeStart > 7 && modeEnd > modeStart) {
      String newMode = payload.substring(modeStart, modeEnd);
      if (newMode != currentMode) {
        Serial.println("[Mode] " + currentMode + " -> " + newMode);
        currentMode = newMode;
        lcdUpdateMode();
        if (currentMode == "enroll") {
          lcdShowEnrollReady();
        } else {
          lcdShowAttendanceReady();
        }
      }
    }
    digitalWrite(STATUS_LED_PIN, HIGH);
  } else {
    Serial.println("[Mode] Check failed: HTTP " + String(httpCode));
  }

  http.end();
}

// ============================================================
// Heartbeat — dedicated request, API key in header
// ============================================================
void sendHeartbeat() {
  if (!isConnected) return;

  HTTPClient http;
  String url = String(SERVER_URL) + "/api/device/heartbeat";
  http.begin(url);
  http.addHeader("X-API-Key", String(API_KEY));
  http.addHeader("Content-Type", "application/json");
  http.setTimeout(5000);

  String payload = "{\\"status\\":\\"online\\"}";
  int httpCode = http.POST(payload);

  if (httpCode == 200) {
    Serial.println("[Heartbeat] OK");
    digitalWrite(STATUS_LED_PIN, HIGH);
  } else {
    Serial.println("[Heartbeat] Failed: HTTP " + String(httpCode));

    url = String(SERVER_URL) + "/api/device/mode";
    http.end();
    http.begin(url);
    http.addHeader("X-API-Key", String(API_KEY));
    http.setTimeout(3000);
    httpCode = http.GET();
    if (httpCode == 200) {
      Serial.println("[Heartbeat] Fallback OK via mode endpoint");
      digitalWrite(STATUS_LED_PIN, HIGH);
    }
  }

  http.end();
}

// ============================================================
// Fingerprint Scanning — attendance mode
// ============================================================
int scanFingerprint() {
  uint8_t result = finger.getImage();
  if (result != FINGERPRINT_OK) return -1;

  result = finger.image2Tz();
  if (result != FINGERPRINT_OK) {
    Serial.println("[Finger] Image conversion failed");
    lcdFlash("Scan error", CLR_ERR);
    startRedBlink(1);
    return -1;
  }

  if (currentMode == "enroll") {
    startEnrollment();
    return -1;
  }

  result = finger.fingerSearch();
  if (result == FINGERPRINT_OK) {
    Serial.println("[Finger] Match ID #" + String(finger.fingerID)
                   + " conf:" + String(finger.confidence));
    return finger.fingerID;
  } else if (result == FINGERPRINT_NOTFOUND) {
    Serial.println("[Finger] No match");
    lcdFlash("Unknown finger", CLR_WARN);
    startRedBlink(2);
    return -1;
  } else {
    Serial.println("[Finger] Search error: " + String(result));
    lcdFlash("Scan error", CLR_ERR);
    startRedBlink(1);
    return -1;
  }
}

// ============================================================
// Enrollment — non-blocking state machine
// ============================================================
void startEnrollment() {
  Serial.println("[Enroll] First scan received, checking...");
  lcdFlash("Checking finger...", CLR_INFO);

  uint8_t result = finger.fingerSearch();
  if (result == FINGERPRINT_OK) {
    Serial.println("[Enroll] Already enrolled as ID #" + String(finger.fingerID));
    lcdFlash("Already enrolled #" + String(finger.fingerID), CLR_WARN);
    syncToServer(finger.fingerID);
    return;
  }

  int newId = findNextFreeSlot();
  if (newId < 0) {
    Serial.println("[Enroll] No free slots!");
    lcdFlash("Sensor memory full!", CLR_ERR);
    startRedBlink(3);
    return;
  }

  enrollTargetId = newId;
  enrollState    = ENROLL_WAIT_LIFT;
  enrollTimer    = millis();

  Serial.println("[Enroll] Enrolling as ID #" + String(newId));
  Serial.println("[Enroll] Lift finger then place again...");
  lcdShowEnrollStep("Lift finger...", newId);
  startGreenBlink(2);
}

void handleEnrollStateMachine(unsigned long now) {
  switch (enrollState) {

    case ENROLL_WAIT_LIFT: {
      if (now - enrollTimer > 3000) {
        enrollState = ENROLL_WAIT_SECOND;
        enrollTimer = now;
        lcdShowEnrollStep("Place finger again", enrollTargetId);
        Serial.println("[Enroll] Ready for second scan");
      }
      break;
    }

    case ENROLL_WAIT_SECOND: {
      if (now - enrollTimer > ENROLL_WAIT_TIMEOUT) {
        Serial.println("[Enroll] Timeout waiting for second scan");
        lcdFlash("Enroll timeout", CLR_ERR);
        startRedBlink(2);
        enrollReset();
        return;
      }

      uint8_t result = finger.getImage();
      if (result == FINGERPRINT_OK) {
        result = finger.image2Tz(2);
        if (result != FINGERPRINT_OK) {
          Serial.println("[Enroll] Second image conversion failed");
          lcdFlash("Scan error", CLR_ERR);
          startRedBlink(1);
          enrollReset();
          return;
        }
        enrollState = ENROLL_PROCESS;
      }
      break;
    }

    case ENROLL_PROCESS: {
      uint8_t result = finger.createModel();
      if (result != FINGERPRINT_OK) {
        Serial.println("[Enroll] Fingers didn't match");
        lcdFlash("No match, retry", CLR_ERR);
        startRedBlink(2);
        enrollReset();
        return;
      }

      result = finger.storeModel(enrollTargetId);
      if (result != FINGERPRINT_OK) {
        Serial.println("[Enroll] Store failed");
        lcdFlash("Store failed!", CLR_ERR);
        startRedBlink(1);
        enrollReset();
        return;
      }

      Serial.println("[Enroll] SUCCESS ID #" + String(enrollTargetId));
      lcdFlash("Enrolled #" + String(enrollTargetId), CLR_OK);
      syncToServer(enrollTargetId);
      startGreenBlink(3);
      enrollReset();
      break;
    }

    default:
      enrollReset();
      break;
  }
}

void enrollReset() {
  enrollState    = ENROLL_IDLE;
  enrollTargetId = -1;
  enrollTimer    = 0;
}

int findNextFreeSlot() {
  finger.getTemplateCount();
  Serial.println("[Enroll] Templates: " + String(finger.templateCount) + "/127");

  for (int i = 1; i <= 127; i++) {
    uint8_t result = finger.loadModel(i);
    if (result == FINGERPRINT_PACKETRECIEVEERR) {
      continue;
    }
    if (result != FINGERPRINT_OK) {
      return i;
    }
  }
  return -1;
}

// ============================================================
// Server Sync
// ============================================================
void handleScan(int fingerprintId) {
  Serial.println("[Sync] Fingerprint #" + String(fingerprintId)
                 + " mode:" + currentMode);

  if (!timeReady) {
    Serial.println("[Sync] Blocked: time not synced");
    lcdFlash("Time not synced!", CLR_ERR);
    startRedBlink(2);
    return;
  }

  lcdFlash("Syncing #" + String(fingerprintId), CLR_INFO);
  syncToServer(fingerprintId);
}

void syncToServer(int fingerprintId) {
  if (!isConnected) {
    Serial.println("[Sync] No WiFi");
    lcdFlash("No WiFi!", CLR_ERR);
    startRedBlink(2);
    return;
  }

  String timestamp = getISOTimestamp();
  if (timestamp.length() == 0 && currentMode == "attendance") {
    Serial.println("[Sync] Cannot sync attendance without valid time");
    lcdFlash("Time not ready", CLR_ERR);
    startRedBlink(1);
    return;
  }

  HTTPClient http;
  String url = String(SERVER_URL) + "/api/attendance/sync";
  http.begin(url);
  http.addHeader("Content-Type", "application/json");
  http.setTimeout(10000);

  String payload = "{\\"apiKey\\":\\"" + String(API_KEY)
                   + "\\",\\"fingerprintId\\":" + String(fingerprintId);
  if (timestamp.length() > 0) {
    payload += ",\\"timestamp\\":\\"" + timestamp + "\\"";
  }
  payload += "}";

  Serial.println("[Sync] POST " + url);
  int httpCode = http.POST(payload);

  if (httpCode == 200) {
    String response = http.getString();
    Serial.println("[Sync] OK: " + response);

    if (response.indexOf("\\"duplicate\\":true") >= 0) {
      lcdFlash("Already recorded", CLR_WARN);
      startGreenBlink(1);
    } else {
      lcdFlash("Attendance OK!", CLR_OK);
      startGreenBlink(2);
    }
  } else {
    String response = http.getString();
    Serial.println("[Sync] Error " + String(httpCode) + ": " + response);
    lcdFlash("Sync failed!", CLR_ERR);
    startRedBlink(2);
  }

  http.end();
}

// ============================================================
// Non-blocking LED Blinks
// ============================================================
void startGreenBlink(int times) {
  greenBlink.remaining  = times * 2;
  greenBlink.isOn       = false;
  greenBlink.lastToggle = millis();
  digitalWrite(GREEN_LED_PIN, LOW);
}

void startRedBlink(int times) {
  redBlink.remaining  = times * 2;
  redBlink.isOn       = false;
  redBlink.lastToggle = millis();
  digitalWrite(RED_LED_PIN, LOW);
}

void updateLedBlinks(unsigned long now) {
  updateOneBlink(greenBlink, now);
  updateOneBlink(redBlink, now);
}

void updateOneBlink(LedBlink &blink, unsigned long now) {
  if (blink.remaining <= 0) return;

  if (now - blink.lastToggle >= BLINK_DURATION) {
    blink.lastToggle = now;
    blink.isOn = !blink.isOn;
    digitalWrite(blink.pin, blink.isOn ? HIGH : LOW);
    if (!blink.isOn) {
      blink.remaining -= 2;
    }
  }
}

// ============================================================
// ST7735S LCD Functions
// ============================================================
void initLCD() {
  tft.initR(INITR_BLACKTAB);
  tft.setRotation(1);
  tft.fillScreen(CLR_BG);
  tft.setTextWrap(true);
}

void lcdShowSplash() {
  tft.fillScreen(CLR_BG);

  tft.setTextSize(2);
  tft.setTextColor(CLR_INFO);
  tft.setCursor(20, 30);
  tft.print("BioTrack");

  tft.setTextSize(1);
  tft.setTextColor(CLR_MUTED);
  tft.setCursor(15, 55);
  tft.print("Attendance System");

  tft.setCursor(15, 80);
  tft.setTextColor(CLR_TEXT);
  tft.print("Initializing...");

  delay(500);
}

void lcdShowAttendanceReady() {
  tft.fillScreen(CLR_BG);
  lcdDrawHeader();

  tft.setTextSize(2);
  tft.setTextColor(CLR_OK);
  tft.setCursor(10, 45);
  tft.print("ATTENDANCE");

  tft.setTextSize(1);
  tft.setTextColor(CLR_TEXT);
  tft.setCursor(10, 75);
  tft.print("Place finger to scan");

  lcdDrawStatusBar();
}

void lcdShowEnrollReady() {
  tft.fillScreen(CLR_BG);
  lcdDrawHeader();

  tft.setTextSize(2);
  tft.setTextColor(CLR_WARN);
  tft.setCursor(10, 45);
  tft.print("ENROLL MODE");

  tft.setTextSize(1);
  tft.setTextColor(CLR_TEXT);
  tft.setCursor(10, 75);
  tft.print("Place new finger...");

  lcdDrawStatusBar();
}

void lcdShowEnrollStep(String msg, int slotId) {
  tft.fillRect(0, 40, 160, 50, CLR_BG);

  tft.setTextSize(1);
  tft.setTextColor(CLR_WARN);
  tft.setCursor(10, 45);
  tft.print("Enroll -> Slot #" + String(slotId));

  tft.setTextColor(CLR_TEXT);
  tft.setCursor(10, 65);
  tft.print(msg);
}

void lcdFlash(String msg, uint16_t color) {
  tft.fillRect(0, 95, 160, 20, CLR_BG);

  tft.setTextSize(1);
  tft.setTextColor(color);
  tft.setCursor(5, 98);
  tft.print(msg);
}

void lcdStatus(String msg, uint16_t color) {
  tft.fillRect(0, 110, 160, 18, CLR_BG);

  tft.setTextSize(1);
  tft.setTextColor(color);
  tft.setCursor(5, 113);
  tft.print(msg);
}

void lcdDrawHeader() {
  tft.fillRect(0, 0, 160, 20, CLR_HEADER);
  tft.setTextSize(1);
  tft.setTextColor(CLR_TEXT);
  tft.setCursor(5, 6);
  tft.print("BioTrack");

  tft.setCursor(90, 6);
  if (isConnected) {
    tft.setTextColor(CLR_OK);
    tft.print("WiFi OK");
  } else {
    tft.setTextColor(CLR_ERR);
    tft.print("No WiFi");
  }

  tft.fillRect(0, 20, 160, 2, CLR_INFO);
}

void lcdDrawStatusBar() {
  tft.fillRect(0, 115, 160, 13, CLR_HEADER);
  tft.setTextSize(1);
  tft.setTextColor(CLR_MUTED);
  tft.setCursor(5, 117);

  if (timeReady) {
    struct tm timeinfo;
    if (getLocalTime(&timeinfo, 100)) {
      char buf[20];
      strftime(buf, sizeof(buf), "%H:%M:%S", &timeinfo);
      tft.print(buf);
    }
  } else {
    tft.setTextColor(CLR_WARN);
    tft.print("No time sync");
  }

  tft.setCursor(100, 117);
  tft.setTextColor(CLR_MUTED);
  tft.print(currentMode == "enroll" ? "ENR" : "ATT");
}

void lcdUpdateClock() {
  lcdDrawStatusBar();
}

void lcdUpdateMode() {
  lcdDrawHeader();
  lcdDrawStatusBar();
}
`;

const WIRING_DIAGRAM = `
ESP32 DevKit Pin Layout & Connections
======================================

  +----------------------------------+
  |          ESP32 DevKit            |
  |                                  |
  |  3V3 ---------> R307 VCC (Red)   |
  |  3V3 ---------> ST7735S VCC     |
  |  GND ---------> R307 GND (Black) |
  |  GND ---------> ST7735S GND     |
  |                                  |
  |  -- R307 Fingerprint (UART2) --  |
  |  GPIO16 (RX2) -> R307 TX (Yel)  |
  |  GPIO17 (TX2) -> R307 RX (Grn)  |
  |                                  |
  |  -- ST7735S LCD (SPI) --        |
  |  GPIO18 (SCLK) -> ST7735S SCL   |
  |  GPIO23 (MOSI) -> ST7735S SDA   |
  |  GPIO5  (CS)   -> ST7735S CS    |
  |  GPIO26 (DC)   -> ST7735S DC    |
  |  GPIO27 (RST)  -> ST7735S RST   |
  |  3V3 -----------> ST7735S BLK   |
  |                                  |
  |  -- LEDs --                     |
  |  GPIO2  --[220R]--> Green LED    |
  |  GPIO4  --[220R]--> Red LED      |
  |  GPIO15 --[220R]--> Status LED   |
  |                                  |
  +----------------------------------+

R307 Fingerprint Sensor (6-pin connector):
  Pin 1 (Red)    = VCC  --> ESP32 3V3
  Pin 2 (Black)  = GND  --> ESP32 GND
  Pin 3 (Yellow) = TX   --> ESP32 GPIO16 (RX2)
  Pin 4 (Green)  = RX   --> ESP32 GPIO17 (TX2)
  Pin 5, 6       = Not Connected

ST7735S LCD (8-pin header):
  GND  --> ESP32 GND
  VCC  --> ESP32 3V3
  SCL  --> ESP32 GPIO18 (SPI Clock)
  SDA  --> ESP32 GPIO23 (SPI MOSI)
  RES  --> ESP32 GPIO27 (Reset)
  DC   --> ESP32 GPIO26 (Data/Command)
  CS   --> ESP32 GPIO5  (Chip Select)
  BLK  --> ESP32 3V3   (Backlight)

LED Circuit (each LED):
  ESP32 GPIO --[220 ohm]--|>|-- GND
                         LED
              (longer leg = anode, shorter = cathode)
`;

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    await navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <Button variant="outline" size="sm" onClick={handleCopy} data-testid="button-copy-code">
      {copied ? <Check className="h-4 w-4 mr-1" /> : <Copy className="h-4 w-4 mr-1" />}
      {copied ? "Copied" : "Copy"}
    </Button>
  );
}

function useUserRole() {
  return useQuery<{ role: string }>({
    queryKey: ["/api/auth/role"],
    queryFn: async () => {
      const res = await fetch("/api/auth/role", { credentials: "include" });
      if (!res.ok) return { role: "viewer" };
      return res.json();
    },
  });
}

export default function Settings() {
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [resetDialogOpen, setResetDialogOpen] = useState(false);
  const [confirmText, setConfirmText] = useState("");
  const { data: roleData } = useUserRole();
  const isAdmin = roleData?.role === "admin";

  const [selectedUserId, setSelectedUserId] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);

  const [smtpHost, setSmtpHost] = useState("");
  const [smtpPort, setSmtpPort] = useState("");
  const [smtpUser, setSmtpUser] = useState("");
  const [smtpPass, setSmtpPass] = useState("");
  const [smtpFromName, setSmtpFromName] = useState("");

  const { data: smtpData, isLoading: smtpLoading } = useQuery<{
    host: string; port: string; user: string; pass: string; fromName: string; configured: boolean;
  }>({
    queryKey: ["/api/settings/smtp"],
    queryFn: async () => {
      const res = await fetch("/api/settings/smtp", { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch SMTP settings");
      return res.json();
    },
    enabled: isAdmin,
  });

  useEffect(() => {
    if (smtpData) {
      setSmtpHost(smtpData.host);
      setSmtpPort(smtpData.port);
      setSmtpUser(smtpData.user);
      setSmtpPass(smtpData.pass);
      setSmtpFromName(smtpData.fromName);
    }
  }, [smtpData]);

  const smtpSaveMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/settings/smtp", {
        host: smtpHost,
        port: smtpPort,
        user: smtpUser,
        pass: smtpPass,
        fromName: smtpFromName,
      });
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "SMTP settings saved", description: "Email configuration has been updated." });
    },
    onError: () => {
      toast({ title: "Failed to save", description: "Could not save SMTP settings.", variant: "destructive" });
    },
  });

  const smtpTestMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/settings/smtp/test");
      return res.json();
    },
    onSuccess: (data: any) => {
      if (data.success) {
        toast({ title: "Connection successful", description: data.message });
      } else {
        toast({ title: "Connection failed", description: data.message, variant: "destructive" });
      }
    },
    onError: () => {
      toast({ title: "Test failed", description: "Could not test SMTP connection.", variant: "destructive" });
    },
  });

  const { data: allUsers, isLoading: usersLoading } = useQuery<{ id: string; email: string; firstName: string; lastName: string; role: string }[]>({
    queryKey: ["/api/users"],
    enabled: isAdmin,
  });

  const resetPasswordMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/admin/reset-password", {
        userId: selectedUserId,
        newPassword,
      });
      return res.json();
    },
    onSuccess: (data: any) => {
      toast({ title: "Password reset", description: data.message });
      setSelectedUserId("");
      setNewPassword("");
      setShowPassword(false);
    },
    onError: (err: Error) => {
      toast({ title: "Reset failed", description: err.message, variant: "destructive" });
    },
  });

  const backupMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch("/api/settings/backup", { credentials: "include" });
      if (!res.ok) throw new Error("Backup failed");
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `biotrack_backup_${new Date().toISOString().slice(0, 10)}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    },
    onSuccess: () => {
      toast({ title: "Backup downloaded", description: "Your database backup file has been saved." });
    },
    onError: () => {
      toast({ title: "Backup failed", description: "Could not create the backup.", variant: "destructive" });
    },
  });

  const restoreMutation = useMutation({
    mutationFn: async (file: File) => {
      const text = await file.text();
      const data = JSON.parse(text);
      if (!data.tables) throw new Error("Invalid backup format");
      const res = await apiRequest("POST", "/api/settings/restore", data);
      return res.json();
    },
    onSuccess: (data: any) => {
      toast({ title: "Restore complete", description: data.message });
    },
    onError: (err: Error) => {
      toast({ title: "Restore failed", description: err.message, variant: "destructive" });
    },
  });

  const optimizeMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/settings/optimize");
      return res.json();
    },
    onSuccess: (data: any) => {
      toast({ title: "Optimization complete", description: data.message });
    },
    onError: () => {
      toast({ title: "Optimization failed", variant: "destructive" });
    },
  });

  const resetMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/settings/reset", { confirmText });
      return res.json();
    },
    onSuccess: (data: any) => {
      toast({ title: "Reset complete", description: data.message });
      setResetDialogOpen(false);
      setConfirmText("");
    },
    onError: (err: Error) => {
      toast({ title: "Reset failed", description: err.message, variant: "destructive" });
    },
  });

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      restoreMutation.mutate(file);
    }
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  return (
    <div className="space-y-4 md:space-y-6">
      <div>
        <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold tracking-tight text-foreground" data-testid="text-settings-title">
          Settings
        </h1>
        <p className="text-muted-foreground mt-1">ESP32 device setup, email, and database management</p>
      </div>

      <Tabs defaultValue="esp32" className="space-y-4">
        <div className="w-full overflow-x-auto">
          <TabsList className="inline-flex w-auto min-w-full md:min-w-0 gap-1">
            <TabsTrigger value="esp32" className="text-xs md:text-sm gap-1 md:gap-2 flex-1 md:flex-none" data-testid="tab-esp32">
              <CircuitBoard className="h-3.5 w-3.5 md:h-4 md:w-4 flex-shrink-0" />
              <span className="hidden md:inline">ESP32 Setup</span>
              <span className="md:hidden">ESP32</span>
            </TabsTrigger>
            {isAdmin && (
              <TabsTrigger value="passwords" className="text-xs md:text-sm gap-1 md:gap-2 flex-1 md:flex-none" data-testid="tab-passwords">
                <KeyRound className="h-3.5 w-3.5 md:h-4 md:w-4 flex-shrink-0" />
                <span className="truncate">Passwords</span>
              </TabsTrigger>
            )}
            {isAdmin && (
              <TabsTrigger value="smtp" className="text-xs md:text-sm gap-1 md:gap-2 flex-1 md:flex-none" data-testid="tab-smtp">
                <Mail className="h-3.5 w-3.5 md:h-4 md:w-4 flex-shrink-0" />
                <span className="truncate">Email</span>
              </TabsTrigger>
            )}
            {isAdmin && (
              <TabsTrigger value="database" className="text-xs md:text-sm gap-1 md:gap-2 flex-1 md:flex-none" data-testid="tab-database">
                <Database className="h-3.5 w-3.5 md:h-4 md:w-4 flex-shrink-0" />
                <span className="truncate">DB</span>
              </TabsTrigger>
            )}
          </TabsList>
        </div>

        <TabsContent value="esp32" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-col md:flex-row items-start md:items-center justify-between gap-2 space-y-0">
              <div className="flex items-center gap-2">
                <FileCode className="h-5 w-5 text-blue-600 flex-shrink-0" />
                <CardTitle className="text-sm md:text-base">Arduino Code (biotrack_esp32.ino)</CardTitle>
              </div>
              <CopyButton text={ESP32_CODE} />
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-3">
                Upload this code to your ESP32. Replace the WiFi, server URL, and API key placeholders with your actual values.
              </p>
              <div className="relative">
                <pre className="bg-slate-950 text-green-400 text-xs p-4 rounded-lg overflow-auto max-h-[400px] font-mono leading-relaxed" data-testid="code-esp32">
                  {ESP32_CODE}
                </pre>
              </div>

              <div className="mt-4 space-y-2">
                <p className="text-sm font-medium text-foreground">Required Libraries (Arduino IDE):</p>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="secondary">Adafruit Fingerprint Sensor Library</Badge>
                  <Badge variant="secondary">Adafruit GFX Library</Badge>
                  <Badge variant="secondary">Adafruit ST7735 and ST7789 Library</Badge>
                  <Badge variant="secondary">WiFi (built-in)</Badge>
                  <Badge variant="secondary">HTTPClient (built-in)</Badge>
                </div>
              </div>

              <div className="mt-4 space-y-2">
                <p className="text-sm font-medium text-foreground">Configuration Steps:</p>
                <ol className="text-sm text-muted-foreground list-decimal list-inside space-y-1">
                  <li>Install Arduino IDE and add ESP32 board support</li>
                  <li>Install the required libraries (see above)</li>
                  <li>Open the code and update WiFi credentials</li>
                  <li>Set the server URL to your BioTrack app URL</li>
                  <li>Set the API key from the Devices page</li>
                  <li>Adjust GMT_OFFSET and DST_OFFSET for your timezone</li>
                  <li>Select board: "ESP32 Dev Module"</li>
                  <li>Upload and open Serial Monitor at 115200 baud</li>
                </ol>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-col md:flex-row items-start md:items-center justify-between gap-2 space-y-0">
              <div className="flex items-center gap-2">
                <Cpu className="h-5 w-5 text-purple-600 flex-shrink-0" />
                <CardTitle className="text-sm md:text-base">Wiring Diagram</CardTitle>
              </div>
              <CopyButton text={WIRING_DIAGRAM} />
            </CardHeader>
            <CardContent>
              <pre className="bg-slate-950 text-amber-300 text-xs p-4 rounded-lg overflow-auto max-h-[350px] font-mono leading-relaxed" data-testid="code-wiring">
                {WIRING_DIAGRAM}
              </pre>

              <div className="mt-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
                <Card className="border-border">
                  <CardContent className="p-3">
                    <div className="flex items-center gap-2 mb-1">
                      <div className="h-3 w-3 rounded-full bg-green-500" />
                      <span className="text-sm font-medium text-foreground">Green LED (GPIO2)</span>
                    </div>
                    <p className="text-xs text-muted-foreground">Blinks when attendance is successfully recorded</p>
                  </CardContent>
                </Card>
                <Card className="border-border">
                  <CardContent className="p-3">
                    <div className="flex items-center gap-2 mb-1">
                      <div className="h-3 w-3 rounded-full bg-red-500" />
                      <span className="text-sm font-medium text-foreground">Red LED (GPIO4)</span>
                    </div>
                    <p className="text-xs text-muted-foreground">Blinks when fingerprint is not recognized or an error occurs</p>
                  </CardContent>
                </Card>
                <Card className="border-border">
                  <CardContent className="p-3">
                    <div className="flex items-center gap-2 mb-1">
                      <div className="h-3 w-3 rounded-full bg-blue-500" />
                      <span className="text-sm font-medium text-foreground">Status LED (GPIO15)</span>
                    </div>
                    <p className="text-xs text-muted-foreground">Solid ON = device connected, OFF = offline, Blinking = connecting</p>
                  </CardContent>
                </Card>
                <Card className="border-border">
                  <CardContent className="p-3">
                    <div className="flex items-center gap-2 mb-1">
                      <div className="h-3 w-3 rounded-full bg-cyan-500" />
                      <span className="text-sm font-medium text-foreground">ST7735S LCD (SPI)</span>
                    </div>
                    <p className="text-xs text-muted-foreground">Shows mode, scan results, WiFi status, clock, and enrollment steps</p>
                  </CardContent>
                </Card>
              </div>

              <div className="mt-4">
                <p className="text-sm font-medium text-foreground mb-2">Pin Summary:</p>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm text-left">
                    <thead>
                      <tr className="border-b border-border">
                        <th className="py-2 px-3 font-medium text-muted-foreground">ESP32 Pin</th>
                        <th className="py-2 px-3 font-medium text-muted-foreground">Connected To</th>
                        <th className="py-2 px-3 font-medium text-muted-foreground">Purpose</th>
                      </tr>
                    </thead>
                    <tbody className="text-foreground">
                      <tr className="border-b border-border"><td className="py-2 px-3">3V3</td><td className="py-2 px-3">R307 VCC (Red)</td><td className="py-2 px-3">Sensor power</td></tr>
                      <tr className="border-b border-border"><td className="py-2 px-3">GND</td><td className="py-2 px-3">R307 GND (Black)</td><td className="py-2 px-3">Common ground</td></tr>
                      <tr className="border-b border-border"><td className="py-2 px-3">GPIO16</td><td className="py-2 px-3">R307 TX (Yellow)</td><td className="py-2 px-3">Receive from sensor</td></tr>
                      <tr className="border-b border-border"><td className="py-2 px-3">GPIO17</td><td className="py-2 px-3">R307 RX (Green)</td><td className="py-2 px-3">Send to sensor</td></tr>
                      <tr className="border-b border-border"><td className="py-2 px-3">GPIO2</td><td className="py-2 px-3">Green LED</td><td className="py-2 px-3">OK attendance</td></tr>
                      <tr className="border-b border-border"><td className="py-2 px-3">GPIO4</td><td className="py-2 px-3">Red LED</td><td className="py-2 px-3">Scan error</td></tr>
                      <tr className="border-b border-border"><td className="py-2 px-3">GPIO15</td><td className="py-2 px-3">Status LED</td><td className="py-2 px-3">Device on/off</td></tr>
                      <tr className="border-b border-border"><td className="py-2 px-3">GPIO18</td><td className="py-2 px-3">ST7735S SCL</td><td className="py-2 px-3">SPI clock</td></tr>
                      <tr className="border-b border-border"><td className="py-2 px-3">GPIO23</td><td className="py-2 px-3">ST7735S SDA</td><td className="py-2 px-3">SPI data out</td></tr>
                      <tr className="border-b border-border"><td className="py-2 px-3">GPIO5</td><td className="py-2 px-3">ST7735S CS</td><td className="py-2 px-3">SPI chip select</td></tr>
                      <tr className="border-b border-border"><td className="py-2 px-3">GPIO26</td><td className="py-2 px-3">ST7735S DC</td><td className="py-2 px-3">Data/command</td></tr>
                      <tr><td className="py-2 px-3">GPIO27</td><td className="py-2 px-3">ST7735S RST</td><td className="py-2 px-3">LCD reset</td></tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {isAdmin && <TabsContent value="passwords" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <KeyRound className="h-5 w-5 text-amber-600" />
                <CardTitle className="text-base">Reset User Password</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                If a viewer or manager has forgotten their password, you can reset it here. Select the user and set a new password for them.
              </p>

              {usersLoading ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="reset-user">Select User</Label>
                    <Select value={selectedUserId} onValueChange={setSelectedUserId}>
                      <SelectTrigger data-testid="select-reset-user">
                        <SelectValue placeholder="Choose a user..." />
                      </SelectTrigger>
                      <SelectContent>
                        {allUsers?.filter(u => u.role !== 'admin').map((user) => (
                          <SelectItem key={user.id} value={user.id} data-testid={`select-user-${user.id}`}>
                            <span className="flex items-center gap-2">
                              <span>{user.firstName} {user.lastName}</span>
                              <span className="text-muted-foreground">({user.email})</span>
                              <span className="text-xs text-muted-foreground capitalize">- {user.role}</span>
                            </span>
                          </SelectItem>
                        ))}
                        {allUsers?.filter(u => u.role !== 'admin').length === 0 && (
                          <div className="px-3 py-2 text-sm text-muted-foreground">No non-admin users found</div>
                        )}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="new-password">New Password</Label>
                    <div className="relative">
                      <Input
                        id="new-password"
                        type={showPassword ? "text" : "password"}
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        placeholder="Enter new password (min 6 characters)"
                        className="pr-10"
                        data-testid="input-new-password"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                        data-testid="button-toggle-password"
                      >
                        {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                    </div>
                    <p className="text-xs text-muted-foreground">Minimum 6 characters</p>
                  </div>

                  <Button
                    onClick={() => resetPasswordMutation.mutate()}
                    disabled={!selectedUserId || newPassword.length < 6 || resetPasswordMutation.isPending}
                    className="w-full sm:w-auto"
                    data-testid="button-reset-password"
                  >
                    {resetPasswordMutation.isPending ? (
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    ) : (
                      <KeyRound className="h-4 w-4 mr-2" />
                    )}
                    Reset Password
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>}

        {isAdmin && <TabsContent value="smtp" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <Mail className="h-5 w-5 text-blue-600" />
                <CardTitle className="text-base">SMTP Email Configuration</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              {smtpLoading ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
                </div>
              ) : (
                <div className="space-y-4">
                  <p className="text-sm text-muted-foreground">
                    Configure the SMTP server used to send invitation emails. Changes here override default environment settings.
                  </p>

                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="smtp-host">SMTP Host</Label>
                      <Input
                        id="smtp-host"
                        value={smtpHost}
                        onChange={(e) => setSmtpHost(e.target.value)}
                        placeholder="smtp.gmail.com"
                        data-testid="input-smtp-host"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="smtp-port">SMTP Port</Label>
                      <Input
                        id="smtp-port"
                        value={smtpPort}
                        onChange={(e) => setSmtpPort(e.target.value)}
                        placeholder="587"
                        data-testid="input-smtp-port"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="smtp-user">Email Address</Label>
                      <Input
                        id="smtp-user"
                        type="email"
                        value={smtpUser}
                        onChange={(e) => setSmtpUser(e.target.value)}
                        placeholder="your-email@gmail.com"
                        data-testid="input-smtp-user"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="smtp-pass">Password / App Password</Label>
                      <Input
                        id="smtp-pass"
                        type="password"
                        value={smtpPass}
                        onChange={(e) => setSmtpPass(e.target.value)}
                        placeholder="Enter password"
                        data-testid="input-smtp-pass"
                      />
                    </div>
                    <div className="space-y-2 md:col-span-2">
                      <Label htmlFor="smtp-from-name">Sender Name</Label>
                      <Input
                        id="smtp-from-name"
                        value={smtpFromName}
                        onChange={(e) => setSmtpFromName(e.target.value)}
                        placeholder="BioTrack"
                        data-testid="input-smtp-from-name"
                      />
                      <p className="text-xs text-muted-foreground">Name shown in the "From" field of emails</p>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-3 pt-2">
                    <Button
                      onClick={() => smtpSaveMutation.mutate()}
                      disabled={smtpSaveMutation.isPending}
                      data-testid="button-save-smtp"
                    >
                      {smtpSaveMutation.isPending ? (
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      ) : (
                        <Check className="h-4 w-4 mr-2" />
                      )}
                      Save Settings
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => smtpTestMutation.mutate()}
                      disabled={smtpTestMutation.isPending}
                      data-testid="button-test-smtp"
                    >
                      {smtpTestMutation.isPending ? (
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      ) : (
                        <Send className="h-4 w-4 mr-2" />
                      )}
                      Test Connection
                    </Button>
                  </div>

                  {smtpData?.configured && (
                    <div className="flex items-center gap-2 pt-2">
                      <div className="h-2 w-2 rounded-full bg-green-500" />
                      <span className="text-sm text-muted-foreground">Email sending is configured</span>
                    </div>
                  )}
                  {smtpData && !smtpData.configured && (
                    <div className="flex items-center gap-2 pt-2">
                      <div className="h-2 w-2 rounded-full bg-amber-500" />
                      <span className="text-sm text-muted-foreground">Email sending is not configured yet</span>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>}

        {isAdmin && <TabsContent value="database" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Download className="h-5 w-5 text-blue-600" />
                  <CardTitle className="text-base">Create Backup</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-sm text-muted-foreground">
                  Download a full backup of all your data as a JSON file. This includes classes, students, devices, attendance records, and user roles.
                </p>
                <Button
                  onClick={() => backupMutation.mutate()}
                  disabled={backupMutation.isPending}
                  className="w-full"
                  data-testid="button-download-backup"
                >
                  {backupMutation.isPending ? (
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <Download className="h-4 w-4 mr-2" />
                  )}
                  Download Backup
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Upload className="h-5 w-5 text-green-600" />
                  <CardTitle className="text-base">Upload Backup</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-sm text-muted-foreground">
                  Restore your data from a previously downloaded backup file. This will replace all existing data with the backup contents.
                </p>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".json"
                  onChange={handleFileUpload}
                  className="hidden"
                  data-testid="input-upload-backup"
                />
                <Button
                  variant="outline"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={restoreMutation.isPending}
                  className="w-full"
                  data-testid="button-upload-backup"
                >
                  {restoreMutation.isPending ? (
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <Upload className="h-4 w-4 mr-2" />
                  )}
                  Upload Backup
                </Button>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-amber-600" />
                  <CardTitle className="text-base">Optimize Database</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-sm text-muted-foreground">
                  Cleans up unused space and rebuilds indexes for better performance. Safe to run anytime.
                </p>
                <Button
                  variant="outline"
                  onClick={() => optimizeMutation.mutate()}
                  disabled={optimizeMutation.isPending}
                  className="w-full"
                  data-testid="button-optimize-db"
                >
                  {optimizeMutation.isPending ? (
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <Zap className="h-4 w-4 mr-2" />
                  )}
                  Optimize Database
                </Button>
              </CardContent>
            </Card>

            <Card className="border-red-200 dark:border-red-900">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <Trash2 className="h-5 w-5 text-red-600 dark:text-red-400" />
                  <CardTitle className="text-base text-red-700 dark:text-red-400">Reset Database</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-sm text-muted-foreground">
                  Permanently deletes all classes, students, devices, and attendance records. User accounts are kept.
                </p>
                <Button
                  variant="destructive"
                  onClick={() => setResetDialogOpen(true)}
                  className="w-full"
                  data-testid="button-reset-db"
                >
                  <AlertTriangle className="h-4 w-4 mr-2" />
                  Reset Database
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>}
      </Tabs>

      <Dialog open={resetDialogOpen} onOpenChange={setResetDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="text-red-700 dark:text-red-400 flex items-center gap-2">
              <AlertTriangle className="h-5 w-5" />
              Reset Database
            </DialogTitle>
            <DialogDescription>
              This will permanently delete all classes, students, devices, and attendance records.
              This action cannot be undone. Type <strong>RESET</strong> below to confirm.
            </DialogDescription>
          </DialogHeader>
          <Input
            value={confirmText}
            onChange={(e) => setConfirmText(e.target.value)}
            placeholder="Type RESET to confirm"
            data-testid="input-confirm-reset"
          />
          <DialogFooter>
            <Button variant="outline" onClick={() => { setResetDialogOpen(false); setConfirmText(""); }}>
              Cancel
            </Button>
            <Button
              variant="destructive"
              disabled={confirmText !== "RESET" || resetMutation.isPending}
              onClick={() => resetMutation.mutate()}
              data-testid="button-confirm-reset"
            >
              {resetMutation.isPending ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <Trash2 className="h-4 w-4 mr-2" />
              )}
              Confirm Reset
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
