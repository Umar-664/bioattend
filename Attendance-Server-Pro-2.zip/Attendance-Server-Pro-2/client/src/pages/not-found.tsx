import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileQuestion, Home } from "lucide-react";
import { useLocation } from "wouter";

export default function NotFound() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-background px-4">
      <Card className="w-full max-w-md">
        <CardContent className="pt-8 pb-8 text-center">
          <div className="bg-muted p-4 rounded-full w-fit mx-auto mb-6">
            <FileQuestion className="h-10 w-10 text-muted-foreground" />
          </div>

          <h1 className="text-3xl font-bold text-foreground mb-2" data-testid="text-404-title">
            404
          </h1>
          <p className="text-lg font-medium text-foreground mb-1">
            Page Not Found
          </p>
          <p className="text-sm text-muted-foreground mb-6">
            The page you're looking for doesn't exist or has been moved.
          </p>

          <Button
            onClick={() => setLocation("/")}
            className="w-full sm:w-auto"
            data-testid="button-go-home"
          >
            <Home className="mr-2 h-4 w-4" />
            Back to Dashboard
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
