import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Fingerprint, Loader2, Eye, EyeOff, ArrowLeft, Mail, RefreshCw, BookOpen, KeyRound, Lock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";

interface PublicClass {
  id: number;
  name: string;
  departmentId: number | null;
}

export default function Login() {
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const [selectedClassId, setSelectedClassId] = useState<string>("");
  const [inviteCode, setInviteCode] = useState("");
  const [rollNumber, setRollNumber] = useState("");
  const [useInviteCode, setUseInviteCode] = useState(false);
  const [publicClasses, setPublicClasses] = useState<PublicClass[]>([]);
  const [resolvedClass, setResolvedClass] = useState<PublicClass | null>(null);

  const [verifyStep, setVerifyStep] = useState(false);
  const [verifyEmail, setVerifyEmail] = useState("");
  const [otpDigits, setOtpDigits] = useState(["", "", "", "", "", ""]);
  const [resendCooldown, setResendCooldown] = useState(0);
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  const [forgotStep, setForgotStep] = useState<"email" | "code" | null>(null);
  const [forgotEmail, setForgotEmail] = useState("");
  const [resetOtpDigits, setResetOtpDigits] = useState(["", "", "", "", "", ""]);
  const [newPassword, setNewPassword] = useState("");
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [resetCooldown, setResetCooldown] = useState(0);
  const resetInputRefs = useRef<(HTMLInputElement | null)[]>([]);

  const { toast } = useToast();
  const queryClient = useQueryClient();

  useEffect(() => {
    if (isSignUp) {
      fetch("/api/public/classes")
        .then(res => res.json())
        .then(data => setPublicClasses(data))
        .catch(() => {});
    }
  }, [isSignUp]);

  useEffect(() => {
    if (resendCooldown > 0) {
      const timer = setTimeout(() => setResendCooldown(resendCooldown - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [resendCooldown]);

  useEffect(() => {
    if (verifyStep && inputRefs.current[0]) {
      inputRefs.current[0]?.focus();
    }
  }, [verifyStep]);

  useEffect(() => {
    if (resetCooldown > 0) {
      const timer = setTimeout(() => setResetCooldown(resetCooldown - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [resetCooldown]);

  useEffect(() => {
    if (forgotStep === "code" && resetInputRefs.current[0]) {
      resetInputRefs.current[0]?.focus();
    }
  }, [forgotStep]);

  useEffect(() => {
    if (!useInviteCode || inviteCode.length !== 6) {
      setResolvedClass(null);
      return;
    }
    const code = inviteCode.toUpperCase();
    const timer = setTimeout(async () => {
      try {
        const res = await fetch(`/api/public/invite-code/${code}`);
        if (res.ok) {
          const cls = await res.json();
          setResolvedClass(cls);
        } else {
          setResolvedClass(null);
        }
      } catch {
        setResolvedClass(null);
      }
    }, 500);
    return () => clearTimeout(timer);
  }, [inviteCode, useInviteCode]);

  const handleOtpChange = (index: number, value: string) => {
    if (value.length > 1) {
      const digits = value.replace(/\D/g, "").split("").slice(0, 6);
      const newOtp = [...otpDigits];
      digits.forEach((d, i) => {
        if (index + i < 6) newOtp[index + i] = d;
      });
      setOtpDigits(newOtp);
      const nextIndex = Math.min(index + digits.length, 5);
      inputRefs.current[nextIndex]?.focus();
      return;
    }

    if (!/^\d*$/.test(value)) return;

    const newOtp = [...otpDigits];
    newOtp[index] = value;
    setOtpDigits(newOtp);

    if (value && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }
  };

  const handleOtpKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === "Backspace" && !otpDigits[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  const getSelectedClassId = (): number | undefined => {
    if (useInviteCode && resolvedClass) return resolvedClass.id;
    if (!useInviteCode && selectedClassId && selectedClassId !== "none") {
      const num = Number(selectedClassId);
      if (!isNaN(num)) return num;
    }
    return undefined;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      if (isSignUp) {
        const classId = getSelectedClassId();
        if (classId && !rollNumber.trim()) {
          toast({
            title: "Roll number required",
            description: "Please enter your roll number when selecting a class",
            variant: "destructive",
          });
          setIsLoading(false);
          return;
        }

        const body: any = { email, password, firstName, lastName };
        if (classId) {
          body.classId = classId;
          body.rollNumber = rollNumber.trim();
        }

        const res = await fetch("/api/auth/register", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body),
          credentials: "include",
        });

        const data = await res.json();

        if (!res.ok) {
          toast({
            title: "Error",
            description: data.message || "Something went wrong",
            variant: "destructive",
          });
          return;
        }

        if (data.requiresVerification) {
          setVerifyEmail(data.email);
          setVerifyStep(true);
          setResendCooldown(60);
          toast({
            title: "Check your email",
            description: data.message,
          });
        }
      } else {
        const res = await fetch("/api/auth/login", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email, password }),
          credentials: "include",
        });

        const data = await res.json();

        if (!res.ok) {
          toast({
            title: "Error",
            description: data.message || "Something went wrong",
            variant: "destructive",
          });
          return;
        }

        await queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
        window.location.href = "/";
      }
    } catch (err) {
      toast({
        title: "Error",
        description: "Network error. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    const code = otpDigits.join("");
    if (code.length !== 6) {
      toast({
        title: "Error",
        description: "Please enter the complete 6-digit code",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    try {
      const res = await fetch("/api/auth/verify-email", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: verifyEmail, code }),
        credentials: "include",
      });

      const data = await res.json();

      if (!res.ok) {
        toast({
          title: "Error",
          description: data.message || "Verification failed",
          variant: "destructive",
        });
        return;
      }

      toast({
        title: "Account created!",
        description: "Your email has been verified successfully.",
      });

      await queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      window.location.href = "/";
    } catch (err) {
      toast({
        title: "Error",
        description: "Network error. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleResendCode = async () => {
    if (resendCooldown > 0) return;

    setIsLoading(true);
    try {
      const res = await fetch("/api/auth/resend-code", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: verifyEmail }),
        credentials: "include",
      });

      const data = await res.json();

      if (!res.ok) {
        toast({
          title: "Error",
          description: data.message || "Failed to resend code",
          variant: "destructive",
        });
        if (data.message?.includes("No pending registration")) {
          setVerifyStep(false);
          setOtpDigits(["", "", "", "", "", ""]);
        }
        return;
      }

      setResendCooldown(60);
      setOtpDigits(["", "", "", "", "", ""]);
      inputRefs.current[0]?.focus();
      toast({
        title: "Code sent",
        description: data.message,
      });
    } catch (err) {
      toast({
        title: "Error",
        description: "Network error. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleResetOtpChange = (index: number, value: string) => {
    if (value.length > 1) {
      const digits = value.replace(/\D/g, "").split("").slice(0, 6);
      const newOtp = [...resetOtpDigits];
      digits.forEach((d, i) => {
        if (index + i < 6) newOtp[index + i] = d;
      });
      setResetOtpDigits(newOtp);
      const nextIndex = Math.min(index + digits.length, 5);
      resetInputRefs.current[nextIndex]?.focus();
      return;
    }
    if (!/^\d*$/.test(value)) return;
    const newOtp = [...resetOtpDigits];
    newOtp[index] = value;
    setResetOtpDigits(newOtp);
    if (value && index < 5) {
      resetInputRefs.current[index + 1]?.focus();
    }
  };

  const handleResetOtpKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === "Backspace" && !resetOtpDigits[index] && index > 0) {
      resetInputRefs.current[index - 1]?.focus();
    }
  };

  const handleForgotPasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      const res = await fetch("/api/auth/forgot-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: forgotEmail }),
        credentials: "include",
      });
      const data = await res.json();
      if (!res.ok) {
        toast({ title: "Error", description: data.message, variant: "destructive" });
        return;
      }
      setForgotStep("code");
      setResetCooldown(60);
      toast({ title: "Check your email", description: data.message });
    } catch {
      toast({ title: "Error", description: "Network error. Please try again.", variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    const code = resetOtpDigits.join("");
    if (code.length !== 6) {
      toast({ title: "Error", description: "Please enter the complete 6-digit code", variant: "destructive" });
      return;
    }
    if (newPassword.length < 6) {
      toast({ title: "Error", description: "Password must be at least 6 characters", variant: "destructive" });
      return;
    }
    setIsLoading(true);
    try {
      const res = await fetch("/api/auth/reset-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: forgotEmail, code, newPassword }),
        credentials: "include",
      });
      const data = await res.json();
      if (!res.ok) {
        toast({ title: "Error", description: data.message, variant: "destructive" });
        return;
      }
      toast({ title: "Password reset!", description: data.message });
      setForgotStep(null);
      setForgotEmail("");
      setResetOtpDigits(["", "", "", "", "", ""]);
      setNewPassword("");
    } catch {
      toast({ title: "Error", description: "Network error. Please try again.", variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  };

  const handleResendResetCode = async () => {
    if (resetCooldown > 0) return;
    setIsLoading(true);
    try {
      const res = await fetch("/api/auth/forgot-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: forgotEmail }),
        credentials: "include",
      });
      const data = await res.json();
      if (!res.ok) {
        toast({ title: "Error", description: data.message, variant: "destructive" });
        return;
      }
      setResetCooldown(60);
      setResetOtpDigits(["", "", "", "", "", ""]);
      resetInputRefs.current[0]?.focus();
      toast({ title: "Code sent", description: data.message });
    } catch {
      toast({ title: "Error", description: "Network error. Please try again.", variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  };

  const resetToSignUp = () => {
    setVerifyStep(false);
    setOtpDigits(["", "", "", "", "", ""]);
    setVerifyEmail("");
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="max-w-4xl w-full bg-card rounded-xl shadow-xl overflow-hidden flex flex-col md:flex-row">
        <div className="md:w-1/2 bg-slate-900 dark:bg-slate-950 p-8 sm:p-12 flex flex-col justify-between relative overflow-hidden min-h-[200px] md:min-h-0">
          <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
            <svg width="100%" height="100%">
              <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                <path d="M 40 0 L 0 0 0 40" fill="none" stroke="white" strokeWidth="1" />
              </pattern>
              <rect width="100%" height="100%" fill="url(#grid)" />
            </svg>
          </div>
          
          <div className="relative z-10">
            <div className="bg-white/10 w-fit p-3 rounded-md mb-6 sm:mb-8 backdrop-blur-sm border border-white/20">
              <Fingerprint className="h-7 w-7 sm:h-8 sm:w-8 text-white" />
            </div>
            <h1 className="text-3xl sm:text-4xl font-bold text-white mb-3 sm:mb-4 tracking-tight">
              BioTrack
            </h1>
            <p className="text-slate-300 text-base sm:text-lg leading-relaxed">
              Secure, efficient, and modern biometric attendance management system.
            </p>
          </div>

          <div className="relative z-10 mt-8 sm:mt-12">
            <div className="flex gap-2 mb-2 items-center">
              <div className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></div>
              <span className="text-emerald-400 text-xs font-mono">SYSTEM ONLINE</span>
            </div>
            <p className="text-slate-400 text-sm">v2.0.0 Stable Build</p>
          </div>
        </div>

        <div className="md:w-1/2 p-8 sm:p-12 flex flex-col justify-center items-center overflow-y-auto max-h-[80vh] md:max-h-none">
          <div className="w-full max-w-sm space-y-6">
            {forgotStep === "code" ? (
              <>
                <div className="text-center">
                  <div className="mx-auto w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                    <Lock className="h-6 w-6 text-primary" />
                  </div>
                  <h2 className="text-xl sm:text-2xl font-bold text-foreground" data-testid="text-reset-title">
                    Reset Password
                  </h2>
                  <p className="text-muted-foreground mt-2 text-sm">
                    Enter the 6-digit code sent to
                  </p>
                  <p className="text-foreground font-medium text-sm" data-testid="text-reset-email">
                    {forgotEmail}
                  </p>
                </div>

                <form onSubmit={handleResetPassword} className="space-y-4">
                  <div className="flex justify-center gap-2" data-testid="reset-otp-input-group">
                    {resetOtpDigits.map((digit, i) => (
                      <Input
                        key={i}
                        ref={(el) => { resetInputRefs.current[i] = el; }}
                        type="text"
                        inputMode="numeric"
                        maxLength={1}
                        value={digit}
                        onChange={(e) => handleResetOtpChange(i, e.target.value)}
                        onKeyDown={(e) => handleResetOtpKeyDown(i, e)}
                        onPaste={(e) => {
                          e.preventDefault();
                          const pasted = e.clipboardData.getData("text").replace(/\D/g, "").slice(0, 6);
                          if (pasted) handleResetOtpChange(0, pasted);
                        }}
                        className="w-11 h-12 text-center text-lg font-bold"
                        data-testid={`input-reset-otp-${i}`}
                      />
                    ))}
                  </div>

                  <div>
                    <label className="text-sm font-medium text-foreground" htmlFor="newPassword">New Password</label>
                    <div className="relative">
                      <Input
                        id="newPassword"
                        type={showNewPassword ? "text" : "password"}
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        placeholder="At least 6 characters"
                        required
                        minLength={6}
                        data-testid="input-new-password"
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                        onClick={() => setShowNewPassword(!showNewPassword)}
                        data-testid="button-toggle-new-password"
                      >
                        {showNewPassword ? <EyeOff className="h-4 w-4 text-muted-foreground" /> : <Eye className="h-4 w-4 text-muted-foreground" />}
                      </Button>
                    </div>
                  </div>

                  <Button
                    type="submit"
                    className="w-full h-11"
                    disabled={isLoading || resetOtpDigits.join("").length !== 6 || newPassword.length < 6}
                    data-testid="button-reset-password"
                  >
                    {isLoading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
                    Reset Password
                  </Button>
                </form>

                <div className="text-center space-y-3">
                  <button
                    type="button"
                    className="text-sm text-primary hover:underline inline-flex items-center gap-1 disabled:opacity-50 disabled:cursor-not-allowed"
                    onClick={handleResendResetCode}
                    disabled={resetCooldown > 0 || isLoading}
                    data-testid="button-resend-reset-code"
                  >
                    <RefreshCw className="h-3 w-3" />
                    {resetCooldown > 0 ? `Resend code in ${resetCooldown}s` : "Resend code"}
                  </button>
                  <div>
                    <button
                      type="button"
                      className="text-sm text-muted-foreground hover:text-foreground inline-flex items-center gap-1"
                      onClick={() => {
                        setForgotStep(null);
                        setResetOtpDigits(["", "", "", "", "", ""]);
                        setNewPassword("");
                      }}
                      data-testid="button-back-to-login"
                    >
                      <ArrowLeft className="h-3 w-3" />
                      Back to sign in
                    </button>
                  </div>
                </div>
              </>
            ) : forgotStep === "email" ? (
              <>
                <div className="text-center">
                  <div className="mx-auto w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                    <Mail className="h-6 w-6 text-primary" />
                  </div>
                  <h2 className="text-xl sm:text-2xl font-bold text-foreground" data-testid="text-forgot-title">
                    Forgot Password
                  </h2>
                  <p className="text-muted-foreground mt-2 text-sm">
                    Enter your email to receive a reset code
                  </p>
                </div>

                <form onSubmit={handleForgotPasswordSubmit} className="space-y-4">
                  <div>
                    <label className="text-sm font-medium text-foreground" htmlFor="forgotEmail">Email</label>
                    <Input
                      id="forgotEmail"
                      type="email"
                      value={forgotEmail}
                      onChange={(e) => setForgotEmail(e.target.value)}
                      placeholder="you@example.com"
                      required
                      data-testid="input-forgot-email"
                    />
                  </div>

                  <Button
                    type="submit"
                    className="w-full h-11"
                    disabled={isLoading || !forgotEmail}
                    data-testid="button-send-reset-code"
                  >
                    {isLoading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
                    Send Reset Code
                  </Button>
                </form>

                <div className="text-center">
                  <button
                    type="button"
                    className="text-sm text-muted-foreground hover:text-foreground inline-flex items-center gap-1"
                    onClick={() => {
                      setForgotStep(null);
                      setForgotEmail("");
                    }}
                    data-testid="button-back-from-forgot"
                  >
                    <ArrowLeft className="h-3 w-3" />
                    Back to sign in
                  </button>
                </div>
              </>
            ) : verifyStep ? (
              <>
                <div className="text-center">
                  <div className="mx-auto w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                    <Mail className="h-6 w-6 text-primary" />
                  </div>
                  <h2 className="text-xl sm:text-2xl font-bold text-foreground" data-testid="text-verify-title">
                    Verify your email
                  </h2>
                  <p className="text-muted-foreground mt-2 text-sm">
                    We sent a 6-digit code to
                  </p>
                  <p className="text-foreground font-medium text-sm" data-testid="text-verify-email">
                    {verifyEmail}
                  </p>
                </div>

                <form onSubmit={handleVerifyOtp} className="space-y-6">
                  <div className="flex justify-center gap-2" data-testid="otp-input-group">
                    {otpDigits.map((digit, i) => (
                      <Input
                        key={i}
                        ref={(el) => { inputRefs.current[i] = el; }}
                        type="text"
                        inputMode="numeric"
                        maxLength={1}
                        value={digit}
                        onChange={(e) => handleOtpChange(i, e.target.value)}
                        onKeyDown={(e) => handleOtpKeyDown(i, e)}
                        onPaste={(e) => {
                          e.preventDefault();
                          const pasted = e.clipboardData.getData("text").replace(/\D/g, "").slice(0, 6);
                          if (pasted) handleOtpChange(0, pasted);
                        }}
                        className="w-11 h-12 text-center text-lg font-bold"
                        data-testid={`input-otp-${i}`}
                      />
                    ))}
                  </div>

                  <Button
                    type="submit"
                    className="w-full h-11"
                    disabled={isLoading || otpDigits.join("").length !== 6}
                    data-testid="button-verify-otp"
                  >
                    {isLoading ? (
                      <Loader2 className="h-4 w-4 animate-spin mr-2" />
                    ) : null}
                    Verify & Create Account
                  </Button>
                </form>

                <div className="text-center space-y-3">
                  <button
                    type="button"
                    className="text-sm text-primary hover:underline inline-flex items-center gap-1 disabled:opacity-50 disabled:cursor-not-allowed"
                    onClick={handleResendCode}
                    disabled={resendCooldown > 0 || isLoading}
                    data-testid="button-resend-code"
                  >
                    <RefreshCw className="h-3 w-3" />
                    {resendCooldown > 0 ? `Resend code in ${resendCooldown}s` : "Resend code"}
                  </button>
                  <div>
                    <button
                      type="button"
                      className="text-sm text-muted-foreground hover:text-foreground inline-flex items-center gap-1"
                      onClick={resetToSignUp}
                      data-testid="button-back-to-signup"
                    >
                      <ArrowLeft className="h-3 w-3" />
                      Back to sign up
                    </button>
                  </div>
                </div>
              </>
            ) : (
              <>
                <div className="text-center">
                  <h2 className="text-xl sm:text-2xl font-bold text-foreground" data-testid="text-auth-title">
                    {isSignUp ? "Create Account" : "Welcome Back"}
                  </h2>
                  <p className="text-muted-foreground mt-2">
                    {isSignUp ? "Sign up to get started" : "Sign in to access your dashboard"}
                  </p>
                </div>

                <form onSubmit={handleSubmit} className="space-y-4">
                  {isSignUp && (
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-sm font-medium text-foreground" htmlFor="firstName">First Name</label>
                        <Input
                          id="firstName"
                          value={firstName}
                          onChange={(e) => setFirstName(e.target.value)}
                          placeholder="John"
                          required
                          data-testid="input-first-name"
                        />
                      </div>
                      <div>
                        <label className="text-sm font-medium text-foreground" htmlFor="lastName">Last Name</label>
                        <Input
                          id="lastName"
                          value={lastName}
                          onChange={(e) => setLastName(e.target.value)}
                          placeholder="Doe"
                          required
                          data-testid="input-last-name"
                        />
                      </div>
                    </div>
                  )}

                  <div>
                    <label className="text-sm font-medium text-foreground" htmlFor="email">Email</label>
                    <Input
                      id="email"
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="you@example.com"
                      required
                      data-testid="input-email"
                    />
                  </div>

                  <div>
                    <label className="text-sm font-medium text-foreground" htmlFor="password">Password</label>
                    <div className="relative">
                      <Input
                        id="password"
                        type={showPassword ? "text" : "password"}
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder={isSignUp ? "At least 6 characters" : "Enter your password"}
                        required
                        minLength={isSignUp ? 6 : undefined}
                        data-testid="input-password"
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                        onClick={() => setShowPassword(!showPassword)}
                        data-testid="button-toggle-password"
                      >
                        {showPassword ? <EyeOff className="h-4 w-4 text-muted-foreground" /> : <Eye className="h-4 w-4 text-muted-foreground" />}
                      </Button>
                    </div>
                  </div>

                  {!isSignUp && (
                    <div className="flex justify-end -mt-1">
                      <button
                        type="button"
                        className="text-xs text-primary hover:underline"
                        onClick={() => {
                          setForgotStep("email");
                          setForgotEmail(email);
                        }}
                        data-testid="button-forgot-password"
                      >
                        Forgot password?
                      </button>
                    </div>
                  )}

                  {isSignUp && (
                    <div className="space-y-3 border border-border rounded-lg p-3 bg-muted/30">
                      <div className="flex items-center justify-between">
                        <label className="text-sm font-medium text-foreground flex items-center gap-1.5">
                          <BookOpen className="h-3.5 w-3.5" />
                          Join a Class
                          <span className="text-xs text-muted-foreground font-normal">(optional)</span>
                        </label>
                        <button
                          type="button"
                          className="text-xs text-primary hover:underline flex items-center gap-1"
                          onClick={() => {
                            setUseInviteCode(!useInviteCode);
                            setSelectedClassId("");
                            setInviteCode("");
                            setResolvedClass(null);
                          }}
                          data-testid="button-toggle-invite-mode"
                        >
                          {useInviteCode ? (
                            <>
                              <BookOpen className="h-3 w-3" />
                              Browse classes
                            </>
                          ) : (
                            <>
                              <KeyRound className="h-3 w-3" />
                              Have an invite code?
                            </>
                          )}
                        </button>
                      </div>

                      {useInviteCode ? (
                        <div>
                          <Input
                            value={inviteCode}
                            onChange={(e) => setInviteCode(e.target.value.toUpperCase())}
                            placeholder="Enter class invite code"
                            maxLength={8}
                            data-testid="input-invite-code"
                          />
                          {resolvedClass && (
                            <p className="text-xs text-emerald-600 dark:text-emerald-400 mt-1" data-testid="text-resolved-class">
                              Class: {resolvedClass.name}
                            </p>
                          )}
                          {inviteCode.length === 6 && !resolvedClass && (
                            <p className="text-xs text-destructive mt-1">Invalid invite code</p>
                          )}
                        </div>
                      ) : (
                        <Select value={selectedClassId} onValueChange={setSelectedClassId}>
                          <SelectTrigger data-testid="select-signup-class">
                            <SelectValue placeholder="Select a class" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="none">No class</SelectItem>
                            {publicClasses.map((cls) => (
                              <SelectItem key={cls.id} value={String(cls.id)}>
                                {cls.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      )}

                      {(getSelectedClassId()) && (
                        <div>
                          <label className="text-sm font-medium text-foreground" htmlFor="rollNumber">Roll Number</label>
                          <Input
                            id="rollNumber"
                            value={rollNumber}
                            onChange={(e) => setRollNumber(e.target.value)}
                            placeholder="e.g. 2024-001"
                            data-testid="input-roll-number"
                          />
                        </div>
                      )}
                    </div>
                  )}

                  <Button
                    type="submit"
                    className="w-full h-11"
                    disabled={isLoading}
                    data-testid="button-submit-auth"
                  >
                    {isLoading ? (
                      <Loader2 className="h-4 w-4 animate-spin mr-2" />
                    ) : null}
                    {isSignUp ? "Create Account" : "Sign In"}
                  </Button>
                </form>

                <div className="text-center">
                  <button
                    type="button"
                    className="text-sm text-primary hover:underline"
                    onClick={() => {
                      setIsSignUp(!isSignUp);
                      setEmail("");
                      setPassword("");
                      setFirstName("");
                      setLastName("");
                      setSelectedClassId("");
                      setInviteCode("");
                      setRollNumber("");
                      setResolvedClass(null);
                    }}
                    data-testid="button-toggle-auth-mode"
                  >
                    {isSignUp ? "Already have an account? Sign in" : "Don't have an account? Sign up"}
                  </button>
                </div>

                <p className="text-xs text-muted-foreground text-center">
                  Restricted access for authorized personnel only.
                </p>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
