import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useUserRole } from "@/hooks/use-role";
import { 
  LayoutDashboard, 
  Users, 
  CalendarCheck, 
  GraduationCap, 
  Server, 
  Shield, 
  LogOut,
  Fingerprint,
  Menu,
  BarChart3,
  Settings,
  Building2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";

type NavItem = {
  label: string;
  href: string;
  icon: any;
  roles?: string[];
};

const navItems: NavItem[] = [
  { label: "Dashboard", href: "/", icon: LayoutDashboard },
  { label: "Classes", href: "/classes", icon: GraduationCap },
  { label: "Students", href: "/students", icon: Users },
  { label: "Departments", href: "/departments", icon: Building2 },
  { label: "Attendance", href: "/attendance", icon: CalendarCheck, roles: ["admin", "manager", "class_admin"] },
  { label: "Devices", href: "/devices", icon: Server, roles: ["admin"] },
  { label: "Assign Fingerprints", href: "/assign-fingerprints", icon: Fingerprint, roles: ["admin", "manager"] },
  { label: "Reports", href: "/reports", icon: BarChart3 },
  { label: "Users & Roles", href: "/users", icon: Shield, roles: ["admin"] },
  { label: "Settings", href: "/settings", icon: Settings, roles: ["admin"] },
];

function NavContent({ location, role, onNavigate }: { location: string; role: string; onNavigate?: () => void }) {
  const filteredItems = navItems.filter(item => !item.roles || item.roles.includes(role));

  return (
    <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
      {filteredItems.map((item) => {
        const isActive = location === item.href;
        return (
          <Link key={item.href} href={item.href}>
            <div
              onClick={onNavigate}
              data-testid={`nav-${item.label.toLowerCase().replace(/\s+/g, '-')}`}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors cursor-pointer ${
                isActive
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:bg-muted hover:text-foreground"
              }`}
            >
              <item.icon className="h-4 w-4 flex-shrink-0" />
              <span className="truncate">{item.label}</span>
            </div>
          </Link>
        );
      })}
    </nav>
  );
}

function UserMenu({ user, logout }: { user: any; logout: () => void }) {
  return (
    <div className="p-3 border-t border-border space-y-2">
      <div className="flex items-center gap-3 px-2 py-1.5">
        <Avatar className="h-8 w-8 border border-border flex-shrink-0">
          <AvatarImage src={user?.profileImageUrl || undefined} />
          <AvatarFallback className="bg-primary/10 text-primary text-xs font-bold">
            {user?.firstName?.[0]}{user?.lastName?.[0]}
          </AvatarFallback>
        </Avatar>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium text-foreground truncate">
            {user?.firstName} {user?.lastName}
          </p>
          <p className="text-xs text-muted-foreground truncate">{user?.email}</p>
        </div>
      </div>
      <Button
        variant="destructive"
        className="w-full"
        data-testid="button-logout"
        onClick={() => logout()}
      >
        <LogOut className="mr-2 h-4 w-4" />
        Log out
      </Button>
    </div>
  );
}

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const { user, logout } = useAuth();
  const { role } = useUserRole();
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background flex overflow-x-hidden">
      <aside className="w-60 bg-card border-r border-border hidden md:flex flex-col fixed h-full z-10">
        <div className="p-4 border-b border-border flex items-center gap-3">
          <div className="bg-primary/10 p-2 rounded-md">
            <Fingerprint className="h-5 w-5 text-primary" />
          </div>
          <span className="font-bold text-lg tracking-tight text-foreground">BioTrack</span>
        </div>

        <NavContent location={location} role={role} />
        <UserMenu user={user} logout={logout} />
      </aside>

      <div className="fixed top-0 left-0 right-0 z-20 bg-card border-b border-border flex items-center justify-between px-3 h-14 md:hidden">
        <div className="flex items-center gap-2">
          <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" data-testid="button-mobile-menu">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-72 p-0 flex flex-col">
              <div className="p-4 border-b border-border flex items-center gap-3">
                <div className="bg-primary/10 p-2 rounded-md">
                  <Fingerprint className="h-5 w-5 text-primary" />
                </div>
                <span className="font-bold text-lg tracking-tight text-foreground">BioTrack</span>
              </div>
              <NavContent location={location} role={role} onNavigate={() => setMobileOpen(false)} />
              <UserMenu user={user} logout={logout} />
            </SheetContent>
          </Sheet>
          <div className="flex items-center gap-2">
            <Fingerprint className="h-5 w-5 text-primary" />
            <span className="font-bold text-base text-foreground">BioTrack</span>
          </div>
        </div>
        <Button
          variant="destructive"
          size="sm"
          data-testid="button-mobile-logout"
          onClick={() => logout()}
        >
          <LogOut className="h-4 w-4 mr-1.5" />
          <span>Log out</span>
        </Button>
      </div>

      <main className="flex-1 md:ml-60 min-h-screen pt-14 md:pt-0 overflow-x-hidden">
        <div className="p-3 sm:p-4 md:p-6 lg:p-8 max-w-7xl mx-auto">
          {children}
        </div>
      </main>
    </div>
  );
}
