# BioTrack - Biometric Attendance Management System

## Overview

BioTrack is a full-stack biometric attendance management system built for tracking student attendance using ESP32 fingerprint scanners (R307 sensor). The application provides a web dashboard for managing classes, students, devices, attendance records, and user roles. It's designed for educational institutions that want automated, fingerprint-based attendance tracking.

The system follows a monorepo structure with a React frontend, Express backend, PostgreSQL database, and shared type definitions between client and server.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Monorepo Structure
- `client/` — React SPA frontend
- `server/` — Express API backend
- `shared/` — Shared schemas, types, and route definitions used by both client and server
- `migrations/` — Drizzle-generated database migrations
- `esp32/` — ESP32 Arduino code (non-blocking, ST7735S LCD, R307 sensor) and wiring diagram

### Frontend (client/)
- **Framework**: React with TypeScript
- **Routing**: Wouter (lightweight client-side routing)
- **State/Data Fetching**: TanStack React Query for server state management
- **UI Components**: shadcn/ui (new-york style) built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming (light/dark mode support)
- **Forms**: React Hook Form with Zod validation via `@hookform/resolvers`
- **Charts**: Recharts for dashboard analytics
- **Build Tool**: Vite with HMR in development

Path aliases:
- `@/*` → `client/src/*`
- `@shared/*` → `shared/*`
- `@assets` → `attached_assets/`

### Backend (server/)
- **Framework**: Express.js with TypeScript
- **Runtime**: tsx for development, esbuild for production bundling
- **Database ORM**: Drizzle ORM with PostgreSQL (node-postgres driver)
- **Session Store**: connect-pg-simple (sessions stored in PostgreSQL)
- **Authentication**: Replit Auth via OpenID Connect (passport-based)
- **API Pattern**: RESTful endpoints under `/api/*` with Zod validation on inputs

### Shared Layer (shared/)
- **Schema definitions**: Drizzle ORM table definitions in `shared/schema.ts` and `shared/models/auth.ts`
- **Route contracts**: `shared/routes.ts` defines API endpoints with paths, methods, input schemas, and response schemas using Zod — acts as a contract between frontend and backend
- **Validation**: drizzle-zod generates insert schemas from table definitions

### Database Schema (PostgreSQL)
Key tables:
- `users` — User accounts (managed by Replit Auth)
- `sessions` — Session storage for authentication
- `classes` — Class definitions with schedule type, start/end times, session start/end dates, teacher assignment
- `students` — Student records with roll numbers and fingerprint IDs (for R307 sensor)
- `devices` — ESP32 device registry with API keys and status tracking
- `departments` — Department definitions with name (unique), description, head of department
- `attendance` — Attendance records linking students to dates with status (present/absent/late/excused/leave)
- `scanned_fingerprints` — Fingerprints scanned by ESP32 but not yet assigned to a student
- `user_roles` — Role-based access control (admin/manager/viewer)
- `invitations` — User invitation system

Use `npm run db:push` to push schema changes to the database.

### Authentication & Authorization
- **Authentication**: Email/password with OTP email verification — handled in `server/replit_integrations/auth/`
- **Authorization**: Role-based access control with four roles: `admin`, `manager`, `class_admin`, `viewer`
- Admin and manager roles can create/modify resources
- Class admin can mark attendance but otherwise has viewer-level access (read-only for their own data)
- Viewer is read-only, can only see data related to their own student records/classes
- Forgot password is restricted to admin and manager roles only
- The `requireRole` middleware in `server/routes.ts` enforces role checks
- Data filtering: viewer and class_admin roles only see classes, students, attendance, and departments related to their own student records (linked via `students.userId`)

### Build Process
- **Development**: `npm run dev` runs tsx with Vite dev server middleware (HMR enabled)
- **Production**: `npm run build` uses Vite to build the client and esbuild to bundle the server into `dist/`. The build script bundles specific server dependencies to reduce cold start times.
- **Production start**: `npm start` runs the bundled server from `dist/index.cjs`

### PWA Support
- **Manifest**: `client/public/manifest.json` — standalone display mode, theme color #2563eb
- **Service Worker**: `client/public/sw.js` — caches static assets, network-first for API, offline fallback
- **Icons**: `client/public/icon-192.png` and `icon-512.png` — maskable app icons
- **Meta Tags**: Apple mobile web app capable, theme-color, OG tags in `client/index.html`
- **Registration**: Service worker registered via inline script in index.html

### Responsive Design
- Mobile-first approach with semantic Tailwind tokens (text-foreground, bg-card, border-border, bg-muted, text-muted-foreground)
- All pages use responsive text sizes (text-xl sm:text-2xl lg:text-3xl for titles)
- Full-width buttons on mobile (w-full sm:w-auto)
- Mobile card views for data tables (hidden on desktop, shown on mobile)
- Dark mode support using .dark class toggling with explicit dark: variants

### Key Design Decisions
1. **Shared route contracts**: The `shared/routes.ts` file defines API shape (paths, methods, schemas) used by both the frontend hooks and backend handlers, ensuring type safety across the stack.
2. **Custom hooks per resource**: Each entity (classes, students, devices, attendance, users) has its own React Query hook file providing CRUD operations with automatic cache invalidation and toast notifications.
3. **Protected routes pattern**: The frontend `ProtectedRoute` component wraps pages requiring auth, redirecting unauthenticated users to the login page.
4. **IoT device integration**: The system is designed for ESP32 microcontrollers with R307 fingerprint sensors to submit attendance via API keys, with device management and last-seen tracking.
5. **Semantic color tokens**: All pages use semantic Tailwind tokens instead of hardcoded colors for proper dark mode and theme support.

## External Dependencies

### Database
- **PostgreSQL** — Primary data store, required via `DATABASE_URL` environment variable
- **Drizzle ORM** — Query builder and schema management
- **connect-pg-simple** — Session storage in PostgreSQL

### Authentication
- **Replit Auth** (OpenID Connect) — Requires `ISSUER_URL`, `REPL_ID`, and `SESSION_SECRET` environment variables
- **Passport.js** with openid-client strategy

### Key NPM Packages
- **Frontend**: React, Wouter, TanStack React Query, shadcn/ui (Radix UI), Tailwind CSS, Recharts, date-fns, react-hook-form, Zod
- **Backend**: Express, Drizzle ORM, Passport, express-session, node-postgres (pg)
- **Build**: Vite, esbuild, tsx

### Environment Variables Required
- `DATABASE_URL` — PostgreSQL connection string
- `SESSION_SECRET` — Secret for session encryption
- `REPL_ID` — Replit environment identifier (for auth)
- `ISSUER_URL` — OpenID Connect issuer (defaults to `https://replit.com/oidc`)