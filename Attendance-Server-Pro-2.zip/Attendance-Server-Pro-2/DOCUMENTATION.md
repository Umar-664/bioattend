# BioTrack - Biometric Attendance Management System

## Project Documentation

**Submitted by:** [Your Name]
**Roll Number:** [Your Roll Number]
**Department:** [Your Department]
**Supervisor:** [Supervisor Name]
**Date:** [Submission Date]

---

## Table of Contents

1. [Abstract](#1-abstract)
2. [Introduction](#2-introduction)
3. [Problem Statement](#3-problem-statement)
4. [Objectives](#4-objectives)
5. [System Requirements](#5-system-requirements)
6. [System Architecture](#6-system-architecture)
7. [Database Design](#7-database-design)
8. [Module Descriptions](#8-module-descriptions)
9. [User Roles and Access Control](#9-user-roles-and-access-control)
10. [ESP32 IoT Device Integration](#10-esp32-iot-device-integration)
11. [API Reference](#11-api-reference)
12. [Security Features](#12-security-features)
13. [User Interface](#13-user-interface)
14. [How to Use the System](#14-how-to-use-the-system)
15. [Installation and Setup](#15-installation-and-setup)
16. [Testing](#16-testing)
17. [Future Scope](#17-future-scope)
18. [Conclusion](#18-conclusion)
19. [References](#19-references)

---

## 1. Abstract

BioTrack is a full-stack biometric attendance management system designed for educational institutions. It automates student attendance tracking using ESP32 microcontrollers equipped with R307 fingerprint sensors and ST7735S TFT LCD displays. The system provides a web-based dashboard for managing classes, students, devices, departments, attendance records, and user roles. It features email/password authentication with OTP email verification, role-based access control (Admin, Manager, Class Admin, Viewer), department-based organization, and student self-registration with admin approval. The hardware component communicates with the server through REST APIs, enabling real-time fingerprint-based attendance marking, enrollment management, and device health monitoring.

**Keywords:** Biometric Attendance, Fingerprint Recognition, ESP32, IoT, React, Node.js, PostgreSQL, Role-Based Access Control

---

## 2. Introduction

### 2.1 Background

Traditional attendance systems in educational institutions rely on manual methods such as roll calls, sign-in sheets, or basic card swipes. These methods are time-consuming, prone to human error, and vulnerable to proxy attendance (one student marking attendance for another). The growing need for accurate, tamper-proof attendance systems has driven the adoption of biometric technologies.

### 2.2 What is BioTrack?

BioTrack is an integrated hardware-software solution that combines fingerprint biometrics with a modern web application. Students register their fingerprints on ESP32-based scanner devices. During class, they simply place their finger on the scanner, and their attendance is automatically recorded in the cloud database. Administrators, managers, and teachers can manage classes, students, and attendance records through a responsive web dashboard.

### 2.3 Technology Stack

| Layer         | Technology                                           |
|---------------|------------------------------------------------------|
| Frontend      | React 18, TypeScript, Tailwind CSS, shadcn/ui, Vite  |
| Backend       | Node.js, Express.js, TypeScript                      |
| Database      | PostgreSQL with Drizzle ORM                          |
| IoT Hardware  | ESP32, R307 Fingerprint Sensor, ST7735S LCD          |
| Authentication| Email/Password with OTP verification                 |
| Deployment    | Replit (Cloud Platform)                              |

---

## 3. Problem Statement

Educational institutions face several challenges with existing attendance systems:

1. **Proxy Attendance** — Students can sign on behalf of absent classmates using manual or card-based systems.
2. **Time Consumption** — Manual roll calls waste valuable instructional time, especially in large classes.
3. **Data Inaccuracy** — Handwritten records are prone to errors and difficult to compile for reports.
4. **Lack of Real-Time Data** — Administrators cannot view attendance data in real time.
5. **No Central Management** — Attendance data for multiple classes and departments is often scattered across different systems.

BioTrack addresses all these challenges by using fingerprint biometrics (eliminating proxy attendance), automating the recording process (saving time), storing data in a centralized database (ensuring accuracy), and providing a web dashboard (enabling real-time access).

---

## 4. Objectives

1. Design and implement a fingerprint-based attendance system using ESP32 and R307 sensor.
2. Develop a responsive web dashboard for managing classes, students, devices, and attendance records.
3. Implement secure email/password authentication with OTP email verification.
4. Implement role-based access control with four levels: Admin, Manager, Class Admin, and Viewer.
5. Enable student self-registration with class assignment and admin approval workflow.
6. Support department-based organization for multi-department institutions.
7. Provide real-time device health monitoring and mode management (attendance/enrollment).
8. Generate attendance reports with filtering capabilities.
9. Implement a Progressive Web App (PWA) for mobile access.

---

## 5. System Requirements

### 5.1 Hardware Requirements

| Component                   | Specification                                | Purpose                          |
|-----------------------------|----------------------------------------------|----------------------------------|
| ESP32 DevKit V1             | 30-pin, dual-core, WiFi + Bluetooth          | Main microcontroller             |
| R307 Fingerprint Sensor     | Optical, UART interface, 127 templates       | Fingerprint capture and matching |
| ST7735S TFT LCD             | 1.8", 128x160px, SPI interface               | Visual feedback display          |
| Green LED                   | Standard 5mm LED                             | Success indicator                |
| Red LED                     | Standard 5mm LED                             | Error indicator                  |
| Blue/White Status LED       | Standard 5mm LED                             | Connection status indicator      |
| Resistors                   | 3x 220 ohm                                  | Current limiting for LEDs        |
| Jumper wires and breadboard | Standard prototyping components              | Circuit connections              |

**Fig 5.1: ESP32 DevKit V1 Microcontroller**

![ESP32 DevKit V1](docs/images/esp32_devkit.png)

The ESP32 DevKit V1 is the central processing unit of the hardware module. It features a dual-core processor, built-in WiFi and Bluetooth, and 30 GPIO pins for connecting peripherals.

**Fig 5.2: R307 Optical Fingerprint Sensor**

![R307 Fingerprint Sensor](docs/images/r307_sensor.png)

The R307 is an optical fingerprint sensor module that communicates via UART. It can store up to 127 fingerprint templates locally and provides fingerprint capture, image processing, template generation, and matching — all onboard.

**Fig 5.3: ST7735S 1.8" TFT LCD Display**

![ST7735S LCD](docs/images/st7735s_lcd.png)

The ST7735S is a 1.8-inch color TFT LCD (128x160 pixels) connected via SPI. It displays real-time system status including current mode (Attendance/Enroll), WiFi status, clock, and scan feedback messages.

### 5.2 Software Requirements

| Software                | Version / Details                             |
|-------------------------|-----------------------------------------------|
| Node.js                 | v20 or higher                                 |
| PostgreSQL              | v14 or higher                                 |
| Arduino IDE             | v2.x (for ESP32 programming)                  |
| Web Browser             | Chrome, Firefox, Edge (modern versions)       |
| Operating System        | Windows 10+, macOS 12+, or Linux              |

### 5.3 Arduino Libraries Required

| Library                              | Purpose                            |
|--------------------------------------|------------------------------------|
| Adafruit Fingerprint Sensor Library  | R307 fingerprint sensor driver     |
| Adafruit GFX Library                 | Graphics primitives for LCD        |
| Adafruit ST7735 and ST7789 Library   | ST7735S LCD display driver         |
| WiFi (built-in)                      | ESP32 WiFi connectivity            |
| HTTPClient (built-in)                | HTTP requests to server            |

### 5.4 NPM Dependencies (Key Packages)

**Frontend:**
- React, React DOM — UI framework
- Wouter — Client-side routing
- TanStack React Query — Server state management
- shadcn/ui (Radix UI) — UI component library
- Tailwind CSS — Utility-first CSS framework
- Recharts — Dashboard charts
- React Hook Form + Zod — Form handling and validation
- date-fns — Date formatting

**Backend:**
- Express.js — HTTP server framework
- Drizzle ORM — Database query builder
- Passport.js — Authentication middleware
- node-postgres (pg) — PostgreSQL client
- bcrypt — Password hashing
- nodemailer — Email sending (OTP)
- express-session — Session management
- connect-pg-simple — PostgreSQL session store

---

## 6. System Architecture

### 6.1 High-Level Architecture

```
┌──────────────────────────────────────────────────────────────────┐
│                        CLIENT (Browser)                          │
│                                                                  │
│   React SPA ──── Wouter Router ──── TanStack Query               │
│   shadcn/ui ──── Tailwind CSS ──── React Hook Form               │
│                                                                  │
│   Port 5000 (served by Express via Vite middleware)              │
└────────────────────────────┬─────────────────────────────────────┘
                             │ HTTP (REST API)
                             │
┌────────────────────────────▼─────────────────────────────────────┐
│                     SERVER (Express.js)                           │
│                                                                  │
│   Auth Middleware ──── Role Middleware ──── Route Handlers        │
│   Session Management ──── Input Validation (Zod)                 │
│   Email Service (Nodemailer) ──── Device Health Monitor          │
│                                                                  │
│   Port 5000                                                      │
└────────────────────────────┬─────────────────────────────────────┘
                             │ SQL (Drizzle ORM)
                             │
┌────────────────────────────▼─────────────────────────────────────┐
│                     DATABASE (PostgreSQL)                         │
│                                                                  │
│   users ── sessions ── user_roles ── invitations                 │
│   classes ── students ── departments ── devices                  │
│   attendance ── scanned_fingerprints                             │
│   pending_verifications ── password_resets ── app_settings       │
│                                                                  │
└──────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────┐
│                     ESP32 IoT DEVICE                             │
│                                                                  │
│   R307 Fingerprint ──── ESP32 MCU ──── ST7735S LCD               │
│   Green LED ── Red LED ── Status LED                             │
│                                                                  │
│   WiFi ──── HTTP REST ──── /api/device/sync                      │
│                             /api/device/mode                     │
│                             /api/device/heartbeat                │
└──────────────────────────────────────────────────────────────────┘
```

### 6.2 Monorepo Structure

```
biotrack/
├── client/                     # Frontend React application
│   ├── src/
│   │   ├── components/         # Reusable UI components
│   │   │   └── ui/             # shadcn/ui base components
│   │   ├── hooks/              # Custom React hooks (data fetching)
│   │   ├── lib/                # Utility functions
│   │   ├── pages/              # Page components
│   │   │   ├── dashboard.tsx
│   │   │   ├── login.tsx
│   │   │   ├── classes.tsx
│   │   │   ├── students.tsx
│   │   │   ├── attendance.tsx
│   │   │   ├── devices.tsx
│   │   │   ├── departments.tsx
│   │   │   ├── users.tsx
│   │   │   ├── reports.tsx
│   │   │   ├── settings.tsx
│   │   │   ├── assign-fingerprints.tsx
│   │   │   └── not-found.tsx
│   │   ├── App.tsx             # Root component with routes
│   │   └── main.tsx            # Application entry point
│   ├── public/                 # Static assets (PWA manifest, icons)
│   └── index.html
├── server/                     # Backend Express application
│   ├── routes.ts               # API route handlers
│   ├── storage.ts              # Database access layer (CRUD)
│   ├── db.ts                   # Database connection
│   ├── email.ts                # Email service (SMTP/OTP)
│   ├── deviceHealthCheck.ts    # Device status monitoring
│   ├── index.ts                # Server entry point
│   ├── vite.ts                 # Vite dev server integration
│   └── replit_integrations/
│       └── auth/               # Authentication (login, register, OTP)
├── shared/                     # Shared between client and server
│   ├── schema.ts               # Database table definitions (Drizzle)
│   ├── routes.ts               # API contract definitions (Zod)
│   └── models/
│       └── auth.ts             # User and session table schemas
├── esp32/                      # ESP32 Arduino firmware
│   ├── biotrack_esp32.ino      # Main firmware code
│   └── WIRING_DIAGRAM.md       # Hardware wiring guide
├── migrations/                 # Database migrations (Drizzle)
├── package.json
├── tsconfig.json
├── vite.config.ts
└── drizzle.config.ts
```

### 6.3 Data Flow

**Fingerprint Attendance Flow:**
1. Student places finger on the R307 sensor connected to the ESP32.
2. The R307 sensor captures the fingerprint image and converts it to a template.
3. The ESP32 searches its local template database for a match.
4. If a match is found, the ESP32 sends a POST request to `/api/device/sync` with the fingerprint ID, API key, and timestamp.
5. The server verifies the API key, looks up the student by fingerprint ID, determines the class based on schedule, checks for late arrival, and records the attendance.
6. The server responds with success/failure, which the ESP32 displays on the LCD and indicates with LEDs.

**Student Self-Registration Flow:**
1. Student visits the registration page and fills in name, email, roll number, and selects a class (from dropdown or via invite code).
2. An OTP is sent to their email address.
3. Student enters the OTP to verify their email.
4. A student record is created with "pending" status.
5. An admin reviews and approves/rejects the registration.
6. Upon approval, the student's status becomes "active" and they can use the system.

---

## 7. Database Design

### 7.1 Entity Relationship Overview

The database contains 13 tables organized into the following groups:

**Core Entities:**
- `users` — User accounts
- `students` — Student profiles
- `classes` — Class definitions
- `departments` — Department definitions
- `devices` — ESP32 device registry

**Operational Data:**
- `attendance` — Attendance records
- `scanned_fingerprints` — Fingerprints scanned but not yet assigned

**Authentication & Authorization:**
- `sessions` — User session data
- `user_roles` — Role assignments
- `invitations` — User invitations
- `pending_verifications` — OTP verification during registration
- `password_resets` — OTP for password reset

**Configuration:**
- `app_settings` — Application settings (SMTP config, etc.)

### 7.2 Table Definitions

#### users
| Column            | Type      | Constraints              | Description                 |
|-------------------|-----------|--------------------------|-----------------------------|
| id                | VARCHAR   | PRIMARY KEY, UUID        | Unique user identifier      |
| email             | VARCHAR   | UNIQUE                   | User email address          |
| password          | VARCHAR   | NULLABLE                 | Bcrypt hashed password      |
| first_name        | VARCHAR   | NULLABLE                 | First name                  |
| last_name         | VARCHAR   | NULLABLE                 | Last name                   |
| profile_image_url | VARCHAR   | NULLABLE                 | Profile picture URL         |
| created_at        | TIMESTAMP | DEFAULT NOW              | Account creation date       |
| updated_at        | TIMESTAMP | DEFAULT NOW              | Last update date            |

#### classes
| Column             | Type    | Constraints                      | Description                     |
|--------------------|---------|----------------------------------|---------------------------------|
| id                 | SERIAL  | PRIMARY KEY                      | Auto-increment ID               |
| name               | TEXT    | NOT NULL                         | Class name                      |
| instructor         | TEXT    | NULLABLE                         | Instructor name                 |
| schedule_type      | TEXT    | NOT NULL                         | "morning" or "evening"          |
| start_time         | TIME    | NOT NULL                         | Class start time                |
| end_time           | TIME    | NOT NULL                         | Class end time                  |
| late_time          | TIME    | NULLABLE                         | Time after which student is late|
| session_start_date | DATE    | NULLABLE                         | Academic session start          |
| session_end_date   | DATE    | NULLABLE                         | Academic session end            |
| teacher_id         | VARCHAR | FOREIGN KEY -> users.id          | Assigned teacher                |
| department_id      | INTEGER | FOREIGN KEY -> departments.id    | Department assignment           |
| invite_code        | TEXT    | UNIQUE, NULLABLE                 | Class invite code for students  |

#### students
| Column         | Type    | Constraints                      | Description                     |
|----------------|---------|----------------------------------|---------------------------------|
| id             | SERIAL  | PRIMARY KEY                      | Auto-increment ID               |
| name           | TEXT    | NOT NULL                         | Student full name               |
| roll_number    | TEXT    | UNIQUE, NOT NULL                 | Student roll number             |
| fingerprint_id | INTEGER | UNIQUE, NULLABLE                 | R307 fingerprint template ID    |
| class_id       | INTEGER | FOREIGN KEY -> classes.id        | Assigned class                  |
| department_id  | INTEGER | FOREIGN KEY -> departments.id    | Assigned department             |
| user_id        | VARCHAR | FOREIGN KEY -> users.id          | Linked user account             |
| status         | TEXT    | NOT NULL, DEFAULT "active"       | "active", "pending", "rejected" |
| created_at     | TIMESTAMP | DEFAULT NOW                    | Registration date               |

#### devices
| Column        | Type    | Constraints                      | Description                     |
|---------------|---------|----------------------------------|---------------------------------|
| id            | SERIAL  | PRIMARY KEY                      | Auto-increment ID               |
| name          | TEXT    | NOT NULL                         | Device name                     |
| location      | TEXT    | NULLABLE                         | Physical location               |
| api_key       | TEXT    | UNIQUE, NOT NULL                 | Device authentication key       |
| is_active     | BOOLEAN | DEFAULT TRUE                     | Whether device is enabled       |
| mode          | TEXT    | NOT NULL, DEFAULT "attendance"   | "attendance" or "enroll"        |
| department_id | INTEGER | FOREIGN KEY -> departments.id    | Department assignment           |
| last_seen     | TIMESTAMP | NULLABLE                       | Last communication timestamp    |

#### departments
| Column             | Type    | Constraints              | Description                |
|--------------------|---------|--------------------------|----------------------------|
| id                 | SERIAL  | PRIMARY KEY              | Auto-increment ID          |
| name               | TEXT    | UNIQUE, NOT NULL         | Department name            |
| description        | TEXT    | NULLABLE                 | Department description     |
| head_of_department | TEXT    | NULLABLE                 | HOD name                   |
| created_at         | TIMESTAMP | DEFAULT NOW            | Creation date              |

#### attendance
| Column     | Type    | Constraints                      | Description                         |
|------------|---------|----------------------------------|-------------------------------------|
| id         | SERIAL  | PRIMARY KEY                      | Auto-increment ID                   |
| student_id | INTEGER | FOREIGN KEY -> students.id, NOT NULL | Student who attended            |
| class_id   | INTEGER | FOREIGN KEY -> classes.id        | Class at time of attendance         |
| device_id  | INTEGER | FOREIGN KEY -> devices.id        | Device that recorded (if hardware)  |
| date       | TIMESTAMP | DEFAULT NOW                    | Attendance date and time            |
| status     | TEXT    | NOT NULL                         | "present", "absent", "late", "excused", "leave" |
| marked_by  | VARCHAR | FOREIGN KEY -> users.id          | User who marked (if manual)         |

#### scanned_fingerprints
| Column         | Type    | Constraints                      | Description                     |
|----------------|---------|----------------------------------|---------------------------------|
| id             | SERIAL  | PRIMARY KEY                      | Auto-increment ID               |
| fingerprint_id | INTEGER | NOT NULL                         | R307 template ID                |
| device_id      | INTEGER | FOREIGN KEY -> devices.id        | Scanner device                  |
| scanned_at     | TIMESTAMP | DEFAULT NOW                    | Scan timestamp                  |
| assigned       | BOOLEAN | DEFAULT FALSE                    | Whether assigned to a student   |

#### user_roles
| Column     | Type    | Constraints                      | Description                     |
|------------|---------|----------------------------------|---------------------------------|
| id         | SERIAL  | PRIMARY KEY                      | Auto-increment ID               |
| user_id    | VARCHAR | FOREIGN KEY -> users.id, UNIQUE  | User reference                  |
| role       | TEXT    | NOT NULL, DEFAULT "viewer"       | "admin", "manager", "class_admin", "viewer" |
| created_at | TIMESTAMP | DEFAULT NOW                    | Assignment date                 |

#### invitations
| Column     | Type    | Constraints                      | Description                     |
|------------|---------|----------------------------------|---------------------------------|
| id         | SERIAL  | PRIMARY KEY                      | Auto-increment ID               |
| email      | TEXT    | UNIQUE, NOT NULL                 | Invitee email                   |
| role       | TEXT    | NOT NULL, DEFAULT "viewer"       | Assigned role on acceptance     |
| invited_by | VARCHAR | FOREIGN KEY -> users.id          | User who sent invitation        |
| created_at | TIMESTAMP | DEFAULT NOW                    | Invitation date                 |
| expires_at | TIMESTAMP | NULLABLE                       | Expiration date                 |

#### pending_verifications
| Column          | Type    | Constraints  | Description                     |
|-----------------|---------|--------------|----------------------------------|
| id              | SERIAL  | PRIMARY KEY  | Auto-increment ID                |
| email           | TEXT    | NOT NULL     | Email being verified             |
| code            | TEXT    | NOT NULL     | OTP verification code            |
| first_name      | TEXT    | NOT NULL     | Registrant first name            |
| last_name       | TEXT    | NOT NULL     | Registrant last name             |
| hashed_password | TEXT    | NOT NULL     | Bcrypt hashed password           |
| class_id        | INTEGER | NULLABLE     | Selected class                   |
| roll_number     | TEXT    | NULLABLE     | Student roll number              |
| expires_at      | TIMESTAMP | NOT NULL   | OTP expiration time              |
| created_at      | TIMESTAMP | DEFAULT NOW| Record creation time             |

#### password_resets
| Column     | Type    | Constraints  | Description                     |
|------------|---------|--------------|----------------------------------|
| id         | SERIAL  | PRIMARY KEY  | Auto-increment ID                |
| email      | TEXT    | NOT NULL     | User email                       |
| code       | TEXT    | NOT NULL     | Reset OTP code                   |
| expires_at | TIMESTAMP | NOT NULL   | OTP expiration time              |
| created_at | TIMESTAMP | DEFAULT NOW| Request creation time            |

#### sessions
| Column | Type    | Constraints  | Description                     |
|--------|---------|--------------|----------------------------------|
| sid    | VARCHAR | PRIMARY KEY  | Session ID                       |
| sess   | JSONB   | NOT NULL     | Session data                     |
| expire | TIMESTAMP | NOT NULL   | Session expiration               |

#### app_settings
| Column     | Type    | Constraints        | Description                     |
|------------|---------|--------------------|---------------------------------|
| id         | SERIAL  | PRIMARY KEY        | Auto-increment ID               |
| key        | TEXT    | UNIQUE, NOT NULL   | Setting key name                |
| value      | TEXT    | NOT NULL           | Setting value                   |
| updated_at | TIMESTAMP | DEFAULT NOW      | Last update time                |

### 7.3 Relationships

```
departments ──< classes ──< students ──< attendance
                   │              │            │
                   │              │            └── devices
                   │              └── users
                   └── users (teacher)

users ──── user_roles
users ──── invitations
users ──── sessions
```

- A **department** has many **classes**
- A **class** has many **students**
- A **student** has many **attendance** records
- A **student** belongs to one **class** and one **department**
- A **student** is linked to one **user** account
- A **class** has one optional **teacher** (user)
- An **attendance** record links to a **student**, optionally a **class**, a **device**, and a **user** (marker)
- A **device** belongs to one optional **department**
- A **user** has one **role** assignment

---

## 8. Module Descriptions

### 8.1 Authentication Module

**Location:** `server/replit_integrations/auth/`

Handles user registration, login, email verification, and password management.

**Features:**
- Email/password registration with form validation
- 6-digit OTP sent to email for verification
- OTP resend functionality
- Secure login with bcrypt password hashing
- Forgot password flow with OTP email reset
- Session-based authentication stored in PostgreSQL
- Rate limiting: 10 attempts per 15 minutes for login/register, 5 attempts per 15 minutes for password reset
- Automatic cleanup of expired verification codes and password reset tokens

### 8.2 Dashboard Module

**Location:** `client/src/pages/dashboard.tsx`

The main landing page after login showing an overview of the system.

**Features:**
- Daily attendance trends chart (Recharts)
- Class-wise attendance summary
- Status breakdown (present, absent, late, excused, leave)
- Recent activity feed
- Configurable time range (7/14/30 days)
- Data filtered based on user role (viewers see only their own data)

### 8.3 Class Management Module

**Location:** `client/src/pages/classes.tsx`, `server/routes.ts`

Manages class definitions and schedules.

**Features:**
- Create, edit, and delete classes
- Set schedule type (morning/evening), start time, end time, and late threshold time
- Assign teacher and department
- Set academic session dates
- Generate unique invite codes for student self-registration
- Class filtering for role-restricted users (viewers/class admins see only their classes)

### 8.4 Student Management Module

**Location:** `client/src/pages/students.tsx`, `server/routes.ts`

Manages student records and registrations.

**Features:**
- Create, edit, and delete student records
- Assign students to classes and departments
- Link students to user accounts
- Student self-registration with class selection (dropdown or invite code)
- Admin approval workflow (pending -> approved/rejected)
- Search and filter by class
- Fingerprint ID assignment

### 8.5 Attendance Module

**Location:** `client/src/pages/attendance.tsx`, `server/routes.ts`

Records and manages attendance data.

**Features:**
- Manual bulk attendance marking by class and date
- Automatic attendance via ESP32 fingerprint devices
- Status options: Present, Absent, Late, Excused, Leave
- Duplicate attendance prevention (one record per student per day)
- Automatic late detection based on class late-time threshold
- Class-based attendance filtering

### 8.6 Device Management Module

**Location:** `client/src/pages/devices.tsx`, `server/routes.ts`

Manages ESP32 fingerprint scanner devices.

**Features:**
- Register new devices with auto-generated API keys
- Switch device mode: Attendance mode or Enrollment mode
- Activate/deactivate devices
- Assign devices to departments
- Device health monitoring with connection status (online/offline/never connected)
- Device ping/test connectivity
- Real-time last-seen tracking via heartbeat

### 8.7 Department Management Module

**Location:** `client/src/pages/departments.tsx`, `server/routes.ts`

Organizes classes, students, and devices by department.

**Features:**
- Create, edit, and delete departments
- Set department head
- Departments link to classes, students, and devices
- Role-restricted visibility (viewers see only their departments)

### 8.8 Fingerprint Assignment Module

**Location:** `client/src/pages/assign-fingerprints.tsx`, `server/routes.ts`

Assigns scanned fingerprints to student records.

**Features:**
- View unassigned fingerprints scanned by devices in enrollment mode
- Assign a fingerprint to a specific student
- Dismiss/delete unassigned fingerprints
- Shows device information and scan timestamp

### 8.9 User Management Module

**Location:** `client/src/pages/users.tsx`, `server/routes.ts`

Manages user accounts and roles (admin only).

**Features:**
- View all registered users
- Change user roles (Admin, Manager, Class Admin, Viewer)
- Send email invitations for new users
- Delete users and invitations
- Protection against self-role modification

### 8.10 Reports Module

**Location:** `client/src/pages/reports.tsx`, `server/routes.ts`

Generates attendance reports with filters.

**Features:**
- Filter by class, date range, and status
- View detailed attendance records
- Role-based data filtering

### 8.11 Settings Module

**Location:** `client/src/pages/settings.tsx`, `server/routes.ts`

System configuration (admin only).

**Features:**
- SMTP email configuration (host, port, user, password, from address)
- Test SMTP connection
- Save and update application settings

---

## 9. User Roles and Access Control

BioTrack implements a four-level Role-Based Access Control (RBAC) system. Each user in the system is assigned exactly one role, which determines what they can see and do. The role is stored in the `user_roles` table and checked on every API request via the `requireRole` middleware.

**Fig 9.1: Users & Roles Management Page (Admin View)**

![Users & Roles Page](docs/images/users_roles_page.png)

The screenshot above shows the Users & Roles page where the Admin can view all users grouped by role, change roles, and manage invitations.

### 9.1 Role Definitions

#### 9.1.1 Admin (Highest Level)

The **Admin** has complete, unrestricted access to every part of the system. This role is intended for the institution's IT administrator or the primary system owner.

**What an Admin can do:**
- Create, edit, and delete classes, students, departments, and devices
- Register ESP32 devices and manage their API keys
- Switch device modes between Attendance and Enrollment
- Mark attendance for any class
- Approve or reject student self-registrations
- Assign fingerprints scanned by devices to student records
- Manage all user accounts — change roles, delete users, send invitations
- Configure system settings — SMTP email, database backup/restore, password resets
- View dashboard statistics and reports for the entire institution
- Generate class invite codes for student self-registration

**What an Admin cannot do:**
- Change their own role (protection against accidental lockout)

**Typical users:** System administrator, IT department head, principal

#### 9.1.2 Manager (Second Level)

The **Manager** role is designed for staff members who need to manage academic data but should not have access to system-level configuration or user management.

**What a Manager can do:**
- Create new classes, students, and departments
- Mark attendance for any class
- View all classes, students, departments, and attendance records
- Assign fingerprints to students
- View dashboard statistics and reports for the entire institution
- Use the forgot password feature to reset their own password

**What a Manager cannot do:**
- Edit or delete existing classes, students, or departments (only create)
- Manage ESP32 devices (register, edit, delete, switch modes)
- Manage user accounts or change roles
- Access system settings (SMTP, database, passwords)
- Approve or reject student registrations

**Typical users:** Department coordinators, senior teachers, academic office staff

#### 9.1.3 Class Admin (Third Level)

The **Class Admin** role is designed for teachers or class representatives who need to mark attendance for their assigned classes but should have limited access to other data.

**What a Class Admin can do:**
- Mark attendance for classes (bulk attendance marking)
- View their own classes (classes linked to their student records)
- View their own student records and attendance history
- View their own departments
- View dashboard statistics for their own data
- View reports filtered to their own data

**What a Class Admin cannot do:**
- Create, edit, or delete any classes, students, or departments
- Manage devices or fingerprints
- Manage users or roles
- Access system settings
- See data belonging to other students or classes
- Use the forgot password feature (must contact Admin)

**Typical users:** Class teachers, class representatives, lab assistants

#### 9.1.4 Viewer (Lowest Level)

The **Viewer** role is the most restricted level, providing read-only access to the user's own data. This is the default role assigned to new student accounts created through self-registration.

**What a Viewer can do:**
- View their own classes (classes they are enrolled in)
- View their own student profile and attendance records
- View their own departments
- View dashboard statistics for their own attendance
- View reports filtered to their own data

**What a Viewer cannot do:**
- Create, edit, or delete any data
- Mark attendance
- Manage devices, fingerprints, users, or settings
- See data belonging to other students or classes
- Use the forgot password feature (must contact Admin)

**Typical users:** Students, parents (if given access), external auditors

### 9.2 Role Hierarchy Diagram

```
  ┌─────────────────────────────────────────────────────────────────┐
  │                                                                 │
  │   ADMIN (Level 1)                                               │
  │   Full system access                                            │
  │   Can: Everything + Settings + Users + Devices + Approvals      │
  │                                                                 │
  │   ┌─────────────────────────────────────────────────────────┐   │
  │   │                                                         │   │
  │   │   MANAGER (Level 2)                                     │   │
  │   │   Academic data management                              │   │
  │   │   Can: Create resources + Mark attendance + Fingerprints│   │
  │   │                                                         │   │
  │   │   ┌─────────────────────────────────────────────────┐   │   │
  │   │   │                                                 │   │   │
  │   │   │   CLASS ADMIN (Level 3)                         │   │   │
  │   │   │   Attendance management                         │   │   │
  │   │   │   Can: Mark attendance + View own data          │   │   │
  │   │   │                                                 │   │   │
  │   │   │   ┌─────────────────────────────────────┐       │   │   │
  │   │   │   │                                     │       │   │   │
  │   │   │   │   VIEWER (Level 4)                  │       │   │   │
  │   │   │   │   Read-only access                  │       │   │   │
  │   │   │   │   Can: View own data only           │       │   │   │
  │   │   │   │                                     │       │   │   │
  │   │   │   └─────────────────────────────────────┘       │   │   │
  │   │   └─────────────────────────────────────────────────┘   │   │
  │   └─────────────────────────────────────────────────────────┘   │
  └─────────────────────────────────────────────────────────────────┘
```

### 9.3 Permission Matrix

| Action                        | Admin | Manager | Class Admin | Viewer |
|-------------------------------|-------|---------|-------------|--------|
| View Dashboard                | Yes   | Yes     | Yes (own)   | Yes (own) |
| Create/Edit/Delete Classes    | Yes   | Yes (create) | No     | No     |
| Create/Edit/Delete Students   | Yes   | Yes (create) | No     | No     |
| Mark Attendance               | Yes   | Yes     | Yes         | No     |
| View Attendance               | Yes   | Yes     | Yes (own)   | Yes (own) |
| Manage Devices                | Yes   | No      | No          | No     |
| Manage Departments            | Yes   | Yes (create) | No     | No     |
| Manage Users & Roles          | Yes   | No      | No          | No     |
| Assign Fingerprints           | Yes   | Yes     | No          | No     |
| View Reports                  | Yes   | Yes     | Yes (own)   | Yes (own) |
| System Settings               | Yes   | No      | No          | No     |
| Approve/Reject Students       | Yes   | No      | No          | No     |
| Forgot Password               | Yes   | Yes     | No          | No     |

### 9.4 Data Filtering

For **Viewer** and **Class Admin** roles, the system automatically filters data so they can only see information relevant to them:

1. **Classes** — They can only see classes they are enrolled in. The system looks up their student records (linked via `students.userId`) and shows only the classes those records belong to.
2. **Students** — They can only see their own student records, not other students in the same class.
3. **Attendance** — They can only see attendance records for their own student IDs. They cannot see attendance of other students.
4. **Dashboard** — Statistics (charts, counts, trends) are calculated using only their own attendance data, not the entire institution's data.
5. **Departments** — They can only see departments that their enrolled classes belong to.
6. **Reports** — Attendance reports are filtered to only include their own student records.

This filtering happens at the server level (in the API route handlers), not just in the frontend, so it cannot be bypassed.

### 9.5 How Roles are Assigned

1. **First Admin** — The very first user registered in the system needs to be manually assigned the Admin role in the database.
2. **By Admin** — After the first admin is set up, they can assign roles to other users from the Users & Roles page.
3. **By Invitation** — When an Admin sends an invitation email, they specify the role the invitee will receive upon registration.
4. **Default Role** — Any user who registers without an invitation is assigned the "Viewer" role by default.
5. **Student Self-Registration** — Students who register through the self-registration flow get the Viewer role and a "pending" student status that requires Admin approval.

---

## 10. ESP32 IoT Device Integration

### 10.1 Hardware Components

The ESP32 device consists of:
- **ESP32 DevKit V1** — Main microcontroller with WiFi
- **R307 Fingerprint Sensor** — Optical fingerprint scanner (UART, 127 template capacity)
- **ST7735S 1.8" TFT LCD** — Color display for status and instructions (128x160px, SPI)
- **3 LEDs** — Green (success), Red (error), Blue/White (connection status)

### 10.2 Wiring Diagram

**Fig 10.1: ESP32 and R307 Fingerprint Sensor Wiring**

![ESP32 R307 Wiring Diagram](docs/images/esp32_r307_wiring.png)

The above diagram shows the physical wiring between the ESP32 development board and the R307 fingerprint sensor, including VIN (5V), GND, GPIO16 (RXD), and GPIO17 (TXD) connections. The complete wiring including the LCD and LEDs is shown below:

```
  ┌───────────────────────────────────────────────────────────────────┐
  │                          ESP32 DevKit                             │
  │                                                                   │
  │   3V3 ──────────────────────────── R307 VCC (Red)                 │
  │   3V3 ──────────────────────────── ST7735S VCC                    │
  │   GND ──────────────────────────── R307 GND (Black)               │
  │   GND ──────────────────────────── ST7735S GND                    │
  │                                                                   │
  │   ── R307 Fingerprint (UART2) ──                                  │
  │   GPIO16 (RX2) ────────────────── R307 TX  (Yellow)               │
  │   GPIO17 (TX2) ────────────────── R307 RX  (Green)                │
  │                                                                   │
  │   ── ST7735S LCD (SPI) ──                                         │
  │   GPIO18 (SCLK) ──────────────── ST7735S SCL/CLK                  │
  │   GPIO23 (MOSI) ──────────────── ST7735S SDA/MOSI                 │
  │   GPIO5  (CS)   ──────────────── ST7735S CS                       │
  │   GPIO26 (DC)   ──────────────── ST7735S DC/A0                    │
  │   GPIO27 (RST)  ──────────────── ST7735S RST/RES                  │
  │   3V3 ─────────────────────────── ST7735S BLK (Backlight)         │
  │                                                                   │
  │   ── LEDs ──                                                      │
  │   GPIO2  ──── [220Ω] ──── Green LED (+) ──── GND                  │
  │   GPIO4  ──── [220Ω] ──── Red LED   (+) ──── GND                  │
  │   GPIO15 ──── [220Ω] ──── Status LED(+) ──── GND                  │
  └───────────────────────────────────────────────────────────────────┘
```

### 10.3 Pin Summary

| ESP32 Pin | Connected To              | Purpose                        |
|-----------|---------------------------|--------------------------------|
| 3V3       | R307 VCC, ST7735S VCC/BLK | Power for sensor and LCD       |
| GND       | R307 GND, ST7735S GND     | Common ground                  |
| GPIO16    | R307 TX (Yellow)          | Receive data from sensor       |
| GPIO17    | R307 RX (Green)           | Send commands to sensor        |
| GPIO18    | ST7735S SCL/CLK           | SPI clock                      |
| GPIO23    | ST7735S SDA/MOSI          | SPI data out                   |
| GPIO5     | ST7735S CS                | SPI chip select                |
| GPIO26    | ST7735S DC/A0             | Data/command select            |
| GPIO27    | ST7735S RST/RES           | LCD reset                      |
| GPIO2     | Green LED (+ anode)       | Blinks on successful scan      |
| GPIO4     | Red LED (+ anode)         | Blinks on scan error           |
| GPIO15    | Status LED (+ anode)      | Solid ON = connected           |

### 10.4 Firmware Architecture

The ESP32 firmware uses a fully **non-blocking** architecture with state machines:

1. **Main Loop** — Runs continuously without `delay()` calls
2. **WiFi Manager** — Event-driven connection/reconnection with timeout
3. **NTP Sync** — Time synchronization with retry logic
4. **Mode Checker** — Polls server every 10 seconds for mode changes
5. **Heartbeat** — Sends keep-alive every 30 seconds
6. **Fingerprint Scanner** — Continuous non-blocking scan loop
7. **Enrollment State Machine** — Multi-step fingerprint enrollment (IDLE → WAIT_LIFT → WAIT_SECOND → PROCESS)
8. **LED Blinker** — Non-blocking LED animations
9. **LCD Manager** — Real-time display updates (header, mode, clock, status messages)

### 10.5 Device Operating Modes

| Mode         | Description                                                    |
|--------------|----------------------------------------------------------------|
| **Attendance** | Default mode. Scans fingerprints and records attendance.     |
| **Enroll**     | Enrollment mode. Captures new fingerprints and stores them on the sensor and server for later assignment. |

Mode is controlled from the web dashboard. The ESP32 polls `/api/device/mode` every 10 seconds to check for mode changes.

### 10.6 LCD Display Layout

```
  ┌─────────────────────────────┐
  │ BioTrack          WiFi OK   │  <- Header bar (blue background)
  │─────────────────────────────│
  │                             │
  │   ATTENDANCE                │  <- Current mode (large text)
  │                             │
  │   Place finger to scan      │  <- Instructions
  │                             │
  │   Attendance OK!            │  <- Status messages (flash area)
  │─────────────────────────────│
  │ 14:23:05              ATT   │  <- Clock + mode indicator
  └─────────────────────────────┘
```

### 10.7 LED Behavior

| LED    | Color       | Behavior                                       |
|--------|-------------|------------------------------------------------|
| Green  | Green       | Blinks when attendance is successfully recorded |
| Red    | Red         | Blinks when fingerprint not recognized or error |
| Status | Blue/White  | Solid ON = device connected and online          |

### 10.8 ESP32 Setup Steps

1. Wire all components as shown in the wiring diagram
2. Install Arduino IDE and add ESP32 board support
3. Install required libraries from the Arduino Library Manager
4. Open `biotrack_esp32.ino`
5. Update WiFi credentials (`WIFI_SSID`, `WIFI_PASSWORD`)
6. Update server URL (`SERVER_URL`) to your deployed BioTrack URL
7. Update API key (`API_KEY`) — get this from the Devices page on the dashboard
8. Adjust `GMT_OFFSET` and `DST_OFFSET` for your timezone
9. Select board: "ESP32 Dev Module"
10. Upload the sketch
11. Open Serial Monitor at 115200 baud to see debug output

---

## 11. API Reference

### 11.1 Authentication Endpoints

| Method | Endpoint                      | Description                  | Auth Required | Rate Limited     |
|--------|-------------------------------|------------------------------|---------------|------------------|
| POST   | /api/auth/register            | Register new user            | No            | 10 req / 15 min  |
| POST   | /api/auth/verify              | Verify OTP code              | No            | 10 req / 15 min  |
| POST   | /api/auth/resend-code         | Resend OTP code              | No            | 10 req / 15 min  |
| POST   | /api/auth/login               | Login with email/password    | No            | 10 req / 15 min  |
| POST   | /api/auth/logout              | Logout                       | Yes           | No               |
| GET    | /api/auth/user                | Get current user profile     | Yes           | No               |
| GET    | /api/auth/role                | Get current user role        | Yes           | No               |
| POST   | /api/auth/forgot-password     | Request password reset OTP   | No            | 5 req / 15 min   |
| POST   | /api/auth/reset-password      | Reset password with OTP      | No            | 5 req / 15 min   |

### 11.2 Class Endpoints

| Method | Endpoint                      | Description                  | Roles                |
|--------|-------------------------------|------------------------------|----------------------|
| GET    | /api/classes                  | List all classes             | All (filtered)       |
| POST   | /api/classes                  | Create a class               | Admin, Manager       |
| PUT    | /api/classes/:id              | Update a class               | Admin                |
| DELETE | /api/classes/:id              | Delete a class               | Admin                |
| POST   | /api/classes/:id/invite-code  | Generate invite code         | Admin                |
| GET    | /api/public/classes           | List classes (registration)  | Public (no auth)     |
| GET    | /api/public/invite-code/:code | Validate invite code         | Public (no auth)     |

### 11.3 Student Endpoints

| Method | Endpoint                      | Description                  | Roles                |
|--------|-------------------------------|------------------------------|----------------------|
| GET    | /api/students                 | List students                | All (filtered)       |
| POST   | /api/students                 | Create a student             | Admin, Manager       |
| PUT    | /api/students/:id             | Update a student             | Admin                |
| DELETE | /api/students/:id             | Delete a student             | Admin                |
| GET    | /api/students/pending         | List pending registrations   | Admin, Manager       |
| POST   | /api/students/:id/approve     | Approve student registration | Admin                |
| POST   | /api/students/:id/reject      | Reject student registration  | Admin                |

### 11.4 Attendance Endpoints

| Method | Endpoint                      | Description                  | Roles                       |
|--------|-------------------------------|------------------------------|-----------------------------|
| GET    | /api/attendance               | List attendance records      | All (filtered)              |
| POST   | /api/attendance/bulk          | Bulk mark attendance         | Admin, Manager, Class Admin |
| GET    | /api/attendance/report        | Get attendance report        | All (filtered)              |

### 11.5 Device Endpoints (Web Dashboard)

| Method | Endpoint                      | Description                  | Roles          |
|--------|-------------------------------|------------------------------|----------------|
| GET    | /api/devices                  | List all devices             | Admin          |
| POST   | /api/devices                  | Register a device            | Admin          |
| PUT    | /api/devices/:id              | Update a device              | Admin          |
| DELETE | /api/devices/:id              | Delete a device              | Admin          |
| POST   | /api/device/ping              | Test device connectivity     | Public         |

### 11.6 Device Endpoints (ESP32)

| Method | Endpoint                      | Description                    | Auth           |
|--------|-------------------------------|--------------------------------|----------------|
| POST   | /api/device/sync              | Submit fingerprint attendance  | API Key        |
| GET    | /api/device/mode              | Check device mode              | API Key (header) |
| POST   | /api/device/heartbeat         | Send heartbeat                 | API Key (header) |

**Sync Request Body:**
```json
{
  "apiKey": "device_api_key_here",
  "fingerprintId": 5,
  "timestamp": "2026-02-17T14:30:00"
}
```

**Sync Response (Success):**
```json
{
  "success": true,
  "message": "Attendance marked for Ahmad Ali (present)",
  "mode": "attendance"
}
```

### 11.7 Department Endpoints

| Method | Endpoint                      | Description                  | Roles                |
|--------|-------------------------------|------------------------------|----------------------|
| GET    | /api/departments              | List departments             | All (filtered)       |
| POST   | /api/departments              | Create a department          | Admin, Manager       |
| PUT    | /api/departments/:id          | Update a department          | Admin                |
| DELETE | /api/departments/:id          | Delete a department          | Admin                |

### 11.8 Fingerprint Endpoints

| Method | Endpoint                       | Description                  | Roles                |
|--------|--------------------------------|------------------------------|----------------------|
| GET    | /api/fingerprints/unassigned   | List unassigned fingerprints | Admin, Manager       |
| POST   | /api/fingerprints/assign       | Assign fingerprint to student| Admin, Manager       |
| DELETE | /api/fingerprints/:id          | Dismiss a fingerprint scan   | Admin, Manager       |

### 11.9 User Management Endpoints

| Method | Endpoint                       | Description                  | Roles     |
|--------|--------------------------------|------------------------------|-----------|
| GET    | /api/users                     | List all users               | Admin     |
| PUT    | /api/users/:id/role            | Update user role             | Admin     |
| DELETE | /api/users/:id/role            | Remove user role             | Admin     |
| DELETE | /api/users/:id                 | Delete user account          | Admin     |
| POST   | /api/users/invite              | Send invitation email        | Admin     |
| GET    | /api/users/invitations         | List pending invitations     | Admin     |
| DELETE | /api/users/invitations/:id     | Delete invitation            | Admin     |

### 11.10 Settings Endpoints

| Method | Endpoint                       | Description                  | Roles     |
|--------|--------------------------------|------------------------------|-----------|
| GET    | /api/settings/smtp             | Get SMTP configuration       | Admin     |
| PUT    | /api/settings/smtp             | Update SMTP configuration    | Admin     |
| POST   | /api/settings/smtp/test        | Test SMTP connection         | Admin     |

### 11.11 Dashboard Endpoint

| Method | Endpoint                       | Description                  | Roles            |
|--------|--------------------------------|------------------------------|------------------|
| GET    | /api/dashboard/stats           | Get dashboard statistics     | All (filtered)   |

---

## 12. Security Features

### 12.1 Authentication Security

- **Password Hashing** — All passwords are hashed using bcrypt with salt rounds before storage. Plain text passwords are never stored.
- **OTP Email Verification** — New registrations require a 6-digit OTP sent to the user's email. OTP codes expire after a set time period.
- **Session Management** — Server-side sessions stored in PostgreSQL with secure cookies. Sessions have expiration and automatic cleanup.
- **Rate Limiting** — Authentication endpoints are rate-limited to prevent brute-force attacks:
  - Login/Register: 10 attempts per 15-minute window per IP
  - Password Reset: 5 attempts per 15-minute window per IP
  - Returns HTTP 429 (Too Many Requests) when limit is exceeded

### 12.2 Authorization Security

- **Role-Based Access Control (RBAC)** — Four role levels with granular permissions enforced on both frontend and backend.
- **Server-Side Enforcement** — All API routes check user roles via `requireRole` middleware. Frontend role checks are supplementary.
- **Data Isolation** — Viewer and Class Admin roles can only access data related to their own student records. Database queries are filtered by user ID.
- **Self-Modification Protection** — Admins cannot change their own role to prevent accidental lockout.

### 12.3 Device Security

- **API Key Authentication** — Each ESP32 device has a unique API key generated on registration. All device endpoints verify the API key.
- **Device Activation Control** — Inactive devices are rejected by the server even with valid API keys.
- **Department Isolation** — Devices assigned to a department can only record attendance for students in that department.

### 12.4 Input Validation

- **Zod Schema Validation** — All API inputs are validated against Zod schemas before processing. Invalid inputs return HTTP 400 with detailed error messages.
- **Shared Schemas** — Validation schemas are shared between frontend and backend ensuring consistent validation rules.
- **SQL Injection Prevention** — Drizzle ORM uses parameterized queries, preventing SQL injection attacks.

### 12.5 Additional Security Measures

- **HTTPS** — Application deployed with TLS encryption via Replit's infrastructure.
- **Secure Cookies** — Session cookies use secure, httpOnly flags in production.
- **Expired Token Cleanup** — Background jobs periodically clean up expired verification codes and password reset tokens.
- **Bounded Rate Limiter** — Rate limit store has a maximum capacity of 10,000 entries with automatic cleanup to prevent memory exhaustion.

---

## 13. User Interface

### 13.1 Pages Overview

| Page                 | Route                  | Description                                    |
|----------------------|------------------------|------------------------------------------------|
| Login                | /login                 | Email/password login with registration link    |
| Register             | /register              | Student self-registration form                 |
| Dashboard            | /                      | Overview charts and statistics                 |
| Classes              | /classes               | Class management with cards/table              |
| Students             | /students              | Student list with search and filters           |
| Attendance           | /attendance            | Bulk attendance marking by class/date          |
| Devices              | /devices               | ESP32 device management                        |
| Departments          | /departments           | Department management                          |
| Assign Fingerprints  | /assign-fingerprints   | Link scanned fingerprints to students          |
| Reports              | /reports               | Attendance reports with filters                |
| Users                | /users                 | User and role management                       |
| Settings             | /settings              | SMTP and system configuration                  |
| 404 Not Found        | /* (catch-all)         | Friendly error page for invalid routes         |

### 13.2 Application Screenshots

#### 13.2.1 Login Page

**Fig 13.1: BioTrack Login Page**

![Login Page](docs/images/login_page.png)

The login page features a split-screen design with the BioTrack branding on the left (including system status indicator and version number) and the authentication form on the right. Users enter their email and password to sign in. The page also provides links to register a new account and reset a forgotten password.

#### 13.2.2 Users & Roles Page

**Fig 13.2: Users & Roles Management (Admin Only)**

![Users & Roles Page](docs/images/users_roles_page.png)

The Users & Roles page is accessible only to Admins. It displays all registered users grouped by their role (Admins, Managers, Class Admins, Viewers). The Admin can edit user roles, delete users, and send email invitations for new users. The sidebar navigation shows all available pages.

#### 13.2.3 Settings Page — ESP32 Setup Tab

**Fig 13.3: Settings - ESP32 Arduino Code**

![Settings ESP32 Setup](docs/images/settings_esp32.png)

The Settings page has four tabs. The ESP32 Setup tab displays the complete Arduino code (`biotrack_esp32.ino`) with a copy button, making it easy for administrators to configure and flash new ESP32 devices.

#### 13.2.4 Settings Page — Passwords Tab

**Fig 13.4: Settings - Password Reset**

![Settings Passwords](docs/images/settings_passwords.png)

The Passwords tab allows the Admin to reset any user's password. This is useful when a Viewer or Class Admin (who cannot use the forgot password feature) needs their password changed. The Admin selects the user and sets a new password.

#### 13.2.5 Settings Page — Email Tab

**Fig 13.5: Settings - SMTP Email Configuration**

![Settings Email](docs/images/settings_email.png)

The Email tab allows the Admin to configure the SMTP server used for sending OTP verification emails, invitation emails, and password reset emails. It includes fields for SMTP host, port, email address, password, and sender name, along with a "Test Connection" button to verify the configuration works.

#### 13.2.6 Settings Page — Database Tab

**Fig 13.6: Settings - Database Management**

![Settings Database](docs/images/settings_database.png)

The Database tab provides database management tools including backup (download all data as JSON), restore (upload a previously downloaded backup), optimize (clean up unused space and rebuild indexes), and reset (permanently delete all data except user accounts).

### 13.3 Design Features

- **Responsive Design** — Mobile-first approach with Tailwind CSS breakpoints. Full-width buttons and stacked layouts on mobile, side-by-side layouts on desktop.
- **Dark Mode** — Full dark mode support with CSS variable theming. Toggle between light and dark themes.
- **Loading States** — Skeleton loaders for tables and content while data is being fetched.
- **Empty States** — Contextual empty state messages with icons and guidance when no data exists.
- **Toast Notifications** — Success, error, and info toast messages for user feedback.
- **Form Validation** — Real-time form validation with error messages using React Hook Form and Zod.
- **Code Splitting** — Pages are lazy-loaded using React.lazy() for faster initial page load.

### 13.3 Progressive Web App (PWA)

BioTrack is installable as a Progressive Web App:
- **Manifest** — `manifest.json` with app name, icons, and standalone display mode
- **Service Worker** — Caches static assets, uses network-first strategy for API calls
- **Offline Fallback** — Basic offline page when network is unavailable
- **App Icons** — 192px and 512px maskable icons for home screen installation

---

## 14. How to Use the System

This section provides a step-by-step guide for using BioTrack, from initial setup to daily attendance operations.

### 14.1 Getting Started — First-Time Setup (Admin)

After deploying BioTrack, the Admin performs these one-time setup steps:

**Step 1: Configure SMTP Email (Before First Registration)**

Before anyone can register, the system needs email credentials to send OTP verification codes. Set these two environment variables on the server:
- `SMTP_USER` — Your email address (e.g., `yourname@gmail.com`)
- `SMTP_PASS` — Your email app password (for Gmail, generate an App Password from Google Account settings)

Without these, users will not receive the OTP verification code and will be unable to complete registration.

**Step 2: Register the Admin Account**
1. Open the BioTrack URL in a web browser.
2. Click "Don't have an account? Sign up" on the login page.
3. Fill in your name, email, and password.
4. Enter the 6-digit OTP sent to your email to verify your account.
5. **The system automatically detects this is the first user** and assigns the **Admin** role. No manual database changes are needed.
6. You are now the system administrator with full access to all features.

> **Note:** Only the very first registered user gets automatic Admin access. All subsequent users who register without an invitation are assigned the Viewer (read-only) role by default. The Admin can then invite other staff with Manager, Class Admin, or Viewer roles.

**Step 3: Configure Email Settings (Optional — In-App)**
1. Log in and navigate to **Settings** from the sidebar.
2. Click the **Email** tab.
3. You can update or change the SMTP settings from within the app if needed.
4. Click **Test Connection** to verify it works, then click **Save Settings**.

**Fig 14.1: SMTP Email Configuration**

![Settings Email](docs/images/settings_email.png)

**Step 4: Create Departments**
1. Navigate to **Departments** from the sidebar.
2. Click **Add Department**.
3. Enter the department name (e.g., "Computer Science"), description, and head of department.
4. Repeat for each department in your institution.

**Step 5: Create Classes**
1. Navigate to **Classes** from the sidebar.
2. Click **Add Class**.
3. Enter class details:
   - **Name** — e.g., "BSCS Morning Section A"
   - **Schedule Type** — Morning or Evening
   - **Start Time / End Time** — Class timing
   - **Late Time** — Time after which students are marked "Late" instead of "Present"
   - **Department** — Select from your created departments
   - **Session Dates** — Academic session start and end dates
4. Optionally generate an **Invite Code** so students can self-register into this class.

**Step 6: Register ESP32 Devices**
1. Navigate to **Devices** from the sidebar.
2. Click **Add Device**.
3. Enter a device name (e.g., "Lab 1 Scanner") and location.
4. The system generates a unique **API Key** — copy this for the ESP32 configuration.
5. Optionally assign the device to a department.

**Step 7: Flash the ESP32**
1. Go to **Settings > ESP32 Setup** tab.
2. Copy the Arduino code displayed on the page.
3. Open Arduino IDE, paste the code, and update:
   - WiFi credentials (`WIFI_SSID`, `WIFI_PASSWORD`)
   - Server URL (`SERVER_URL`)
   - API Key (`API_KEY`) — the one generated in Step 6
   - Timezone offset (`GMT_OFFSET`)
4. Upload the code to the ESP32.
5. The device should connect to WiFi and show "WiFi OK" on the LCD.

**Fig 14.2: ESP32 Setup Page with Arduino Code**

![Settings ESP32](docs/images/settings_esp32.png)

### 14.2 Inviting Users (Admin)

The Admin can invite other staff members to use the system:

1. Navigate to **Users & Roles** from the sidebar.
2. Scroll to the invitation section and click **Invite User**.
3. Enter the invitee's email address and select their role (Manager, Class Admin, or Viewer).
4. Click **Send Invitation** — an email is sent with a registration link.
5. The invitee registers using the link and is automatically assigned the specified role.

### 14.3 Registering Students

There are two ways to add students:

#### Method A: Admin/Manager Adds Students Manually
1. Navigate to **Students** from the sidebar.
2. Click **Register Student**.
3. Fill in the student's name, roll number, class, and department.
4. The student is created with "Active" status immediately.

**Fig 14.3: Students Page (Manager View)**

![Students Page](docs/images/students_page.png)

#### Method B: Students Self-Register
1. The Admin generates an **Invite Code** for a class (Classes page > click the invite icon on a class).
2. The invite code is shared with students (e.g., posted in the classroom).
3. Students visit the BioTrack registration page and click **Sign Up**.
4. They fill in their name, email, password, roll number, and enter the invite code (or select a class from the dropdown).
5. They verify their email with the OTP code.
6. Their student record is created with **"Pending"** status.
7. The Admin navigates to **Students > Pending** tab and **Approves** or **Rejects** each registration.
8. Approved students become "Active" and can use the system.

### 14.4 Enrolling Fingerprints

Before students can use the fingerprint scanner for attendance, their fingerprints must be enrolled:

1. **Admin switches device to Enroll mode:**
   - Go to **Devices** page.
   - Click the edit icon on the device and change its mode to **Enroll**.
   - The ESP32 automatically detects the mode change within 10 seconds.

2. **Student places finger on the scanner:**
   - The LCD shows "ENROLL MODE — Place new finger..."
   - Student places their finger on the R307 sensor.
   - The LCD prompts "Lift finger..." then "Place finger again."
   - Student places the same finger again for confirmation.
   - If successful, the LCD shows "Enrolled #X" (where X is the sensor slot number).

3. **Admin assigns the fingerprint to the student:**
   - Go to **Assign Fingerprints** page.
   - The unassigned fingerprint scan appears in the list.
   - Select the student from the dropdown and click **Assign**.
   - The student's record is now linked to their fingerprint ID.

4. **Admin switches device back to Attendance mode:**
   - Go to **Devices** page and change the mode back to **Attendance**.

### 14.5 Daily Attendance — Automatic (Fingerprint)

Once fingerprints are enrolled and the device is in Attendance mode:

1. Students arrive at the classroom.
2. Each student places their finger on the R307 sensor.
3. The ESP32 recognizes the fingerprint and sends it to the server.
4. The server checks:
   - Is the fingerprint assigned to a student? (If not, shows "Unknown finger" on LCD)
   - Has attendance already been recorded today? (If yes, shows "Already recorded")
   - Is the student late? (Compares scan time against the class late-time threshold)
5. The LCD shows "Attendance OK!" with a green LED blink for success.
6. The attendance record is saved with status: **Present** or **Late**.

### 14.6 Daily Attendance — Manual (Web Dashboard)

Admins, Managers, and Class Admins can also mark attendance manually:

1. Navigate to **Attendance** from the sidebar.
2. Select a **Class** from the dropdown.
3. Select the **Date** for which to mark attendance.
4. A list of all students in the class appears.
5. Set each student's status: Present, Absent, Late, Excused, or Leave.
6. Click **Save Attendance** to record all entries at once (bulk marking).

### 14.7 Viewing the Dashboard

The Dashboard provides an overview of attendance data. What you see depends on your role:

**Fig 14.4: Dashboard (Manager View)**

![Dashboard Manager View](docs/images/dashboard_manager.png)

**Admin/Manager Dashboard shows:**
- Total Students count
- Active Classes count
- Overall Attendance Rate
- Daily Attendance Trends chart (configurable: last 7, 14, or 30 days)
- Class-wise attendance summary
- Status breakdown (present/absent/late/excused/leave)
- Recent activity feed

**Viewer/Class Admin Dashboard shows:**
- The same layout, but all data is filtered to show only their own classes and attendance records.

### 14.8 Managing Passwords (Admin)

If a student or staff member forgets their password:

- **Admin/Manager users** can use the **Forgot Password** link on the login page. An OTP is sent to their email to reset the password.
- **Class Admin/Viewer users** cannot reset their own password. The Admin must reset it for them:
  1. Go to **Settings > Passwords** tab.
  2. Select the user from the dropdown.
  3. Enter a new password and click **Reset Password**.

**Fig 14.5: Admin Password Reset**

![Settings Passwords](docs/images/settings_passwords.png)

### 14.9 Database Backup and Restore (Admin)

The Admin can back up and restore all system data:

1. Go to **Settings > DB** tab.
2. Click **Download Backup** to save all data (classes, students, devices, attendance, roles) as a JSON file.
3. To restore, click **Upload Backup** and select a previously downloaded backup file.
4. Use **Optimize Database** to clean up unused space.
5. Use **Reset Database** to permanently delete all data (except user accounts) — use with caution.

**Fig 14.6: Database Management**

![Settings Database](docs/images/settings_database.png)

### 14.10 Viewing Reports

1. Navigate to **Reports** from the sidebar.
2. Apply filters:
   - **Class** — Filter by specific class
   - **Date Range** — Select start and end dates
   - **Status** — Filter by attendance status (Present, Absent, Late, etc.)
3. The filtered attendance records are displayed in a table.
4. Viewers and Class Admins can only see reports for their own student records.

### 14.11 Different User Level Views

Different roles see different sidebar menus and have different capabilities:

**Admin View — Full sidebar with all pages:**
- Dashboard, Classes, Students, Departments, Attendance, Devices, Assign Fingerprints, Reports, Users & Roles, Settings

**Manager View — Limited sidebar (no Devices, Users, Settings):**

**Fig 14.7: Manager View — Dashboard**

![Dashboard Manager](docs/images/dashboard_manager.png)

The Manager sees Dashboard, Classes, Students, Departments, Attendance, Assign Fingerprints, and Reports. They can create new classes and students, mark attendance, and assign fingerprints, but cannot manage devices, users, or system settings.

**Fig 14.8: Manager View — Students Page**

![Students Manager](docs/images/students_page.png)

The Manager's Students page shows the "Register Student" button (they can add students) and the full student table with search and class filter.

**Class Admin View — Minimal sidebar:**
- Dashboard, Classes, Students, Departments, Attendance, Reports
- Can mark attendance but everything else is read-only
- Data is filtered to show only their own classes and students

**Viewer View — Most restricted sidebar:**
- Dashboard, Classes, Students, Departments, Reports
- Everything is read-only — no attendance marking
- Data is filtered to show only their own records

### 14.12 Typical Daily Workflow

Here is how BioTrack is used on a typical day:

```
  Morning:
  ┌─────────────────────────────────────────────────────┐
  │ 1. ESP32 devices are powered on (always-on is best) │
  │ 2. Devices connect to WiFi and sync with server     │
  │ 3. LCD shows "ATTENDANCE — Place finger to scan"    │
  └─────────────────────────────────────────────────────┘
          │
          ▼
  During Class:
  ┌─────────────────────────────────────────────────────┐
  │ 4. Students scan their fingerprints as they arrive  │
  │ 5. LCD shows "Attendance OK!" for each scan         │
  │ 6. Late students are auto-detected based on time    │
  │ 7. Server records each attendance in real-time      │
  └─────────────────────────────────────────────────────┘
          │
          ▼
  After Class:
  ┌─────────────────────────────────────────────────────┐
  │ 8. Teacher/Admin opens the web dashboard            │
  │ 9. Checks attendance for the class                  │
  │ 10. Manually marks anyone who was excused/on leave  │
  │ 11. Reviews dashboard charts for trends             │
  └─────────────────────────────────────────────────────┘
          │
          ▼
  End of Day / Week:
  ┌─────────────────────────────────────────────────────┐
  │ 12. Admin reviews attendance reports                │
  │ 13. Admin creates database backup (optional)        │
  │ 14. Students check their own attendance via login   │
  └─────────────────────────────────────────────────────┘
```

### 14.13 Multi-College Deployment

BioTrack is designed so that each college or institution runs its own independent deployment. There is no shared central server — every deployment has its own database, user accounts, and web address.

**How it works:**

Each college deploys BioTrack separately, resulting in a unique URL for each:

| College              | BioTrack URL                               |
|----------------------|--------------------------------------------|
| ABC Engineering      | `https://abc-biotrack.replit.app`           |
| XYZ University       | `https://xyz-biotrack.replit.app`           |
| City College         | `https://city-college-biotrack.replit.app`  |

**Logging into a specific college:**

To access a particular college's BioTrack system, simply open that college's URL in your web browser and log in with the credentials you registered there. Each deployment is completely independent:

- Your account at College A is separate from your account at College B.
- Even if you use the same email address at two colleges, the accounts are independent with separate passwords and data.
- There is no "choose your college" screen — you go directly to the correct college's URL.

**Key points:**
- **Separate databases** — Each deployment stores its own students, classes, attendance, and devices. No data is shared between colleges.
- **Separate user accounts** — Admin, Manager, and student accounts are created per deployment. An Admin at one college has no access to another college's system.
- **Separate ESP32 devices** — Each college's fingerprint scanners connect only to their own BioTrack server using their own API keys.
- **Independent configuration** — Each college configures its own departments, classes, email settings, and device setup independently.

```
  College A BioTrack           College B BioTrack
  ┌──────────────────┐         ┌──────────────────┐
  │  Own Database     │         │  Own Database     │
  │  Own Users        │         │  Own Users        │
  │  Own Students     │         │  Own Students     │
  │  Own Devices      │         │  Own Devices      │
  │  Own URL          │         │  Own URL          │
  └──────────────────┘         └──────────────────┘
        ▲                            ▲
        │ (no connection)            │
        └────────────────────────────┘
          Completely Independent
```

---

## 15. Installation and Setup

### 14.1 Web Application Setup

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd biotrack
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   ```
   DATABASE_URL=postgresql://user:password@host:port/database
   SESSION_SECRET=your-random-secret-key
   SMTP_USER=your-email@gmail.com
   SMTP_PASS=your-app-password
   ```

4. **Push database schema**
   ```bash
   npm run db:push
   ```

5. **Start the application**
   ```bash
   npm run dev     # Development mode
   npm run build   # Production build
   npm start       # Production start
   ```

6. **Access the application** at `http://localhost:5000`

### 14.2 First-Time Admin Setup

1. Register the first user account through the registration page
2. The first registered user should be assigned the Admin role (done manually in the database or via the settings)
3. Log in as admin and configure SMTP settings (Settings page)
4. Create departments, classes, and register devices

### 14.3 ESP32 Device Setup

1. Install Arduino IDE (v2.x recommended)
2. Add ESP32 board support via Board Manager
3. Install required libraries:
   - Adafruit Fingerprint Sensor Library
   - Adafruit GFX Library
   - Adafruit ST7735 and ST7789 Library
4. Wire components according to the wiring diagram (Section 10.2)
5. Open `esp32/biotrack_esp32.ino` in Arduino IDE
6. Configure the following in the code:
   - `WIFI_SSID` and `WIFI_PASSWORD` — Your WiFi network
   - `SERVER_URL` — Your deployed BioTrack URL (e.g., `https://biotrack.replit.app`)
   - `API_KEY` — Get from the Devices page after registering the device
   - `GMT_OFFSET` and `DST_OFFSET` — Your timezone offset in seconds
7. Select board: "ESP32 Dev Module"
8. Upload the sketch
9. Monitor via Serial Monitor at 115200 baud

---

## 16. Testing

### 15.1 Testing Approach

The application was tested using:
- **End-to-End Testing** — Playwright-based automated testing of UI workflows
- **API Testing** — Direct HTTP requests to verify API responses and error handling
- **Rate Limiting Testing** — Verified that authentication endpoints return HTTP 429 after exceeding attempt limits
- **Role-Based Access Testing** — Verified that unauthorized users receive HTTP 403 for restricted endpoints
- **Device Integration Testing** — Verified ESP32 sync, heartbeat, and mode check endpoints

### 15.2 Key Test Scenarios

| Scenario                          | Expected Result                                           | Status  |
|-----------------------------------|-----------------------------------------------------------|---------|
| User registration with OTP        | OTP sent, verification creates account                    | Passed  |
| Login with correct credentials    | Session created, dashboard loaded                         | Passed  |
| Login with wrong credentials      | 401 error returned                                        | Passed  |
| Rate limiting (11 login attempts) | First 10 return 401, 11th returns 429                     | Passed  |
| Admin creates class               | Class created successfully (201)                          | Passed  |
| Viewer accesses devices page      | 403 Forbidden                                             | Passed  |
| ESP32 sync with valid fingerprint | Attendance recorded, success response                     | Passed  |
| ESP32 sync with unknown finger    | 404 with "not assigned" message                           | Passed  |
| Duplicate attendance same day     | Returns success with duplicate flag                       | Passed  |
| 404 page for unknown routes       | Friendly "Page Not Found" with back button                | Passed  |

---

## 17. Future Scope

1. **Mobile Application** — Develop a native mobile app (React Native) for on-the-go attendance management by teachers and administrators.

2. **Multiple Biometric Modalities** — Add support for facial recognition or iris scanning as alternative or additional biometric methods.

3. **Offline Attendance Sync** — Store attendance records locally on the ESP32 when WiFi is unavailable and sync when connectivity is restored.

4. **Attendance Analytics** — Advanced analytics with attendance patterns, student engagement scores, and predictive absence alerts.

5. **SMS Notifications** — Send SMS alerts to parents or guardians when students are marked absent.

6. **Batch Fingerprint Enrollment** — Streamline enrollment by supporting multiple fingerprint registrations in a single session.

7. **Multi-Campus Support** — Scale the system to support multiple campuses or branches of an institution.

8. **Export and Integration** — Export attendance data to Excel/PDF and integrate with existing Student Information Systems (SIS).

9. **Geo-Fencing** — Add location-based verification to ensure attendance is only marked within the institution premises.

10. **Dashboard Customization** — Allow admins to customize dashboard widgets and create custom reports.

---

## 18. Conclusion

BioTrack successfully demonstrates a practical, end-to-end biometric attendance management system suitable for educational institutions. By combining ESP32 microcontrollers with R307 fingerprint sensors and a modern web dashboard, the system eliminates proxy attendance, automates the recording process, and provides real-time data access to administrators and teachers.

Key achievements of this project include:
- A fully functional fingerprint-based attendance system with hardware and software integration
- A responsive, modern web dashboard with dark mode support and PWA capabilities
- Secure authentication with email verification and rate limiting
- Granular role-based access control supporting multiple organizational roles
- Student self-registration with admin approval workflow
- Real-time device health monitoring and remote mode management
- Department-based organization for multi-department institutions

The system is deployed and accessible via the web, making it easy to adopt without complex infrastructure requirements. The modular architecture allows for future enhancements such as mobile apps, additional biometric methods, and advanced analytics.

---

## 19. References

1. Espressif Systems. (2024). ESP32 Technical Reference Manual. https://www.espressif.com/en/products/socs/esp32
2. Adafruit Industries. (2024). Adafruit Fingerprint Sensor Library Documentation. https://github.com/adafruit/Adafruit-Fingerprint-Sensor-Library
3. React Team. (2024). React Documentation. https://react.dev
4. Express.js. (2024). Express - Node.js Web Application Framework. https://expressjs.com
5. Drizzle Team. (2024). Drizzle ORM Documentation. https://orm.drizzle.team
6. PostgreSQL Global Development Group. (2024). PostgreSQL Documentation. https://www.postgresql.org/docs
7. shadcn. (2024). shadcn/ui - Re-usable Components. https://ui.shadcn.com
8. Tailwind Labs. (2024). Tailwind CSS Documentation. https://tailwindcss.com
9. R307 Fingerprint Module Datasheet. Hangzhou Grow Technology Co., Ltd.
10. Sitronix Technology. ST7735S Datasheet - 262K Color Single-Chip TFT Controller/Driver.

---

*This document was prepared as part of the final year project submission for [Department Name], [College Name].*
