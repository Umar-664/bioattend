import { db } from "./db";
import {
  classes, students, devices, attendance, userRoles, users, invitations, scannedFingerprints, appSettings, departments,
  type Class, type InsertClass,
  type Student, type InsertStudent,
  type Device, type InsertDevice,
  type Attendance, type InsertAttendance,
  type UserRole, type InsertUserRole,
  type Invitation, type InsertInvitation,
  type ScannedFingerprint, type InsertScannedFingerprint,
  type AppSetting,
  type Department, type InsertDepartment
} from "@shared/schema";
import { eq, desc, and, sql, gte, lte, isNull } from "drizzle-orm";

export interface IStorage {
  // Classes
  getClasses(): Promise<Class[]>;
  getClass(id: number): Promise<Class | undefined>;
  createClass(cls: InsertClass): Promise<Class>;
  updateClass(id: number, updates: Partial<InsertClass>): Promise<Class | undefined>;
  deleteClass(id: number): Promise<void>;

  // Students
  getStudents(classId?: number, search?: string): Promise<Student[]>;
  getStudent(id: number): Promise<Student | undefined>;
  getStudentByFingerprint(fingerprintId: number): Promise<Student | undefined>;
  createStudent(student: InsertStudent): Promise<Student>;
  updateStudent(id: number, updates: Partial<InsertStudent>): Promise<Student | undefined>;
  deleteStudent(id: number): Promise<void>;

  // Devices
  getDevices(): Promise<Device[]>;
  getDevice(id: number): Promise<Device | undefined>;
  getDeviceByApiKey(apiKey: string): Promise<Device | undefined>;
  createDevice(device: InsertDevice): Promise<Device>;
  updateDevice(id: number, updates: Partial<InsertDevice>): Promise<Device | undefined>;
  deleteDevice(id: number): Promise<void>;
  updateDeviceLastSeen(id: number): Promise<void>;

  // Attendance
  getAttendance(classId?: number, date?: Date): Promise<(Attendance & { student: Student })[]>;
  getAttendanceReport(filters: { classId?: number; startDate?: Date; endDate?: Date; status?: string; teacherClassIds?: number[]; studentIds?: number[] }): Promise<(Attendance & { student: Student })[]>;
  createAttendance(record: InsertAttendance & { date?: Date }): Promise<Attendance>;
  bulkCreateAttendance(records: (InsertAttendance & { date?: Date })[]): Promise<Attendance[]>;
  hasAttendanceForStudentOnDate(studentId: number, date: Date): Promise<boolean>;
  
  // Departments
  getDepartments(): Promise<Department[]>;
  getDepartment(id: number): Promise<Department | undefined>;
  createDepartment(dept: InsertDepartment): Promise<Department>;
  updateDepartment(id: number, updates: Partial<InsertDepartment>): Promise<Department | undefined>;
  deleteDepartment(id: number): Promise<void>;

  // Department-scoped queries
  getClassesByDepartment(departmentId: number): Promise<Class[]>;

  // Users/Roles
  getAllUsers(): Promise<any[]>; // Returns joined user + role data
  getUserRole(userId: string): Promise<UserRole | undefined>;
  upsertUserRole(userId: string, role: string): Promise<UserRole>;
  hasAdminRole(): Promise<boolean>;

  deleteUserRole(userId: string): Promise<void>;
  deleteUser(userId: string): Promise<void>;

  // Invitations
  createInvitation(invitation: InsertInvitation): Promise<Invitation>;
  getInvitations(): Promise<Invitation[]>;
  getInvitationByEmail(email: string): Promise<Invitation | undefined>;
  deleteInvitation(id: number): Promise<void>;

  // Scanned Fingerprints
  saveScannedFingerprint(fp: InsertScannedFingerprint): Promise<ScannedFingerprint>;
  getUnassignedFingerprints(): Promise<(ScannedFingerprint & { device?: Device })[]>;
  assignFingerprintToStudent(scannedFingerprintId: number, studentId: number): Promise<{ success: boolean; message: string }>;
  markFingerprintAssigned(id: number): Promise<void>;
  deleteScannedFingerprint(id: number): Promise<void>;

  // App Settings
  getSetting(key: string): Promise<string | null>;
  getSettings(keys: string[]): Promise<Record<string, string>>;
  setSetting(key: string, value: string): Promise<void>;

  // Student approval
  getPendingStudents(): Promise<Student[]>;
  approveStudent(id: number): Promise<Student | undefined>;
  rejectStudent(id: number): Promise<void>;
  getStudentByUserId(userId: string): Promise<Student | undefined>;

  // Class invite codes
  generateClassInviteCode(classId: number): Promise<string>;
  getClassByInviteCode(code: string): Promise<Class | undefined>;

  // Password management
  resetUserPassword(userId: string, hashedPassword: string): Promise<boolean>;

  // Raw query helper
  rawQuery(query: string, params?: any[]): Promise<any[]>;

  // Teacher-filtered queries (for viewer role)
  getClassesByTeacher(userId: string): Promise<Class[]>;
  getStudentsForTeacher(userId: string, classId?: number, search?: string): Promise<Student[]>;
  getDashboardStatsForTeacher(userId: string, days: number): Promise<{
    dailyTrends: { date: string; present: number; absent: number; late: number; excused: number }[];
    classSummary: { classId: number; className: string; present: number; absent: number; late: number; total: number }[];
    statusBreakdown: { status: string; count: number }[];
    recentActivity: { id: number; studentName: string; status: string; className: string | null; date: Date | null; deviceId: number | null }[];
  }>;

  // Viewer/class_admin filtered queries
  getStudentClassIdsByUserId(userId: string): Promise<number[]>;
  getStudentsByUserId(userId: string): Promise<Student[]>;
  getStudentIdsByUserId(userId: string): Promise<number[]>;
  getAttendanceForStudents(studentIds: number[], classId?: number, date?: Date): Promise<(Attendance & { student: Student })[]>;

  // Dashboard
  getDashboardStats(days: number, classIds?: number[]): Promise<{
    dailyTrends: { date: string; present: number; absent: number; late: number; excused: number }[];
    classSummary: { classId: number; className: string; present: number; absent: number; late: number; total: number }[];
    statusBreakdown: { status: string; count: number }[];
    recentActivity: { id: number; studentName: string; status: string; className: string | null; date: Date | null; deviceId: number | null }[];
  }>;
}

export class DatabaseStorage implements IStorage {
  // Classes
  async getClasses(): Promise<Class[]> {
    return await db.select().from(classes).orderBy(classes.name);
  }

  async getClass(id: number): Promise<Class | undefined> {
    const [cls] = await db.select().from(classes).where(eq(classes.id, id));
    return cls;
  }

  async createClass(cls: InsertClass): Promise<Class> {
    const existing = await db.select().from(classes).where(
      and(
        eq(classes.name, cls.name),
        eq(classes.scheduleType, cls.scheduleType)
      )
    );
    if (existing.length > 0) {
      throw new Error("A class with this name and schedule type already exists");
    }
    const [newClass] = await db.insert(classes).values(cls).returning();
    return newClass;
  }

  async updateClass(id: number, updates: Partial<InsertClass>): Promise<Class | undefined> {
    const [updated] = await db.update(classes).set(updates).where(eq(classes.id, id)).returning();
    return updated;
  }

  async deleteClass(id: number): Promise<void> {
    await db.delete(classes).where(eq(classes.id, id));
  }

  // Students
  async getStudents(classId?: number, search?: string): Promise<Student[]> {
    let query = db.select().from(students);
    const conditions = [];
    
    conditions.push(sql`(${students.status} IS NULL OR ${students.status} != 'pending')`);
    if (classId) conditions.push(eq(students.classId, classId));
    if (search) conditions.push(sql`${students.name} ILIKE ${`%${search}%`}`);

    // @ts-ignore - complex types issue with drizzle array spread
    return await query.where(and(...conditions));
  }

  async getStudent(id: number): Promise<Student | undefined> {
    const [student] = await db.select().from(students).where(eq(students.id, id));
    return student;
  }

  async getStudentByFingerprint(fingerprintId: number): Promise<Student | undefined> {
    const [student] = await db.select().from(students).where(eq(students.fingerprintId, fingerprintId));
    return student;
  }

  async createStudent(student: InsertStudent): Promise<Student> {
    const existing = await db.select().from(students).where(
      eq(students.rollNumber, student.rollNumber)
    );
    if (existing.length > 0) {
      throw new Error("A student with this roll number already exists");
    }
    const [newStudent] = await db.insert(students).values(student).returning();
    return newStudent;
  }

  async updateStudent(id: number, updates: Partial<InsertStudent>): Promise<Student | undefined> {
    const [updated] = await db.update(students).set(updates).where(eq(students.id, id)).returning();
    return updated;
  }

  async deleteStudent(id: number): Promise<void> {
    await db.delete(students).where(eq(students.id, id));
  }

  // Devices
  async getDevices(): Promise<Device[]> {
    return await db.select().from(devices).orderBy(desc(devices.lastSeen));
  }

  async getDevice(id: number): Promise<Device | undefined> {
    const [device] = await db.select().from(devices).where(eq(devices.id, id));
    return device;
  }

  async getDeviceByApiKey(apiKey: string): Promise<Device | undefined> {
    const [device] = await db.select().from(devices).where(eq(devices.apiKey, apiKey));
    return device;
  }

  async createDevice(device: InsertDevice): Promise<Device> {
    const [newDevice] = await db.insert(devices).values(device).returning();
    return newDevice;
  }

  async updateDevice(id: number, updates: Partial<InsertDevice>): Promise<Device | undefined> {
    const [updated] = await db.update(devices).set(updates).where(eq(devices.id, id)).returning();
    return updated;
  }

  async deleteDevice(id: number): Promise<void> {
    await db.delete(devices).where(eq(devices.id, id));
  }

  async updateDeviceLastSeen(id: number): Promise<void> {
    await db.update(devices).set({ lastSeen: new Date() }).where(eq(devices.id, id));
  }

  // Attendance
  async getAttendance(classId?: number, date?: Date): Promise<(Attendance & { student: Student })[]> {
    const query = db.select({
      id: attendance.id,
      studentId: attendance.studentId,
      classId: attendance.classId,
      deviceId: attendance.deviceId,
      date: attendance.date,
      status: attendance.status,
      markedBy: attendance.markedBy,
      student: students
    })
    .from(attendance)
    .innerJoin(students, eq(attendance.studentId, students.id));

    const conditions = [];
    if (classId) conditions.push(eq(attendance.classId, classId));
    if (date) {
      const startOfDay = new Date(date);
      startOfDay.setHours(0,0,0,0);
      const endOfDay = new Date(date);
      endOfDay.setHours(23,59,59,999);
      conditions.push(and(sql`${attendance.date} >= ${startOfDay}`, sql`${attendance.date} <= ${endOfDay}`));
    }

    if (conditions.length > 0) {
      // @ts-ignore
      return await query.where(and(...conditions)).orderBy(desc(attendance.date));
    }
    
    return await query.orderBy(desc(attendance.date));
  }

  async getAttendanceReport(filters: { classId?: number; startDate?: Date; endDate?: Date; status?: string; teacherClassIds?: number[]; studentIds?: number[] }): Promise<(Attendance & { student: Student })[]> {
    const query = db.select({
      id: attendance.id,
      studentId: attendance.studentId,
      classId: attendance.classId,
      deviceId: attendance.deviceId,
      date: attendance.date,
      status: attendance.status,
      markedBy: attendance.markedBy,
      student: students
    })
    .from(attendance)
    .innerJoin(students, eq(attendance.studentId, students.id));

    const conditions = [];
    if (filters.classId) conditions.push(eq(attendance.classId, filters.classId));
    if (filters.status) conditions.push(eq(attendance.status, filters.status));
    if (filters.startDate) conditions.push(gte(attendance.date, filters.startDate));
    if (filters.endDate) {
      const end = new Date(filters.endDate);
      end.setHours(23, 59, 59, 999);
      conditions.push(lte(attendance.date, end));
    }
    if (filters.teacherClassIds && filters.teacherClassIds.length > 0) {
      conditions.push(sql`${attendance.classId} IN (${sql.join(filters.teacherClassIds.map(id => sql`${id}`), sql`, `)})`);
    }
    if (filters.studentIds && filters.studentIds.length > 0) {
      conditions.push(sql`${attendance.studentId} IN (${sql.join(filters.studentIds.map((id: number) => sql`${id}`), sql`, `)})`);
    }

    if (conditions.length > 0) {
      // @ts-ignore
      return await query.where(and(...conditions)).orderBy(desc(attendance.date));
    }

    return await query.orderBy(desc(attendance.date));
  }

  async createAttendance(record: InsertAttendance & { date?: Date }): Promise<Attendance> {
    const date = record.date || new Date();
    const dateStr = date.toISOString().split('T')[0];
    const existing = await db.select().from(attendance).where(
      and(
        eq(attendance.studentId, record.studentId),
        sql`DATE(${attendance.date}) = ${dateStr}`,
        record.classId ? eq(attendance.classId, record.classId) : undefined
      )
    );
    if (existing.length > 0) {
      const [updated] = await db.update(attendance)
        .set({ status: record.status, markedBy: record.markedBy })
        .where(eq(attendance.id, existing[0].id))
        .returning();
      return updated;
    }
    const [att] = await db.insert(attendance).values(record as any).returning();
    return att;
  }

  async hasAttendanceForStudentOnDate(studentId: number, date: Date): Promise<boolean> {
    const dateStr = date.toISOString().split('T')[0];
    const existing = await db.select({ id: attendance.id }).from(attendance).where(
      and(
        eq(attendance.studentId, studentId),
        sql`DATE(${attendance.date}) = ${dateStr}`
      )
    );
    return existing.length > 0;
  }

  async bulkCreateAttendance(records: (InsertAttendance & { date?: Date })[]): Promise<Attendance[]> {
    const results: Attendance[] = [];
    for (const record of records) {
      const result = await this.createAttendance(record);
      results.push(result);
    }
    return results;
  }

  // Departments
  async getDepartments(): Promise<Department[]> {
    return await db.select().from(departments).orderBy(desc(departments.createdAt));
  }

  async getDepartment(id: number): Promise<Department | undefined> {
    const [dept] = await db.select().from(departments).where(eq(departments.id, id));
    return dept;
  }

  async createDepartment(dept: InsertDepartment): Promise<Department> {
    const existing = await db.select().from(departments).where(eq(departments.name, dept.name));
    if (existing.length > 0) {
      throw new Error("A department with this name already exists");
    }
    const [newDept] = await db.insert(departments).values(dept).returning();
    return newDept;
  }

  async updateDepartment(id: number, updates: Partial<InsertDepartment>): Promise<Department | undefined> {
    if (updates.name) {
      const existing = await db.select().from(departments).where(and(eq(departments.name, updates.name), sql`${departments.id} != ${id}`));
      if (existing.length > 0) {
        throw new Error("A department with this name already exists");
      }
    }
    const [updated] = await db.update(departments).set(updates).where(eq(departments.id, id)).returning();
    return updated;
  }

  async deleteDepartment(id: number): Promise<void> {
    await db.delete(departments).where(eq(departments.id, id));
  }

  async getClassesByDepartment(departmentId: number): Promise<Class[]> {
    return await db.select().from(classes).where(eq(classes.departmentId, departmentId));
  }

  // Users/Roles
  async getAllUsers(): Promise<any[]> {
    const result = await db.select({
      id: users.id,
      email: users.email,
      firstName: users.firstName,
      lastName: users.lastName,
      role: userRoles.role
    })
    .from(users)
    .leftJoin(userRoles, eq(users.id, userRoles.userId));
    
    return result;
  }

  async getUserRole(userId: string): Promise<UserRole | undefined> {
    const [role] = await db.select().from(userRoles).where(eq(userRoles.userId, userId));
    return role;
  }

  async upsertUserRole(userId: string, role: string): Promise<UserRole> {
    const [newRole] = await db.insert(userRoles)
      .values({ userId, role })
      .onConflictDoUpdate({ target: userRoles.userId, set: { role } })
      .returning();
    return newRole;
  }

  async hasAdminRole(): Promise<boolean> {
    const [result] = await db.select({ count: sql<number>`count(*)` })
      .from(userRoles)
      .where(eq(userRoles.role, 'admin'));
    return (result?.count ?? 0) > 0;
  }

  // Invitations
  async createInvitation(invitation: InsertInvitation): Promise<Invitation> {
    const [newInv] = await db.insert(invitations).values(invitation).returning();
    return newInv;
  }

  async getInvitations(): Promise<Invitation[]> {
    return await db.select().from(invitations).orderBy(desc(invitations.createdAt));
  }

  async getInvitationByEmail(email: string): Promise<Invitation | undefined> {
    const [inv] = await db.select().from(invitations).where(eq(invitations.email, email));
    return inv;
  }

  async deleteUserRole(userId: string): Promise<void> {
    await db.delete(userRoles).where(eq(userRoles.userId, userId));
  }

  async deleteUser(userId: string): Promise<void> {
    await db.delete(userRoles).where(eq(userRoles.userId, userId));
    await db.execute(sql`DELETE FROM sessions WHERE sess->>'userId' = ${userId}`);
    await db.delete(users).where(eq(users.id, userId));
  }

  async deleteInvitation(id: number): Promise<void> {
    await db.delete(invitations).where(eq(invitations.id, id));
  }

  // Scanned Fingerprints
  async saveScannedFingerprint(fp: InsertScannedFingerprint): Promise<ScannedFingerprint> {
    const existing = await db.select().from(scannedFingerprints)
      .where(and(
        eq(scannedFingerprints.fingerprintId, fp.fingerprintId),
        eq(scannedFingerprints.assigned, false)
      ));
    if (existing.length > 0) {
      const [updated] = await db.update(scannedFingerprints)
        .set({ scannedAt: new Date(), deviceId: fp.deviceId })
        .where(eq(scannedFingerprints.id, existing[0].id))
        .returning();
      return updated;
    }
    const [newFp] = await db.insert(scannedFingerprints).values(fp).returning();
    return newFp;
  }

  async getUnassignedFingerprints(): Promise<(ScannedFingerprint & { device?: Device })[]> {
    const results = await db.select({
      id: scannedFingerprints.id,
      fingerprintId: scannedFingerprints.fingerprintId,
      deviceId: scannedFingerprints.deviceId,
      scannedAt: scannedFingerprints.scannedAt,
      assigned: scannedFingerprints.assigned,
      device: devices,
    })
    .from(scannedFingerprints)
    .leftJoin(devices, eq(scannedFingerprints.deviceId, devices.id))
    .where(eq(scannedFingerprints.assigned, false))
    .orderBy(desc(scannedFingerprints.scannedAt));

    return results.map(r => ({
      id: r.id,
      fingerprintId: r.fingerprintId,
      deviceId: r.deviceId,
      scannedAt: r.scannedAt,
      assigned: r.assigned,
      device: r.device || undefined,
    }));
  }

  async assignFingerprintToStudent(scannedFingerprintId: number, studentId: number): Promise<{ success: boolean; message: string }> {
    return await db.transaction(async (tx) => {
      const [fp] = await tx.select().from(scannedFingerprints).where(eq(scannedFingerprints.id, scannedFingerprintId));
      if (!fp) {
        const err: any = new Error("Scanned fingerprint not found");
        err.statusCode = 404;
        throw err;
      }

      const [student] = await tx.select().from(students).where(eq(students.id, studentId));
      if (!student) {
        const err: any = new Error("Student not found");
        err.statusCode = 404;
        throw err;
      }

      if (student.fingerprintId) {
        const err: any = new Error(`Student "${student.name}" already has fingerprint #${student.fingerprintId} assigned`);
        err.statusCode = 400;
        throw err;
      }

      const [existingStudent] = await tx.select().from(students).where(eq(students.fingerprintId, fp.fingerprintId));
      if (existingStudent) {
        const err: any = new Error(`Fingerprint #${fp.fingerprintId} is already assigned to "${existingStudent.name}"`);
        err.statusCode = 400;
        throw err;
      }

      await tx.update(students).set({ fingerprintId: fp.fingerprintId }).where(eq(students.id, studentId));
      await tx.update(scannedFingerprints).set({ assigned: true }).where(eq(scannedFingerprints.id, scannedFingerprintId));

      return { success: true, message: `Fingerprint #${fp.fingerprintId} assigned to ${student.name}` };
    });
  }

  async markFingerprintAssigned(id: number): Promise<void> {
    await db.update(scannedFingerprints)
      .set({ assigned: true })
      .where(eq(scannedFingerprints.id, id));
  }

  async deleteScannedFingerprint(id: number): Promise<void> {
    await db.delete(scannedFingerprints).where(eq(scannedFingerprints.id, id));
  }

  async getDashboardStats(days: number, classIds?: number[]) {
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);
    startDate.setHours(0, 0, 0, 0);

    const classFilter = classIds && classIds.length > 0
      ? sql` AND class_id IN (${sql.join(classIds.map(id => sql`${id}`), sql`, `)})`
      : sql``;

    const classFilterJoined = classIds && classIds.length > 0
      ? sql` AND a.class_id IN (${sql.join(classIds.map(id => sql`${id}`), sql`, `)})`
      : sql``;

    const dailyTrends = await db.execute(sql`
      SELECT 
        TO_CHAR(date, 'YYYY-MM-DD') as date,
        COUNT(*) FILTER (WHERE status = 'present') as present,
        COUNT(*) FILTER (WHERE status = 'absent') as absent,
        COUNT(*) FILTER (WHERE status = 'late') as late,
        COUNT(*) FILTER (WHERE status = 'excused') as excused,
        COUNT(*) FILTER (WHERE status = 'leave') as leave
      FROM attendance
      WHERE date >= ${startDate}${classFilter}
      GROUP BY TO_CHAR(date, 'YYYY-MM-DD')
      ORDER BY date ASC
    `);

    const classSummary = await db.execute(sql`
      SELECT 
        c.id as class_id,
        c.name as class_name,
        COUNT(*) FILTER (WHERE a.status = 'present') as present,
        COUNT(*) FILTER (WHERE a.status = 'absent') as absent,
        COUNT(*) FILTER (WHERE a.status = 'late') as late,
        COUNT(*) as total
      FROM attendance a
      INNER JOIN classes c ON a.class_id = c.id
      WHERE a.date >= ${startDate}${classFilterJoined}
      GROUP BY c.id, c.name
      ORDER BY c.name
    `);

    const statusBreakdown = await db.execute(sql`
      SELECT status, COUNT(*) as count
      FROM attendance
      WHERE date >= ${startDate}${classFilter}
      GROUP BY status
      ORDER BY count DESC
    `);

    const conditions = [gte(attendance.date, startDate)];
    if (classIds && classIds.length > 0) {
      conditions.push(sql`${attendance.classId} IN (${sql.join(classIds.map(id => sql`${id}`), sql`, `)})`);
    }

    const recentActivity = await db.select({
      id: attendance.id,
      studentName: students.name,
      status: attendance.status,
      className: classes.name,
      date: attendance.date,
      deviceId: attendance.deviceId,
    })
    .from(attendance)
    .innerJoin(students, eq(attendance.studentId, students.id))
    .leftJoin(classes, eq(attendance.classId, classes.id))
    // @ts-ignore
    .where(and(...conditions))
    .orderBy(desc(attendance.date))
    .limit(20);

    return {
      dailyTrends: (dailyTrends.rows as any[]).map(r => ({
        date: r.date,
        present: Number(r.present),
        absent: Number(r.absent),
        late: Number(r.late),
        excused: Number(r.excused),
        leave: Number(r.leave || 0),
      })),
      classSummary: (classSummary.rows as any[]).map(r => ({
        classId: Number(r.class_id),
        className: r.class_name,
        present: Number(r.present),
        absent: Number(r.absent),
        late: Number(r.late),
        total: Number(r.total),
      })),
      statusBreakdown: (statusBreakdown.rows as any[]).map(r => ({
        status: r.status,
        count: Number(r.count),
      })),
      recentActivity,
    };
  }

  async getPendingStudents(): Promise<Student[]> {
    return await db.select().from(students).where(eq(students.status, "pending")).orderBy(desc(students.createdAt));
  }

  async approveStudent(id: number): Promise<Student | undefined> {
    const [updated] = await db.update(students).set({ status: "active" }).where(eq(students.id, id)).returning();
    return updated;
  }

  async rejectStudent(id: number): Promise<void> {
    await db.delete(students).where(and(eq(students.id, id), eq(students.status, "pending")));
  }

  async getStudentByUserId(userId: string): Promise<Student | undefined> {
    const [student] = await db.select().from(students).where(eq(students.userId, userId));
    return student;
  }

  async getStudentClassIdsByUserId(userId: string): Promise<number[]> {
    const myStudents = await db.select({ classId: students.classId }).from(students).where(
      and(eq(students.userId, userId), sql`(${students.status} IS NULL OR ${students.status} != 'pending')`)
    );
    return myStudents.filter(s => s.classId !== null).map(s => s.classId as number);
  }

  async getStudentsByUserId(userId: string): Promise<Student[]> {
    return await db.select().from(students).where(
      and(eq(students.userId, userId), sql`(${students.status} IS NULL OR ${students.status} != 'pending')`)
    );
  }

  async getStudentIdsByUserId(userId: string): Promise<number[]> {
    const myStudents = await db.select({ id: students.id }).from(students).where(
      and(eq(students.userId, userId), sql`(${students.status} IS NULL OR ${students.status} != 'pending')`)
    );
    return myStudents.map(s => s.id);
  }

  async getAttendanceForStudents(studentIds: number[], classId?: number, date?: Date): Promise<(Attendance & { student: Student })[]> {
    const query = db.select({
      id: attendance.id,
      studentId: attendance.studentId,
      classId: attendance.classId,
      deviceId: attendance.deviceId,
      date: attendance.date,
      status: attendance.status,
      markedBy: attendance.markedBy,
      student: students
    })
    .from(attendance)
    .innerJoin(students, eq(attendance.studentId, students.id));

    const conditions: any[] = [
      sql`${attendance.studentId} IN (${sql.join(studentIds.map(id => sql`${id}`), sql`, `)})`
    ];
    if (classId) conditions.push(eq(attendance.classId, classId));
    if (date) {
      const startOfDay = new Date(date);
      startOfDay.setHours(0,0,0,0);
      const endOfDay = new Date(date);
      endOfDay.setHours(23,59,59,999);
      conditions.push(and(sql`${attendance.date} >= ${startOfDay}`, sql`${attendance.date} <= ${endOfDay}`));
    }

    // @ts-ignore
    return await query.where(and(...conditions)).orderBy(desc(attendance.date));
  }

  async generateClassInviteCode(classId: number): Promise<string> {
    const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    let code = "";
    for (let i = 0; i < 6; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    await db.update(classes).set({ inviteCode: code }).where(eq(classes.id, classId));
    return code;
  }

  async getClassByInviteCode(code: string): Promise<Class | undefined> {
    const [cls] = await db.select().from(classes).where(eq(classes.inviteCode, code.toUpperCase()));
    return cls;
  }

  async resetUserPassword(userId: string, hashedPassword: string): Promise<boolean> {
    const [updated] = await db.update(users)
      .set({ password: hashedPassword, updatedAt: new Date() })
      .where(eq(users.id, userId))
      .returning({ id: users.id });
    return !!updated;
  }

  async getClassesByTeacher(userId: string): Promise<Class[]> {
    return await db.select().from(classes).where(eq(classes.teacherId, userId)).orderBy(classes.name);
  }

  async getStudentsForTeacher(userId: string, classId?: number, search?: string): Promise<Student[]> {
    const teacherClasses = await db.select({ id: classes.id }).from(classes).where(eq(classes.teacherId, userId));
    const classIds = teacherClasses.map(c => c.id);

    if (classIds.length === 0) return [];

    const conditions = [
      sql`${students.classId} IN (${sql.join(classIds.map(id => sql`${id}`), sql`, `)})`,
      sql`(${students.status} IS NULL OR ${students.status} != 'pending')`,
    ];
    if (classId) conditions.push(eq(students.classId, classId));
    if (search) conditions.push(sql`${students.name} ILIKE ${`%${search}%`}`);

    // @ts-ignore
    return await db.select().from(students).where(and(...conditions));
  }

  async getDashboardStatsForTeacher(userId: string, days: number) {
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);
    startDate.setHours(0, 0, 0, 0);

    const teacherClasses = await db.select({ id: classes.id }).from(classes).where(eq(classes.teacherId, userId));
    const classIds = teacherClasses.map(c => c.id);

    if (classIds.length === 0) {
      return { dailyTrends: [], classSummary: [], statusBreakdown: [], recentActivity: [] };
    }

    const classIdList = classIds.join(',');

    const dailyTrends = await db.execute(sql`
      SELECT 
        TO_CHAR(date, 'YYYY-MM-DD') as date,
        COUNT(*) FILTER (WHERE status = 'present') as present,
        COUNT(*) FILTER (WHERE status = 'absent') as absent,
        COUNT(*) FILTER (WHERE status = 'late') as late,
        COUNT(*) FILTER (WHERE status = 'excused') as excused,
        COUNT(*) FILTER (WHERE status = 'leave') as leave
      FROM attendance
      WHERE date >= ${startDate} AND class_id IN (${sql.raw(classIdList)})
      GROUP BY TO_CHAR(date, 'YYYY-MM-DD')
      ORDER BY date ASC
    `);

    const classSummary = await db.execute(sql`
      SELECT 
        c.id as class_id,
        c.name as class_name,
        COUNT(*) FILTER (WHERE a.status = 'present') as present,
        COUNT(*) FILTER (WHERE a.status = 'absent') as absent,
        COUNT(*) FILTER (WHERE a.status = 'late') as late,
        COUNT(*) as total
      FROM attendance a
      INNER JOIN classes c ON a.class_id = c.id
      WHERE a.date >= ${startDate} AND c.id IN (${sql.raw(classIdList)})
      GROUP BY c.id, c.name
      ORDER BY c.name
    `);

    const statusBreakdown = await db.execute(sql`
      SELECT status, COUNT(*) as count
      FROM attendance
      WHERE date >= ${startDate} AND class_id IN (${sql.raw(classIdList)})
      GROUP BY status
      ORDER BY count DESC
    `);

    const classInCondition = sql`${attendance.classId} IN (${sql.join(classIds.map(id => sql`${id}`), sql`, `)})`;

    const recentActivity = await db.select({
      id: attendance.id,
      studentName: students.name,
      status: attendance.status,
      className: classes.name,
      date: attendance.date,
      deviceId: attendance.deviceId,
    })
    .from(attendance)
    .innerJoin(students, eq(attendance.studentId, students.id))
    .leftJoin(classes, eq(attendance.classId, classes.id))
    .where(and(gte(attendance.date, startDate), classInCondition))
    .orderBy(desc(attendance.date))
    .limit(20);

    return {
      dailyTrends: (dailyTrends.rows as any[]).map(r => ({
        date: r.date,
        present: Number(r.present),
        absent: Number(r.absent),
        late: Number(r.late),
        excused: Number(r.excused),
        leave: Number(r.leave || 0),
      })),
      classSummary: (classSummary.rows as any[]).map(r => ({
        classId: Number(r.class_id),
        className: r.class_name,
        present: Number(r.present),
        absent: Number(r.absent),
        late: Number(r.late),
        total: Number(r.total),
      })),
      statusBreakdown: (statusBreakdown.rows as any[]).map(r => ({
        status: r.status,
        count: Number(r.count),
      })),
      recentActivity,
    };
  }

  async getSetting(key: string): Promise<string | null> {
    const [row] = await db.select().from(appSettings).where(eq(appSettings.key, key));
    return row?.value ?? null;
  }

  async getSettings(keys: string[]): Promise<Record<string, string>> {
    const rows = await db.select().from(appSettings);
    const result: Record<string, string> = {};
    for (const row of rows) {
      if (keys.includes(row.key)) {
        result[row.key] = row.value;
      }
    }
    return result;
  }

  async setSetting(key: string, value: string): Promise<void> {
    const existing = await db.select().from(appSettings).where(eq(appSettings.key, key));
    if (existing.length > 0) {
      await db.update(appSettings).set({ value, updatedAt: new Date() }).where(eq(appSettings.key, key));
    } else {
      await db.insert(appSettings).values({ key, value });
    }
  }

  async rawQuery(query: string, params?: any[]): Promise<any[]> {
    const { pool } = await import("./db");
    const result = await pool.query(query, params);
    return result.rows;
  }
}

export const storage = new DatabaseStorage();
