import session from "express-session";
import type { Express, RequestHandler } from "express";
import connectPg from "connect-pg-simple";
import { authStorage } from "./storage";
import { storage } from "../../storage";
import { sendVerificationEmail, sendPasswordResetEmail } from "../../email";
import bcrypt from "bcryptjs";
import crypto from "crypto";
import { z } from "zod";
import { db } from "../../db";
import { pendingVerifications, passwordResets, users } from "@shared/schema";
import { eq, and, gt, lt } from "drizzle-orm";

const rateLimitStore = new Map<string, { count: number; resetAt: number }>();
const MAX_STORE_SIZE = 10000;

function rateLimit(windowMs: number, maxAttempts: number) {
  return (req: any, res: any, next: any) => {
    const ip = req.ip || req.connection.remoteAddress || "unknown";
    const key = `${ip}:${req.path}`;
    const now = Date.now();

    const entry = rateLimitStore.get(key);
    if (entry && now < entry.resetAt) {
      if (entry.count >= maxAttempts) {
        const retryAfter = Math.ceil((entry.resetAt - now) / 1000);
        return res.status(429).json({
          message: `Too many attempts. Please try again in ${retryAfter} seconds.`,
          retryAfter,
        });
      }
      entry.count++;
    } else {
      if (rateLimitStore.size >= MAX_STORE_SIZE) {
        const keysToDelete: string[] = [];
        rateLimitStore.forEach((e, k) => { if (now >= e.resetAt) keysToDelete.push(k); });
        keysToDelete.forEach(k => rateLimitStore.delete(k));
      }
      rateLimitStore.set(key, { count: 1, resetAt: now + windowMs });
    }
    next();
  };
}

const cleanupInterval = setInterval(() => {
  const now = Date.now();
  rateLimitStore.forEach((entry, key) => {
    if (now >= entry.resetAt) rateLimitStore.delete(key);
  });
}, 60_000);
cleanupInterval.unref();

const authRateLimit = rateLimit(15 * 60 * 1000, 10);
const strictRateLimit = rateLimit(15 * 60 * 1000, 5);

async function cleanupExpiredVerifications() {
  try {
    await db.delete(pendingVerifications).where(lt(pendingVerifications.expiresAt, new Date()));
  } catch (err) {
    console.error("Failed to cleanup expired verifications:", err);
  }
}

export function getSession() {
  const sessionTtl = 7 * 24 * 60 * 60 * 1000; // 1 week
  const pgStore = connectPg(session);
  const sessionStore = new pgStore({
    conString: process.env.DATABASE_URL,
    createTableIfMissing: false,
    ttl: sessionTtl,
    tableName: "sessions",
  });
  return session({
    secret: process.env.SESSION_SECRET || require("crypto").randomBytes(32).toString("hex"),
    store: sessionStore,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      maxAge: sessionTtl,
    },
  });
}

function generateOtp(): string {
  return crypto.randomInt(100000, 999999).toString();
}

const registerSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6, "Password must be at least 6 characters"),
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  classId: z.number().optional(),
  rollNumber: z.string().optional(),
});

const verifySchema = z.object({
  email: z.string().email(),
  code: z.string().length(6),
});

const resendSchema = z.object({
  email: z.string().email(),
});

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

const forgotPasswordSchema = z.object({
  email: z.string().email(),
});

const resetPasswordSchema = z.object({
  email: z.string().email(),
  code: z.string().length(6),
  newPassword: z.string().min(6, "Password must be at least 6 characters"),
});

export async function setupAuth(app: Express) {
  app.set("trust proxy", 1);
  app.use(getSession());

  app.post("/api/auth/register", authRateLimit, async (req, res) => {
    try {
      cleanupExpiredVerifications();
      const input = registerSchema.parse(req.body);
      const normalizedEmail = input.email.trim().toLowerCase();

      const existingUser = await authStorage.getUserByEmail(normalizedEmail);
      if (existingUser) {
        return res.status(409).json({ message: "An account with this email already exists" });
      }

      const hashedPassword = await bcrypt.hash(input.password, 10);
      const code = generateOtp();
      const expiresAt = new Date(Date.now() + 10 * 60 * 1000);

      await db.delete(pendingVerifications).where(eq(pendingVerifications.email, normalizedEmail));

      await db.insert(pendingVerifications).values({
        email: normalizedEmail,
        code,
        firstName: input.firstName,
        lastName: input.lastName,
        hashedPassword,
        classId: input.classId || null,
        rollNumber: input.rollNumber || null,
        expiresAt,
      });

      const sent = await sendVerificationEmail(input.email, code);

      res.status(200).json({
        requiresVerification: true,
        email: input.email,
        emailSent: sent,
        message: sent
          ? "Verification code sent to your email"
          : "SMTP not configured. Check server logs for the verification code.",
      });
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      console.error("Registration error:", err);
      res.status(500).json({ message: "Registration failed" });
    }
  });

  app.post("/api/auth/verify-email", strictRateLimit, async (req, res) => {
    try {
      const input = verifySchema.parse(req.body);
      const normalizedEmail = input.email.trim().toLowerCase();

      const [pending] = await db
        .select()
        .from(pendingVerifications)
        .where(
          and(
            eq(pendingVerifications.email, normalizedEmail),
            eq(pendingVerifications.code, input.code),
            gt(pendingVerifications.expiresAt, new Date())
          )
        );

      if (!pending) {
        return res.status(400).json({ message: "Invalid or expired verification code" });
      }

      const existingUser = await authStorage.getUserByEmail(normalizedEmail);
      if (existingUser) {
        await db.delete(pendingVerifications).where(eq(pendingVerifications.email, normalizedEmail));
        return res.status(409).json({ message: "An account with this email already exists" });
      }

      const user = await authStorage.upsertUser({
        email: pending.email,
        password: pending.hashedPassword,
        firstName: pending.firstName,
        lastName: pending.lastName,
      });

      if (user.email) {
        try {
          const invitation = await storage.getInvitationByEmail(user.email);
          if (invitation) {
            await storage.upsertUserRole(user.id, invitation.role);
            await storage.deleteInvitation(invitation.id);
          } else {
            const hasAdmin = await storage.hasAdminRole();
            if (!hasAdmin) {
              await storage.upsertUserRole(user.id, 'admin');
              console.log(`First user registered (${user.email}) — automatically assigned Admin role`);
            } else {
              await storage.upsertUserRole(user.id, 'viewer');
            }
          }
        } catch (err) {
          console.error("Error processing invitation/role on register:", err);
          await storage.upsertUserRole(user.id, 'viewer');
        }
      } else {
        await storage.upsertUserRole(user.id, 'viewer');
      }

      if (pending.classId && pending.rollNumber) {
        try {
          const cls = await storage.getClass(pending.classId);
          if (cls) {
            await storage.createStudent({
              name: `${pending.firstName} ${pending.lastName}`,
              rollNumber: pending.rollNumber,
              classId: pending.classId,
              departmentId: cls.departmentId,
              userId: user.id,
              status: "pending",
              fingerprintId: null,
            });
          }
        } catch (err) {
          console.error("Error creating pending student on register:", err);
        }
      }

      await db.delete(pendingVerifications).where(eq(pendingVerifications.email, input.email));

      (req.session as any).userId = user.id;

      const { password: _, ...safeUser } = user;
      res.status(201).json(safeUser);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input" });
      }
      console.error("Verification error:", err);
      res.status(500).json({ message: "Verification failed" });
    }
  });

  app.post("/api/auth/resend-code", strictRateLimit, async (req, res) => {
    try {
      const input = resendSchema.parse(req.body);
      const normalizedEmail = input.email.trim().toLowerCase();

      const [existing] = await db
        .select()
        .from(pendingVerifications)
        .where(eq(pendingVerifications.email, normalizedEmail));

      if (!existing) {
        return res.status(404).json({ message: "No pending registration found. Please register again." });
      }

      const code = generateOtp();
      const expiresAt = new Date(Date.now() + 10 * 60 * 1000);

      await db.delete(pendingVerifications).where(eq(pendingVerifications.email, normalizedEmail));

      await db.insert(pendingVerifications).values({
        email: existing.email,
        code,
        firstName: existing.firstName,
        lastName: existing.lastName,
        hashedPassword: existing.hashedPassword,
        classId: existing.classId,
        rollNumber: existing.rollNumber,
        expiresAt,
      });

      const sent = await sendVerificationEmail(input.email, code);

      res.json({
        emailSent: sent,
        message: sent
          ? "New verification code sent"
          : "SMTP not configured. Check server logs for the code.",
      });
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input" });
      }
      console.error("Resend code error:", err);
      res.status(500).json({ message: "Failed to resend code" });
    }
  });

  app.post("/api/auth/login", authRateLimit, async (req, res) => {
    try {
      const input = loginSchema.parse(req.body);

      const user = await authStorage.getUserByEmail(input.email.trim().toLowerCase());
      if (!user || !user.password) {
        return res.status(401).json({ message: "Invalid email or password" });
      }

      const validPassword = await bcrypt.compare(input.password, user.password);
      if (!validPassword) {
        return res.status(401).json({ message: "Invalid email or password" });
      }

      (req.session as any).userId = user.id;

      const { password: _, ...safeUser } = user;
      res.json(safeUser);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input" });
      }
      console.error("Login error:", err);
      res.status(500).json({ message: "Login failed" });
    }
  });

  app.post("/api/auth/forgot-password", strictRateLimit, async (req, res) => {
    try {
      const input = forgotPasswordSchema.parse(req.body);
      const normalizedEmail = input.email.trim().toLowerCase();

      const user = await authStorage.getUserByEmail(normalizedEmail);
      if (!user) {
        return res.json({ message: "If an account exists with that email, a reset code has been sent.", emailSent: true });
      }

      const userRole = await storage.getUserRole(user.id);
      const role = userRole?.role || 'viewer';
      if (role === 'viewer' || role === 'class_admin') {
        return res.status(403).json({ message: "Password reset is not available for your account type. Please contact an administrator." });
      }

      const code = generateOtp();
      const expiresAt = new Date(Date.now() + 10 * 60 * 1000);

      await db.delete(passwordResets).where(eq(passwordResets.email, normalizedEmail));

      await db.insert(passwordResets).values({
        email: normalizedEmail,
        code,
        expiresAt,
      });

      const sent = await sendPasswordResetEmail(normalizedEmail, code);

      res.json({
        emailSent: sent,
        message: sent
          ? "If an account exists with that email, a reset code has been sent."
          : "SMTP not configured. Check server logs for the code.",
      });
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid email address" });
      }
      console.error("Forgot password error:", err);
      res.status(500).json({ message: "Failed to process request" });
    }
  });

  app.post("/api/auth/reset-password", strictRateLimit, async (req, res) => {
    try {
      const input = resetPasswordSchema.parse(req.body);
      const normalizedEmail = input.email.trim().toLowerCase();

      const [resetEntry] = await db
        .select()
        .from(passwordResets)
        .where(
          and(
            eq(passwordResets.email, normalizedEmail),
            eq(passwordResets.code, input.code),
            gt(passwordResets.expiresAt, new Date())
          )
        );

      if (!resetEntry) {
        return res.status(400).json({ message: "Invalid or expired reset code" });
      }

      const user = await authStorage.getUserByEmail(normalizedEmail);
      if (!user) {
        return res.status(404).json({ message: "Account not found" });
      }

      const userRole = await storage.getUserRole(user.id);
      const role = userRole?.role || 'viewer';
      if (role === 'viewer' || role === 'class_admin') {
        await db.delete(passwordResets).where(eq(passwordResets.email, normalizedEmail));
        return res.status(403).json({ message: "Password reset is not available for your account type. Please contact an administrator." });
      }

      const hashedPassword = await bcrypt.hash(input.newPassword, 10);
      await db.update(users).set({ password: hashedPassword }).where(eq(users.id, user.id));

      await db.delete(passwordResets).where(eq(passwordResets.email, normalizedEmail));

      res.json({ message: "Password reset successfully. You can now log in with your new password." });
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      console.error("Reset password error:", err);
      res.status(500).json({ message: "Failed to reset password" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Logout failed" });
      }
      res.clearCookie("connect.sid");
      res.json({ message: "Logged out" });
    });
  });

  app.get("/api/logout", (req, res) => {
    req.session.destroy((err) => {
      res.redirect("/");
    });
  });
}

export const isAuthenticated: RequestHandler = async (req, res, next) => {
  const userId = (req.session as any)?.userId;
  if (!userId) {
    return res.status(401).json({ message: "Unauthorized" });
  }

  const user = await authStorage.getUser(userId);
  if (!user) {
    return res.status(401).json({ message: "Unauthorized" });
  }

  (req as any).user = { claims: { sub: user.id }, dbUser: user };
  next();
};
