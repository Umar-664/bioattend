import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api, errorSchemas } from "@shared/routes";
import { z } from "zod";
import { setupAuth, registerAuthRoutes } from "./replit_integrations/auth";
import { isAuthenticated } from "./replit_integrations/auth";
import { sendInvitationEmail, getSmtpSettings, updateSmtpSettings, testSmtpConnection } from "./email";
import { getDeviceConnectionStatus } from "./deviceHealthCheck";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Initialize Replit Auth
  await setupAuth(app);
  registerAuthRoutes(app);

  const getUserId = (req: any): string | null => {
    return req.user?.claims?.sub || null;
  };

  const requireRole = (allowedRoles: string[]) => {
    return async (req: any, res: any, next: any) => {
      isAuthenticated(req, res, async () => {
        const userId = getUserId(req);
        if (!userId) return res.sendStatus(401);

        const userRole = await storage.getUserRole(userId);
        const role = userRole?.role || 'viewer';

        if (allowedRoles.includes(role)) {
          next();
        } else {
          res.status(403).json({ message: "Forbidden" });
        }
      });
    };
  };

  // --- Current User Role ---
  app.get('/api/auth/role', isAuthenticated, async (req, res) => {
    const userId = getUserId(req)!;
    const userRole = await storage.getUserRole(userId);
    res.json({ role: userRole?.role || 'viewer' });
  });

  // --- Dashboard ---
  app.get('/api/dashboard/stats', isAuthenticated, async (req, res) => {
    try {
      const userId = getUserId(req)!;
      const userRole = await storage.getUserRole(userId);
      const role = userRole?.role || 'viewer';
      const days = Number(req.query.days) || 30;

      if (role === 'viewer' || role === 'class_admin') {
        const studentClassIds = await storage.getStudentClassIdsByUserId(userId);
        const stats = await storage.getDashboardStats(days, studentClassIds);
        res.json(stats);
      } else {
        const stats = await storage.getDashboardStats(days);
        res.json(stats);
      }
    } catch (err) {
      console.error('Dashboard stats error:', err);
      res.status(500).json({ message: "Failed to load dashboard stats" });
    }
  });

  // --- Classes ---
  app.get(api.classes.list.path, isAuthenticated, async (req, res) => {
    const userId = getUserId(req)!;
    const userRole = await storage.getUserRole(userId);
    const role = userRole?.role || 'viewer';

    if (role === 'viewer' || role === 'class_admin') {
      const studentClassIds = await storage.getStudentClassIdsByUserId(userId);
      if (studentClassIds.length === 0) {
        return res.json([]);
      }
      const allClasses = await storage.getClasses();
      const filtered = allClasses.filter(c => studentClassIds.includes(c.id));
      return res.json(filtered);
    }
    const classes = await storage.getClasses();
    res.json(classes);
  });

  app.post(api.classes.create.path, requireRole(['admin', 'manager']), async (req, res) => {
    try {
      const input = api.classes.create.input.parse(req.body);
      const cls = await storage.createClass(input);
      res.status(201).json(cls);
    } catch (err) {
      if (err instanceof z.ZodError) res.status(400).json(err.errors);
      else if (err instanceof Error && err.message.includes("already exists")) res.status(409).json({ message: err.message });
      else throw err;
    }
  });

  app.put(api.classes.update.path, requireRole(['admin']), async (req, res) => {
    try {
      const input = api.classes.update.input.parse(req.body);
      const cls = await storage.updateClass(Number(req.params.id), input);
      if (!cls) return res.sendStatus(404);
      res.json(cls);
    } catch (err) {
      if (err instanceof z.ZodError) res.status(400).json(err.errors);
      else throw err;
    }
  });

  app.delete(api.classes.delete.path, requireRole(['admin']), async (req, res) => {
    await storage.deleteClass(Number(req.params.id));
    res.sendStatus(204);
  });

  // --- Class Invite Codes ---
  app.post('/api/classes/:id/invite-code', requireRole(['admin']), async (req, res) => {
    try {
      const classId = Number(req.params.id);
      const cls = await storage.getClass(classId);
      if (!cls) return res.sendStatus(404);
      const code = await storage.generateClassInviteCode(classId);
      res.json({ inviteCode: code });
    } catch (err) {
      console.error("Generate invite code error:", err);
      res.status(500).json({ message: "Failed to generate invite code" });
    }
  });

  // Public endpoint: list classes for registration dropdown (no auth needed)
  app.get('/api/public/classes', async (_req, res) => {
    try {
      const allClasses = await storage.getClasses();
      const result = allClasses.map(c => ({ id: c.id, name: c.name, departmentId: c.departmentId }));
      res.set('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
      res.set('Content-Type', 'application/json');
      return res.status(200).send(JSON.stringify(result));
    } catch (err) {
      res.status(500).json({ message: "Failed to fetch classes" });
    }
  });

  // Public endpoint: validate invite code
  app.get('/api/public/invite-code/:code', async (req, res) => {
    try {
      const cls = await storage.getClassByInviteCode(req.params.code);
      if (!cls) return res.status(404).json({ message: "Invalid invite code" });
      res.json({ id: cls.id, name: cls.name, departmentId: cls.departmentId });
    } catch (err) {
      res.status(500).json({ message: "Failed to validate invite code" });
    }
  });

  // --- Pending Students (Admin Approval) ---
  app.get('/api/students/pending', requireRole(['admin', 'manager']), async (_req, res) => {
    try {
      const pending = await storage.getPendingStudents();
      res.json(pending);
    } catch (err) {
      res.status(500).json({ message: "Failed to fetch pending students" });
    }
  });

  app.post('/api/students/:id/approve', requireRole(['admin']), async (req, res) => {
    try {
      const student = await storage.approveStudent(Number(req.params.id));
      if (!student) return res.sendStatus(404);
      res.json(student);
    } catch (err) {
      res.status(500).json({ message: "Failed to approve student" });
    }
  });

  app.post('/api/students/:id/reject', requireRole(['admin']), async (req, res) => {
    try {
      await storage.rejectStudent(Number(req.params.id));
      res.sendStatus(204);
    } catch (err) {
      res.status(500).json({ message: "Failed to reject student" });
    }
  });

  // --- Students ---
  app.get(api.students.list.path, isAuthenticated, async (req, res) => {
    const userId = getUserId(req)!;
    const userRole = await storage.getUserRole(userId);
    const role = userRole?.role || 'viewer';
    const { classId, search } = req.query;

    if (role === 'viewer' || role === 'class_admin') {
      const myStudents = await storage.getStudentsByUserId(userId);
      return res.json(myStudents);
    }

    const students = await storage.getStudents(
      classId ? Number(classId) : undefined,
      search as string
    );
    res.json(students);
  });

  app.post(api.students.create.path, requireRole(['admin', 'manager']), async (req, res) => {
    try {
      const input = api.students.create.input.parse(req.body);
      const student = await storage.createStudent(input);
      res.status(201).json(student);
    } catch (err) {
      if (err instanceof z.ZodError) res.status(400).json(err.errors);
      else if (err instanceof Error && err.message.includes("already exists")) res.status(409).json({ message: err.message });
      else throw err;
    }
  });

  app.put(api.students.update.path, requireRole(['admin']), async (req, res) => {
    try {
      const input = api.students.update.input.parse(req.body);
      const student = await storage.updateStudent(Number(req.params.id), input);
      if (!student) return res.sendStatus(404);
      res.json(student);
    } catch (err) {
      if (err instanceof z.ZodError) res.status(400).json(err.errors);
      else throw err;
    }
  });

  app.delete(api.students.delete.path, requireRole(['admin']), async (req, res) => {
    await storage.deleteStudent(Number(req.params.id));
    res.sendStatus(204);
  });

  // --- Devices ---
  app.get(api.devices.list.path, requireRole(['admin']), async (req, res) => {
    const devices = await storage.getDevices();
    const enriched = devices.map(d => ({
      ...d,
      connectionStatus: getDeviceConnectionStatus(d.lastSeen),
    }));
    res.json(enriched);
  });

  app.post(api.devices.create.path, requireRole(['admin']), async (req, res) => {
    try {
      const input = api.devices.create.input.parse(req.body);
      const device = await storage.createDevice(input);
      res.status(201).json(device);
    } catch (err) {
      if (err instanceof z.ZodError) res.status(400).json(err.errors);
      else throw err;
    }
  });

  app.put(api.devices.update.path, requireRole(['admin']), async (req, res) => {
    try {
      const input = api.devices.update.input.parse(req.body);
      if (input.mode && !['attendance', 'enroll'].includes(input.mode)) {
        return res.status(400).json({ message: "Mode must be 'attendance' or 'enroll'" });
      }
      const device = await storage.updateDevice(Number(req.params.id), input);
      if (!device) return res.sendStatus(404);
      res.json(device);
    } catch (err) {
      if (err instanceof z.ZodError) res.status(400).json(err.errors);
      else throw err;
    }
  });

  app.delete(api.devices.delete.path, requireRole(['admin']), async (req, res) => {
    await storage.deleteDevice(Number(req.params.id));
    res.sendStatus(204);
  });

  // --- Departments ---
  app.get(api.departments.list.path, isAuthenticated, async (req, res) => {
    const userId = getUserId(req)!;
    const userRole = await storage.getUserRole(userId);
    const role = userRole?.role || 'viewer';

    if (role === 'viewer' || role === 'class_admin') {
      const myStudents = await storage.getStudentsByUserId(userId);
      const myDeptIds = Array.from(new Set(myStudents.filter(s => s.departmentId).map(s => s.departmentId as number)));
      if (myDeptIds.length === 0) return res.json([]);
      const allDepts = await storage.getDepartments();
      return res.json(allDepts.filter(d => myDeptIds.includes(d.id)));
    }

    const depts = await storage.getDepartments();
    res.json(depts);
  });

  app.post(api.departments.create.path, requireRole(['admin', 'manager']), async (req, res) => {
    try {
      const input = api.departments.create.input.parse(req.body);
      const dept = await storage.createDepartment(input);
      res.status(201).json(dept);
    } catch (err) {
      if (err instanceof z.ZodError) res.status(400).json(err.errors);
      else if (err instanceof Error && err.message.includes("already exists")) res.status(409).json({ message: err.message });
      else throw err;
    }
  });

  app.put(api.departments.update.path, requireRole(['admin']), async (req, res) => {
    try {
      const input = api.departments.update.input.parse(req.body);
      const dept = await storage.updateDepartment(Number(req.params.id), input);
      if (!dept) return res.sendStatus(404);
      res.json(dept);
    } catch (err) {
      if (err instanceof z.ZodError) res.status(400).json(err.errors);
      else if (err instanceof Error && err.message.includes("already exists")) res.status(409).json({ message: err.message });
      else throw err;
    }
  });

  app.delete(api.departments.delete.path, requireRole(['admin']), async (req, res) => {
    await storage.deleteDepartment(Number(req.params.id));
    res.sendStatus(204);
  });

  // --- Attendance ---
  app.get(api.attendance.list.path, isAuthenticated, async (req, res) => {
    const userId = getUserId(req)!;
    const userRole = await storage.getUserRole(userId);
    const role = userRole?.role || 'viewer';
    const { classId, date } = req.query;

    if (role === 'viewer' || role === 'class_admin') {
      const myStudentIds = await storage.getStudentIdsByUserId(userId);
      if (myStudentIds.length === 0) return res.json([]);
      const records = await storage.getAttendanceForStudents(
        myStudentIds,
        classId ? Number(classId) : undefined,
        date ? new Date(date as string) : undefined
      );
      return res.json(records);
    }

    const records = await storage.getAttendance(
      classId ? Number(classId) : undefined,
      date ? new Date(date as string) : undefined
    );
    res.json(records);
  });

  app.get(api.attendance.report.path, isAuthenticated, async (req, res) => {
    const userId = getUserId(req)!;
    const userRole = await storage.getUserRole(userId);
    const role = userRole?.role || 'viewer';
    const { classId, startDate, endDate, status } = req.query;

    const filters: any = {
      classId: classId ? Number(classId) : undefined,
      startDate: startDate ? new Date(startDate as string) : undefined,
      endDate: endDate ? new Date(endDate as string) : undefined,
      status: status as string | undefined,
    };

    if (role === 'viewer' || role === 'class_admin') {
      const myStudentIds = await storage.getStudentIdsByUserId(userId);
      if (myStudentIds.length === 0) return res.json([]);
      filters.studentIds = myStudentIds;
      const records = await storage.getAttendanceReport(filters);
      return res.json(records);
    }

    const records = await storage.getAttendanceReport(filters);
    res.json(records);
  });

  // Bulk Mark Attendance
  app.post(api.attendance.bulkMark.path, requireRole(['admin', 'manager', 'class_admin']), async (req, res) => {
    try {
      const input = api.attendance.bulkMark.input.parse(req.body);
      const userId = getUserId(req)!;
      
      const records = input.records.map(r => ({
        studentId: r.studentId,
        classId: input.classId,
        status: r.status,
        date: new Date(input.date),
        markedBy: userId
      }));

      const result = await storage.bulkCreateAttendance(records);
      res.json({ count: result.length });
    } catch (err) {
      if (err instanceof z.ZodError) res.status(400).json(err.errors);
      else throw err;
    }
  });

  // Device Sync Endpoint (ESP32)
  app.post(api.attendance.sync.path, async (req, res) => {
    try {
      const input = api.attendance.sync.input.parse(req.body);
      
      // Verify API Key
      const device = await storage.getDeviceByApiKey(input.apiKey);
      if (!device || !device.isActive) {
        return res.status(401).json({ message: "Invalid or inactive API Key" });
      }

      await storage.updateDeviceLastSeen(device.id);

      if (device.mode === "enroll") {
        await storage.saveScannedFingerprint({
          fingerprintId: input.fingerprintId,
          deviceId: device.id,
        });
        res.json({ success: true, message: `Fingerprint #${input.fingerprintId} enrolled and saved for assignment.`, mode: "enroll" });
      } else {
        const student = await storage.getStudentByFingerprint(input.fingerprintId);
        if (!student) {
          return res.status(404).json({ message: `Fingerprint #${input.fingerprintId} not assigned to any student.` });
        }

        if (device.departmentId && student.departmentId && device.departmentId !== student.departmentId) {
          return res.status(403).json({ message: `Student ${student.name} does not belong to this device's department.` });
        }

        let classId = student.classId;
        let status = 'present';

        if (device.departmentId && !classId) {
          const deptClasses = await storage.getClassesByDepartment(device.departmentId);
          if (deptClasses.length > 0) {
            const scanTime = input.timestamp ? new Date(input.timestamp) : new Date();
            const scanMinutes = scanTime.getHours() * 60 + scanTime.getMinutes();
            const matchedClass = deptClasses.find(cls => {
              const [sh, sm] = cls.startTime.split(':').map(Number);
              const [eh, em] = cls.endTime.split(':').map(Number);
              const startMin = sh * 60 + sm;
              const endMin = eh * 60 + em;
              return scanMinutes >= startMin && scanMinutes <= endMin;
            });
            if (matchedClass) {
              classId = matchedClass.id;
            }
          }
        }

        if (classId) {
          const cls = await storage.getClass(classId);
          if (cls?.lateTime) {
            const lateStr = typeof cls.lateTime === 'string' ? cls.lateTime : String(cls.lateTime);
            const [lh, lm] = lateStr.split(':').map(Number);
            if (!isNaN(lh) && !isNaN(lm)) {
              const scanTime = input.timestamp ? new Date(input.timestamp) : new Date();
              const lateMinutes = lh * 60 + lm;
              const scanMinutes = scanTime.getHours() * 60 + scanTime.getMinutes();
              if (scanMinutes > lateMinutes) {
                status = 'late';
              }
            }
          }
        }

        const attendanceDate = input.timestamp ? new Date(input.timestamp) : new Date();

        const alreadyRecorded = await storage.hasAttendanceForStudentOnDate(student.id, attendanceDate);
        if (alreadyRecorded) {
          return res.json({ success: true, message: `Attendance already recorded for ${student.name} today.`, mode: "attendance", duplicate: true });
        }

        await storage.createAttendance({
          studentId: student.id,
          deviceId: device.id,
          classId,
          status,
          date: attendanceDate,
        });

        res.json({ success: true, message: `Attendance marked for ${student.name} (${status})`, mode: "attendance" });
      }
    } catch (err) {
      console.error('Sync error:', err);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Device Mode Check Endpoint (ESP32 polls this to know its mode)
  app.get('/api/device/mode', async (req, res) => {
    try {
      const apiKey = req.headers['x-api-key'] as string || req.query.apiKey as string;
      if (!apiKey) return res.status(400).json({ message: "API key required" });

      const device = await storage.getDeviceByApiKey(apiKey);
      if (!device) return res.status(404).json({ message: "Device not found" });
      if (!device.isActive) return res.status(403).json({ message: "Device is inactive" });

      await storage.updateDeviceLastSeen(device.id);
      res.json({ mode: device.mode, deviceId: device.id, name: device.name });
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post('/api/device/heartbeat', async (req, res) => {
    try {
      const apiKey = req.headers['x-api-key'] as string || req.body?.apiKey as string;
      if (!apiKey) return res.status(400).json({ message: "API key required" });

      const device = await storage.getDeviceByApiKey(apiKey);
      if (!device) return res.status(404).json({ message: "Device not found" });
      if (!device.isActive) return res.status(403).json({ message: "Device is inactive" });

      await storage.updateDeviceLastSeen(device.id);
      res.json({ success: true, deviceId: device.id });
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // --- Fingerprint Management ---
  app.get(api.fingerprints.unassigned.path, requireRole(['admin', 'manager']), async (req, res) => {
    const fps = await storage.getUnassignedFingerprints();
    res.json(fps);
  });

  app.post(api.fingerprints.assign.path, requireRole(['admin', 'manager']), async (req, res) => {
    try {
      const input = api.fingerprints.assign.input.parse(req.body);
      const result = await storage.assignFingerprintToStudent(input.scannedFingerprintId, input.studentId);
      res.json(result);
    } catch (err: any) {
      if (err instanceof z.ZodError) return res.status(400).json(err.errors);
      if (err.statusCode) return res.status(err.statusCode).json({ message: err.message });
      throw err;
    }
  });

  app.delete(api.fingerprints.dismiss.path, requireRole(['admin', 'manager']), async (req, res) => {
    await storage.deleteScannedFingerprint(Number(req.params.id));
    res.sendStatus(204);
  });

  // --- Users & Invitations ---
  app.post('/api/device/ping', async (req, res) => {
    try {
      const { apiKey } = req.body;
      if (!apiKey) return res.status(400).json({ message: "API key required", status: "error" });

      const device = await storage.getDeviceByApiKey(apiKey);
      if (!device) return res.status(404).json({ message: "Invalid API key — device not found", status: "error" });
      if (!device.isActive) return res.status(403).json({ message: "Device is registered but marked as inactive", status: "inactive" });

      const lastSeen = device.lastSeen ? new Date(device.lastSeen) : null;
      const now = new Date();
      const minutesSinceLastSeen = lastSeen ? Math.round((now.getTime() - lastSeen.getTime()) / 60000) : null;

      let status: string;
      let message: string;

      if (!lastSeen) {
        status = "never_connected";
        message = `API key is valid but "${device.name}" has never connected to the server. Make sure the ESP32 is powered on and configured with this API key.`;
      } else if (minutesSinceLastSeen !== null && minutesSinceLastSeen <= 5) {
        status = "online";
        message = `"${device.name}" is online — last seen ${minutesSinceLastSeen} minute(s) ago.`;
      } else {
        status = "offline";
        const timeAgo = minutesSinceLastSeen !== null && minutesSinceLastSeen < 60
          ? `${minutesSinceLastSeen} minutes ago`
          : minutesSinceLastSeen !== null && minutesSinceLastSeen < 1440
          ? `${Math.round(minutesSinceLastSeen / 60)} hours ago`
          : lastSeen ? `on ${lastSeen.toLocaleDateString()}` : "unknown";
        message = `API key is valid but "${device.name}" appears offline. Last communication was ${timeAgo}. Check if the ESP32 is powered on and connected to WiFi.`;
      }

      res.json({
        status,
        message,
        device: { id: device.id, name: device.name, location: device.location },
        lastSeen: device.lastSeen,
        timestamp: now.toISOString(),
      });
    } catch (err) {
      res.status(500).json({ message: "Connection test failed", status: "error" });
    }
  });

  app.get(api.users.list.path, requireRole(['admin']), async (req, res) => {
    const users = await storage.getAllUsers();
    res.json(users);
  });

  app.put(api.users.updateRole.path, requireRole(['admin']), async (req, res) => {
    try {
      const currentUserId = getUserId(req)!;
      if (req.params.id === currentUserId) {
        return res.status(400).json({ message: "You cannot change your own role" });
      }
      const input = api.users.updateRole.input.parse(req.body);
      const role = await storage.upsertUserRole(req.params.id, input.role);
      res.json(role);
    } catch (err) {
      res.status(400).json({ message: "Invalid input" });
    }
  });

  app.post(api.users.invite.path, requireRole(['admin']), async (req, res) => {
    try {
      const userId = getUserId(req)!;
      const input = api.users.invite.input.parse({
        ...req.body,
        invitedBy: userId,
        expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) // 7 days
      });
      const invitation = await storage.createInvitation(input);

      const dbUser = (req as any).user?.dbUser;
      const inviterName = [dbUser?.firstName, dbUser?.lastName].filter(Boolean).join(" ") || dbUser?.email || "An admin";
      const emailSent = await sendInvitationEmail(input.email, input.role || "viewer", inviterName);

      res.status(201).json({ ...invitation, emailSent });
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        res.status(400).json(err.errors);
      } else if (err?.code === '23505' || err?.constraint) {
        res.status(409).json({ message: "This email has already been invited" });
      } else {
        res.status(500).json({ message: "Failed to create invitation" });
      }
    }
  });

  app.get(api.users.listInvitations.path, requireRole(['admin']), async (req, res) => {
    const invitations = await storage.getInvitations();
    res.json(invitations);
  });

  app.delete(api.users.deleteRole.path, requireRole(['admin']), async (req, res) => {
    const currentUserId = getUserId(req)!;
    if (req.params.id === currentUserId) {
      return res.status(400).json({ message: "You cannot remove your own role" });
    }
    await storage.upsertUserRole(req.params.id, 'viewer');
    res.status(204).send();
  });

  app.delete(api.users.deleteUser.path, requireRole(['admin']), async (req, res) => {
    const currentUserId = getUserId(req)!;
    if (req.params.id === currentUserId) {
      return res.status(400).json({ message: "You cannot delete your own account" });
    }
    await storage.deleteUser(req.params.id);
    res.status(204).send();
  });

  app.delete(api.users.deleteInvitation.path, requireRole(['admin']), async (req, res) => {
    await storage.deleteInvitation(Number(req.params.id));
    res.status(204).send();
  });

  // --- Admin Password Reset ---
  app.post('/api/admin/reset-password', requireRole(['admin']), async (req, res) => {
    try {
      const schema = z.object({
        userId: z.string().min(1, "User ID is required"),
        newPassword: z.string().min(6, "Password must be at least 6 characters"),
      });
      const input = schema.parse(req.body);

      const currentUserId = getUserId(req)!;
      if (input.userId === currentUserId) {
        return res.status(400).json({ message: "You cannot reset your own password here" });
      }

      const bcrypt = await import("bcryptjs");
      const hashedPassword = await bcrypt.hash(input.newPassword, 10);
      const updated = await storage.resetUserPassword(input.userId, hashedPassword);
      if (!updated) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json({ success: true, message: "Password has been reset successfully" });
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      console.error("Password reset error:", err);
      res.status(500).json({ message: "Failed to reset password" });
    }
  });

  // --- SMTP Settings (admin only) ---
  app.get('/api/settings/smtp', requireRole(['admin']), async (req, res) => {
    try {
      const settings = await getSmtpSettings();
      res.json(settings);
    } catch (err) {
      console.error('SMTP settings error:', err);
      res.status(500).json({ message: "Failed to load SMTP settings" });
    }
  });

  app.post('/api/settings/smtp', requireRole(['admin']), async (req, res) => {
    try {
      const { host, port, user, pass, fromName } = req.body;
      await updateSmtpSettings({ host, port, user, pass, fromName });
      res.json({ success: true, message: "SMTP settings saved" });
    } catch (err) {
      console.error('SMTP update error:', err);
      res.status(500).json({ message: "Failed to save SMTP settings" });
    }
  });

  app.post('/api/settings/smtp/test', requireRole(['admin']), async (req, res) => {
    try {
      const result = await testSmtpConnection();
      res.json(result);
    } catch (err) {
      console.error('SMTP test error:', err);
      res.status(500).json({ message: "Failed to test SMTP connection" });
    }
  });

  // --- Settings / Database Management (admin only) ---
  app.get('/api/settings/backup', requireRole(['admin']), async (req, res) => {
    try {
      const tables = ['users', 'user_roles', 'classes', 'students', 'devices', 'attendance', 'scanned_fingerprints'];
      const backup: Record<string, any[]> = {};

      for (const table of tables) {
        const result = await storage.rawQuery(`SELECT * FROM "${table}"`);
        backup[table] = result;
      }

      const filename = `biotrack_backup_${new Date().toISOString().slice(0, 10)}.json`;
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      res.setHeader('Content-Type', 'application/json');
      res.json({
        version: 1,
        createdAt: new Date().toISOString(),
        tables: backup,
      });
    } catch (err) {
      console.error('Backup error:', err);
      res.status(500).json({ message: "Failed to create backup" });
    }
  });

  app.post('/api/settings/restore', requireRole(['admin']), async (req, res) => {
    try {
      const { tables } = req.body;
      if (!tables || typeof tables !== 'object') {
        return res.status(400).json({ message: "Invalid backup file format" });
      }

      const currentUserId = (req.session as any)?.userId || getUserId(req);
      const hasUsersBackup = tables.users && Array.isArray(tables.users);
      const hasRolesBackup = tables.user_roles && Array.isArray(tables.user_roles);

      const dataTablesOrder = ['classes', 'students', 'devices', 'attendance', 'scanned_fingerprints'];
      const dataRestore = dataTablesOrder.filter(t => tables[t] && Array.isArray(tables[t]));

      const allUserIds = new Set<string>();
      if (hasUsersBackup) {
        for (const u of tables.users) {
          if (u.id) allUserIds.add(u.id);
        }
      }
      if (currentUserId) allUserIds.add(currentUserId);
      const existingUsers = await storage.rawQuery(`SELECT "id" FROM "users"`);
      for (const u of existingUsers) {
        allUserIds.add((u as any).id);
      }

      const existingDepartmentIds = new Set(
        (await storage.rawQuery(`SELECT "id" FROM "departments"`)).map((d: any) => d.id)
      );

      await storage.rawQuery('BEGIN');
      try {
        for (const table of [...dataRestore].reverse()) {
          await storage.rawQuery(`DELETE FROM "${table}"`);
        }

        if (hasUsersBackup) {
          if (hasRolesBackup) {
            if (currentUserId) {
              await storage.rawQuery(`DELETE FROM "user_roles" WHERE "userId" != $1`, [currentUserId]);
            } else {
              await storage.rawQuery(`DELETE FROM "user_roles"`);
            }
          }
          await storage.rawQuery(`DELETE FROM "invitations"`);
          if (currentUserId) {
            await storage.rawQuery(`DELETE FROM "users" WHERE "id" != $1`, [currentUserId]);
          } else {
            await storage.rawQuery(`DELETE FROM "users"`);
          }
        }

        let totalRows = 0;

        if (hasUsersBackup) {
          for (const row of tables.users) {
            if (currentUserId && row.id === currentUserId) continue;
            const cols = Object.keys(row).filter(c => row[c] !== undefined);
            const vals = cols.map((_, i) => `$${i + 1}`);
            await storage.rawQuery(
              `INSERT INTO "users" (${cols.map(c => `"${c}"`).join(', ')}) VALUES (${vals.join(', ')}) ON CONFLICT DO NOTHING`,
              cols.map(c => row[c])
            );
          }
          totalRows += tables.users.length;
        }

        if (hasRolesBackup) {
          for (const row of tables.user_roles) {
            if (currentUserId && row.userId === currentUserId) continue;
            if (row.userId && !allUserIds.has(row.userId)) continue;
            const cols = Object.keys(row).filter(c => row[c] !== undefined);
            const vals = cols.map((_, i) => `$${i + 1}`);
            await storage.rawQuery(
              `INSERT INTO "user_roles" (${cols.map(c => `"${c}"`).join(', ')}) VALUES (${vals.join(', ')}) ON CONFLICT DO NOTHING`,
              cols.map(c => row[c])
            );
          }
          totalRows += tables.user_roles.length;
        }

        for (const table of dataRestore) {
          const rows = tables[table];
          for (const row of rows) {
            if (row.userId && !allUserIds.has(row.userId)) {
              row.userId = null;
            }
            if (row.teacherId && !allUserIds.has(row.teacherId)) {
              row.teacherId = null;
            }
            if (row.departmentId && !existingDepartmentIds.has(row.departmentId)) {
              row.departmentId = null;
            }
            const cols = Object.keys(row).filter(c => row[c] !== undefined);
            const vals = cols.map((_, i) => `$${i + 1}`);
            await storage.rawQuery(
              `INSERT INTO "${table}" (${cols.map(c => `"${c}"`).join(', ')}) VALUES (${vals.join(', ')}) ON CONFLICT DO NOTHING`,
              cols.map(c => row[c])
            );
          }
          totalRows += rows.length;
        }

        await storage.rawQuery('COMMIT');
        res.json({ success: true, message: `Restored ${totalRows} records` });
      } catch (innerErr) {
        await storage.rawQuery('ROLLBACK');
        throw innerErr;
      }
    } catch (err) {
      console.error('Restore error:', err);
      res.status(500).json({ message: "Failed to restore backup: " + (err as Error).message });
    }
  });

  app.post('/api/settings/optimize', requireRole(['admin']), async (req, res) => {
    try {
      const tables = ['classes', 'students', 'devices', 'attendance', 'scanned_fingerprints', 'user_roles', 'invitations', 'users', 'sessions'];
      let analyzed = 0;
      for (const table of tables) {
        try {
          await storage.rawQuery(`ANALYZE "${table}"`);
          analyzed++;
        } catch { /* skip tables that don't exist */ }
      }

      const tableStats = await storage.rawQuery(`
        SELECT relname AS table_name, 
               n_live_tup AS row_count,
               n_dead_tup AS dead_rows,
               last_analyze
        FROM pg_stat_user_tables 
        ORDER BY n_live_tup DESC
      `);

      const totalRows = tableStats.reduce((sum: number, t: any) => sum + Number(t.row_count || 0), 0);
      const totalDead = tableStats.reduce((sum: number, t: any) => sum + Number(t.dead_rows || 0), 0);

      res.json({ 
        success: true, 
        message: `Database optimized: ${analyzed} tables analyzed, ${totalRows} total rows, ${totalDead} stale rows found` 
      });
    } catch (err) {
      console.error('Optimize error:', err);
      res.status(500).json({ message: "Failed to optimize database" });
    }
  });

  app.post('/api/settings/reset', requireRole(['admin']), async (req, res) => {
    try {
      const { confirmText } = req.body;
      if (confirmText !== 'RESET') {
        return res.status(400).json({ message: "Type RESET to confirm" });
      }

      const userId = getUserId(req)!;

      const tables = ['attendance', 'scanned_fingerprints', 'students', 'devices', 'classes', 'invitations', 'user_roles'];
      for (const table of tables) {
        await storage.rawQuery(`DELETE FROM "${table}"`);
      }

      await storage.upsertUserRole(userId, 'admin');

      res.json({ success: true, message: "All data has been reset" });
    } catch (err) {
      console.error('Reset error:', err);
      res.status(500).json({ message: "Failed to reset database" });
    }
  });

  return httpServer;
}
