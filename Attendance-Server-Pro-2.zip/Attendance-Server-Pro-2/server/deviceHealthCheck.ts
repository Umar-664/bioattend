import { storage } from "./storage";
import { log } from "./index";

const OFFLINE_THRESHOLD_MS = 60 * 1000;
const CHECK_INTERVAL_MS = 60 * 1000;

export function getDeviceConnectionStatus(lastSeen: Date | null): "online" | "offline" | "never_connected" {
  if (!lastSeen) return "never_connected";
  const diff = Date.now() - new Date(lastSeen).getTime();
  return diff <= OFFLINE_THRESHOLD_MS ? "online" : "offline";
}

export function startDeviceHealthCheck() {
  log("Device health check started (every 60s)", "health");

  setInterval(async () => {
    try {
      const devices = await storage.getDevices();
      const now = Date.now();
      let onlineCount = 0;
      let offlineCount = 0;

      for (const device of devices) {
        if (!device.isActive) continue;

        if (!device.lastSeen) {
          offlineCount++;
          continue;
        }

        const diff = now - new Date(device.lastSeen).getTime();
        if (diff <= OFFLINE_THRESHOLD_MS) {
          onlineCount++;
        } else {
          offlineCount++;
        }
      }

      log(`Health check: ${onlineCount} online, ${offlineCount} offline out of ${devices.length} devices`, "health");
    } catch (err) {
      console.error("[health] Device health check error:", err);
    }
  }, CHECK_INTERVAL_MS);
}
