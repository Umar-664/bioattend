import nodemailer from "nodemailer";
import { storage } from "./storage";

const SMTP_KEYS = ["smtp_host", "smtp_port", "smtp_user", "smtp_pass", "smtp_from_name"];

async function getSmtpConfig() {
  const dbSettings = await storage.getSettings(SMTP_KEYS);

  return {
    host: dbSettings.smtp_host || process.env.SMTP_HOST || "smtp.gmail.com",
    port: Number(dbSettings.smtp_port || process.env.SMTP_PORT || "587"),
    user: dbSettings.smtp_user || process.env.SMTP_USER || "",
    pass: dbSettings.smtp_pass || process.env.SMTP_PASS || "",
    fromName: dbSettings.smtp_from_name || "BioTrack",
  };
}

function createTransporter(config: { host: string; port: number; user: string; pass: string }) {
  return nodemailer.createTransport({
    host: config.host,
    port: config.port,
    secure: config.port === 465,
    auth: {
      user: config.user,
      pass: config.pass,
    },
  });
}

export async function getSmtpSettings() {
  const dbSettings = await storage.getSettings(SMTP_KEYS);
  const user = dbSettings.smtp_user || process.env.SMTP_USER || "";
  const hasPass = !!(dbSettings.smtp_pass || process.env.SMTP_PASS);
  return {
    host: dbSettings.smtp_host || process.env.SMTP_HOST || "smtp.gmail.com",
    port: dbSettings.smtp_port || process.env.SMTP_PORT || "587",
    user,
    pass: hasPass ? "********" : "",
    fromName: dbSettings.smtp_from_name || "BioTrack",
    configured: !!(user && hasPass),
  };
}

export async function updateSmtpSettings(settings: {
  host?: string;
  port?: string;
  user?: string;
  pass?: string;
  fromName?: string;
}) {
  if (settings.host !== undefined) await storage.setSetting("smtp_host", settings.host);
  if (settings.port !== undefined) await storage.setSetting("smtp_port", settings.port);
  if (settings.user !== undefined) await storage.setSetting("smtp_user", settings.user);
  if (settings.pass !== undefined && settings.pass !== "********") await storage.setSetting("smtp_pass", settings.pass);
  if (settings.fromName !== undefined) await storage.setSetting("smtp_from_name", settings.fromName);
}

export async function testSmtpConnection(): Promise<{ success: boolean; message: string }> {
  const config = await getSmtpConfig();

  if (!config.user || !config.pass) {
    return { success: false, message: "SMTP credentials not configured" };
  }

  try {
    const transporter = createTransporter(config);
    await transporter.verify();
    return { success: true, message: "SMTP connection successful" };
  } catch (error: any) {
    return { success: false, message: error.message || "Connection failed" };
  }
}

export async function sendVerificationEmail(
  toEmail: string,
  code: string
): Promise<boolean> {
  const config = await getSmtpConfig();

  if (!config.user || !config.pass) {
    console.log(`[Email] SMTP not configured. Verification code for ${toEmail}: ${code}`);
    return false;
  }

  const transporter = createTransporter(config);

  const mailOptions = {
    from: `"${config.fromName}" <${config.user}>`,
    to: toEmail,
    subject: `${code} - Your BioTrack Verification Code`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="background: #1e293b; padding: 24px; border-radius: 12px 12px 0 0; text-align: center;">
          <h1 style="color: white; margin: 0; font-size: 24px;">${config.fromName}</h1>
          <p style="color: #94a3b8; margin: 8px 0 0 0; font-size: 14px;">Email Verification</p>
        </div>
        <div style="background: #ffffff; padding: 32px; border: 1px solid #e2e8f0; border-top: none; border-radius: 0 0 12px 12px;">
          <h2 style="color: #1e293b; margin-top: 0;">Verify your email</h2>
          <p style="color: #475569; line-height: 1.6;">
            Enter this code to complete your registration:
          </p>
          <div style="text-align: center; margin: 32px 0;">
            <div style="background: #f1f5f9; border: 2px dashed #cbd5e1; border-radius: 12px; padding: 20px; display: inline-block;">
              <span style="font-size: 36px; font-weight: 700; letter-spacing: 8px; color: #1e293b; font-family: monospace;">${code}</span>
            </div>
          </div>
          <p style="color: #94a3b8; font-size: 12px; margin-bottom: 0;">
            This code expires in 10 minutes. If you didn't request this, you can safely ignore this email.
          </p>
        </div>
      </div>
    `,
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log(`[Email] Verification code sent to ${toEmail}`);
    return true;
  } catch (error) {
    console.error(`[Email] Failed to send verification email to ${toEmail}:`, error);
    return false;
  }
}

export async function sendPasswordResetEmail(
  toEmail: string,
  code: string
): Promise<boolean> {
  const config = await getSmtpConfig();

  if (!config.user || !config.pass) {
    console.log(`[Email] SMTP not configured. Password reset code for ${toEmail}: ${code}`);
    return false;
  }

  const transporter = createTransporter(config);

  const mailOptions = {
    from: `"${config.fromName}" <${config.user}>`,
    to: toEmail,
    subject: `${code} - Your BioTrack Password Reset Code`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="background: #1e293b; padding: 24px; border-radius: 12px 12px 0 0; text-align: center;">
          <h1 style="color: white; margin: 0; font-size: 24px;">${config.fromName}</h1>
          <p style="color: #94a3b8; margin: 8px 0 0 0; font-size: 14px;">Password Reset</p>
        </div>
        <div style="background: #ffffff; padding: 32px; border: 1px solid #e2e8f0; border-top: none; border-radius: 0 0 12px 12px;">
          <h2 style="color: #1e293b; margin-top: 0;">Reset your password</h2>
          <p style="color: #475569; line-height: 1.6;">
            Enter this code to reset your password:
          </p>
          <div style="text-align: center; margin: 32px 0;">
            <div style="background: #f1f5f9; border: 2px dashed #cbd5e1; border-radius: 12px; padding: 20px; display: inline-block;">
              <span style="font-size: 36px; font-weight: 700; letter-spacing: 8px; color: #1e293b; font-family: monospace;">${code}</span>
            </div>
          </div>
          <p style="color: #94a3b8; font-size: 12px; margin-bottom: 0;">
            This code expires in 10 minutes. If you didn't request this, you can safely ignore this email.
          </p>
        </div>
      </div>
    `,
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log(`[Email] Password reset code sent to ${toEmail}`);
    return true;
  } catch (error) {
    console.error(`[Email] Failed to send password reset email to ${toEmail}:`, error);
    return false;
  }
}

export async function sendInvitationEmail(
  toEmail: string,
  role: string,
  inviterName: string
): Promise<boolean> {
  const config = await getSmtpConfig();

  if (!config.user || !config.pass) {
    console.log(`[Email] SMTP not configured. Invitation for ${toEmail} saved but email not sent.`);
    return false;
  }

  const appUrl = process.env.REPLIT_DEV_DOMAIN
    ? `https://${process.env.REPLIT_DEV_DOMAIN}`
    : process.env.REPL_SLUG
      ? `https://${process.env.REPL_SLUG}.${process.env.REPL_OWNER}.repl.co`
      : "the application";

  const transporter = createTransporter(config);

  const mailOptions = {
    from: `"${config.fromName}" <${config.user}>`,
    to: toEmail,
    subject: "You've been invited to BioTrack",
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="background: #1e293b; padding: 24px; border-radius: 12px 12px 0 0; text-align: center;">
          <h1 style="color: white; margin: 0; font-size: 24px;">${config.fromName}</h1>
          <p style="color: #94a3b8; margin: 8px 0 0 0; font-size: 14px;">Biometric Attendance Management</p>
        </div>
        <div style="background: #ffffff; padding: 32px; border: 1px solid #e2e8f0; border-top: none; border-radius: 0 0 12px 12px;">
          <h2 style="color: #1e293b; margin-top: 0;">You've been invited!</h2>
          <p style="color: #475569; line-height: 1.6;">
            <strong>${inviterName}</strong> has invited you to join ${config.fromName} as a <strong style="text-transform: capitalize;">${role}</strong>.
          </p>
          <p style="color: #475569; line-height: 1.6;">
            Click the button below to sign in and get started:
          </p>
          <div style="text-align: center; margin: 32px 0;">
            <a href="${appUrl}" style="background: #3b82f6; color: white; padding: 12px 32px; border-radius: 8px; text-decoration: none; font-weight: 600; display: inline-block;">
              Sign In to ${config.fromName}
            </a>
          </div>
          <p style="color: #94a3b8; font-size: 12px; margin-bottom: 0;">
            This invitation will expire in 7 days. If you didn't expect this email, you can safely ignore it.
          </p>
        </div>
      </div>
    `,
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log(`[Email] Invitation email sent to ${toEmail}`);
    return true;
  } catch (error) {
    console.error(`[Email] Failed to send invitation email to ${toEmail}:`, error);
    return false;
  }
}
