# BioTrack ESP32 Wiring Diagram

## Components
- 1x ESP32 DevKit V1 (30-pin)
- 1x R307 Fingerprint Sensor
- 1x ST7735S 1.8" TFT LCD (128x160, SPI)
- 1x Green LED (attendance OK)
- 1x Red LED (scan error)
- 1x Blue/White LED (device status - on/off)
- 3x 220 ohm Resistors (for LEDs)
- Jumper wires
- Breadboard (optional)

## Wiring Connections

```
  ┌───────────────────────────────────────────────────────────────────┐
  │                          ESP32 DevKit                             │
  │                                                                   │
  │   3V3 ──────────────────────────── R307 VCC (Red)                 │
  │   3V3 ──────────────────────────── ST7735S VCC                    │
  │   GND ──────────────────────────── R307 GND (Black)               │
  │   GND ──────────────────────────── ST7735S GND                    │
  │                                                                   │
  │   ── R307 Fingerprint (UART2) ──                                  │
  │   GPIO16 (RX2) ────────────────── R307 TX  (Yellow)               │
  │   GPIO17 (TX2) ────────────────── R307 RX  (Green)                │
  │                                                                   │
  │   ── ST7735S LCD (SPI) ──                                         │
  │   GPIO18 (SCLK) ──────────────── ST7735S SCL/CLK                  │
  │   GPIO23 (MOSI) ──────────────── ST7735S SDA/MOSI                 │
  │   GPIO5  (CS)   ──────────────── ST7735S CS                       │
  │   GPIO26 (DC)   ──────────────── ST7735S DC/A0                    │
  │   GPIO27 (RST)  ──────────────── ST7735S RST/RES                  │
  │   3V3 ─────────────────────────── ST7735S BLK (Backlight)         │
  │                                                                   │
  │   ── LEDs ──                                                      │
  │   GPIO2  ──── [220 ohm] ──── Green LED (+) ──── GND               │
  │   GPIO4  ──── [220 ohm] ──── Red LED   (+) ──── GND               │
  │   GPIO15 ──── [220 ohm] ──── Status LED(+) ──── GND               │
  │                                                                   │
  └───────────────────────────────────────────────────────────────────┘
```

## Pin Summary

| ESP32 Pin | Connected To              | Purpose                        |
|-----------|---------------------------|--------------------------------|
| 3V3       | R307 VCC, ST7735S VCC/BLK | Power for sensor and LCD       |
| GND       | R307 GND, ST7735S GND     | Common ground                  |
| GPIO16    | R307 TX (Yellow)          | Receive data from sensor       |
| GPIO17    | R307 RX (Green)           | Send commands to sensor        |
| GPIO18    | ST7735S SCL/CLK           | SPI clock                      |
| GPIO23    | ST7735S SDA/MOSI          | SPI data out                   |
| GPIO5     | ST7735S CS                | SPI chip select                |
| GPIO26    | ST7735S DC/A0             | Data/command select            |
| GPIO27    | ST7735S RST/RES           | LCD reset                      |
| GPIO2     | Green LED (+ anode)       | Blinks on successful scan      |
| GPIO4     | Red LED (+ anode)         | Blinks on scan error           |
| GPIO15    | Status LED (+ anode)      | Solid ON = connected           |

## R307 Fingerprint Sensor Pinout

```
  R307 Connector (6 pins, but only 4 used):

  ┌─────────────────────┐
  │  Pin 1 (Red)    VCC │ ──── ESP32 3V3
  │  Pin 2 (Black)  GND │ ──── ESP32 GND
  │  Pin 3 (Yellow) TX  │ ──── ESP32 GPIO16 (RX2)
  │  Pin 4 (Green)  RX  │ ──── ESP32 GPIO17 (TX2)
  │  Pin 5          NC  │     (not connected)
  │  Pin 6          NC  │     (not connected)
  └─────────────────────┘
```

## ST7735S 1.8" TFT LCD Pinout

```
  ST7735S Module (typical 8-pin header):

  ┌──────────────────────────┐
  │  GND  ───────── ESP32 GND    │
  │  VCC  ───────── ESP32 3V3    │
  │  SCL  ───────── ESP32 GPIO18 │  (SPI Clock)
  │  SDA  ───────── ESP32 GPIO23 │  (SPI MOSI)
  │  RES  ───────── ESP32 GPIO27 │  (Reset)
  │  DC   ───────── ESP32 GPIO26 │  (Data/Command)
  │  CS   ───────── ESP32 GPIO5  │  (Chip Select)
  │  BLK  ───────── ESP32 3V3    │  (Backlight, always on)
  └──────────────────────────┘
```

Note: Some ST7735S modules label pins differently:
- SCL may be labeled CLK or SCK
- SDA may be labeled DIN or MOSI
- RES may be labeled RST or RESET
- DC may be labeled A0 or RS
- BLK may be labeled LED or BL

## LED Circuit Detail

```
  ESP32 GPIOx ────[220 ohm]────|>|──── GND
                              LED
                         (longer leg = anode +)
                         (shorter leg = cathode -)
```

Each LED needs a 220 ohm current-limiting resistor between the ESP32 GPIO pin and the LED anode (longer leg). The cathode (shorter leg) connects to GND.

## LCD Display Layout

The ST7735S LCD shows real-time information:

```
  ┌─────────────────────────────┐
  │ BioTrack          WiFi OK   │  <- Header bar (blue bg)
  │─────────────────────────────│
  │                             │
  │   ATTENDANCE                │  <- Current mode (large text)
  │                             │
  │   Place finger to scan      │  <- Instructions
  │                             │
  │   Attendance OK!            │  <- Status messages (flash area)
  │─────────────────────────────│
  │ 14:23:05              ATT   │  <- Clock + mode indicator
  └─────────────────────────────┘
```

## LED Behavior

| LED           | Color        | Behavior                                          |
|---------------|--------------|---------------------------------------------------|
| Green (GPIO2) | Green        | Blinks when attendance is successfully recorded    |
| Red (GPIO4)   | Red          | Blinks when fingerprint not recognized or error    |
| Status (GPIO15)| Blue/White  | Solid ON = device connected and online             |
|               |              | OFF = device offline or WiFi disconnected          |

## Power Options

1. **USB Power**: Connect ESP32 via USB cable (easiest for development)
2. **External 5V**: Connect a 5V power supply to the VIN pin and GND
3. **Battery**: Use a 3.7V LiPo battery with a voltage regulator

Note: The ST7735S LCD and R307 sensor both run on 3.3V. Ensure your power supply can provide enough current (at least 500mA recommended).

## Required Arduino Libraries

Install these via the Arduino Library Manager:

1. `Adafruit Fingerprint Sensor Library` — for the R307 sensor
2. `Adafruit GFX Library` — graphics primitives for the LCD
3. `Adafruit ST7735 and ST7789 Library` — ST7735S driver

## Setup Steps

1. Wire all components as shown above
2. Install Arduino IDE and add ESP32 board support
3. Install the three libraries listed above from the Library Manager
4. Open `biotrack_esp32.ino`
5. Update the WiFi credentials, server URL, and API key
6. Adjust `GMT_OFFSET` and `DST_OFFSET` for your timezone
7. Select board: "ESP32 Dev Module"
8. Upload the sketch
9. Open Serial Monitor at 115200 baud to see debug output
10. The LCD should show the BioTrack splash screen on boot
