import { z } from 'zod';
import { 
  insertClassSchema, 
  insertStudentSchema, 
  insertDeviceSchema, 
  insertAttendanceSchema,
  insertUserRoleSchema,
  insertInvitationSchema,
  insertDepartmentSchema,
  classes,
  students,
  devices,
  attendance,
  userRoles,
  invitations,
  scannedFingerprints,
  departments,
} from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
  unauthorized: z.object({
    message: z.string(),
  }),
};

export const api = {
  // Classes
  classes: {
    list: {
      method: 'GET' as const,
      path: '/api/classes' as const,
      responses: {
        200: z.array(z.custom<typeof classes.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/classes' as const,
      input: insertClassSchema,
      responses: {
        201: z.custom<typeof classes.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    update: {
      method: 'PUT' as const,
      path: '/api/classes/:id' as const,
      input: insertClassSchema.partial(),
      responses: {
        200: z.custom<typeof classes.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/classes/:id' as const,
      responses: {
        204: z.void(),
        404: errorSchemas.notFound,
      },
    },
  },

  // Students
  students: {
    list: {
      method: 'GET' as const,
      path: '/api/students' as const,
      input: z.object({
        classId: z.coerce.number().optional(),
        search: z.string().optional(),
      }).optional(),
      responses: {
        200: z.array(z.custom<typeof students.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/students' as const,
      input: insertStudentSchema,
      responses: {
        201: z.custom<typeof students.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    update: {
      method: 'PUT' as const,
      path: '/api/students/:id' as const,
      input: insertStudentSchema.partial(),
      responses: {
        200: z.custom<typeof students.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/students/:id' as const,
      responses: {
        204: z.void(),
        404: errorSchemas.notFound,
      },
    },
  },

  // Devices
  devices: {
    list: {
      method: 'GET' as const,
      path: '/api/devices' as const,
      responses: {
        200: z.array(z.custom<typeof devices.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/devices' as const,
      input: insertDeviceSchema,
      responses: {
        201: z.custom<typeof devices.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    update: {
      method: 'PUT' as const,
      path: '/api/devices/:id' as const,
      input: insertDeviceSchema.partial(),
      responses: {
        200: z.custom<typeof devices.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/devices/:id' as const,
      responses: {
        204: z.void(),
        404: errorSchemas.notFound,
      },
    },
  },

  // Attendance
  attendance: {
    list: {
      method: 'GET' as const,
      path: '/api/attendance' as const,
      input: z.object({
        classId: z.coerce.number().optional(),
        date: z.string().optional(), // ISO date string
      }).optional(),
      responses: {
        200: z.array(z.custom<typeof attendance.$inferSelect & { student: typeof students.$inferSelect }>()),
      },
    },
    mark: {
      method: 'POST' as const,
      path: '/api/attendance/mark' as const,
      input: insertAttendanceSchema,
      responses: {
        201: z.custom<typeof attendance.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    bulkMark: {
      method: 'POST' as const,
      path: '/api/attendance/bulk' as const,
      input: z.object({
        classId: z.number(),
        date: z.string(),
        records: z.array(z.object({
          studentId: z.number(),
          status: z.enum(['present', 'absent', 'late', 'excused', 'leave']),
        })),
      }),
      responses: {
        200: z.object({ count: z.number() }),
      },
    },
    report: {
      method: 'GET' as const,
      path: '/api/attendance/report' as const,
      input: z.object({
        classId: z.coerce.number().optional(),
        startDate: z.string().optional(),
        endDate: z.string().optional(),
        status: z.string().optional(),
      }).optional(),
      responses: {
        200: z.array(z.custom<typeof attendance.$inferSelect & { student: typeof students.$inferSelect }>()),
      },
    },
    sync: {
      method: 'POST' as const,
      path: '/api/device/sync' as const,
      input: z.object({
        apiKey: z.string(),
        fingerprintId: z.number(),
        timestamp: z.string().optional(),
      }),
      responses: {
        200: z.object({ success: z.boolean(), message: z.string() }),
        401: errorSchemas.unauthorized,
        404: errorSchemas.notFound,
      },
    },
  },

  // Fingerprint Management
  fingerprints: {
    unassigned: {
      method: 'GET' as const,
      path: '/api/fingerprints/unassigned' as const,
      responses: {
        200: z.array(z.custom<typeof scannedFingerprints.$inferSelect & { device?: typeof devices.$inferSelect }>()),
      },
    },
    assign: {
      method: 'POST' as const,
      path: '/api/fingerprints/assign' as const,
      input: z.object({
        scannedFingerprintId: z.number(),
        studentId: z.number(),
      }),
      responses: {
        200: z.object({ success: z.boolean(), message: z.string() }),
        400: errorSchemas.validation,
        404: errorSchemas.notFound,
      },
    },
    dismiss: {
      method: 'DELETE' as const,
      path: '/api/fingerprints/:id' as const,
      responses: {
        204: z.void(),
      },
    },
  },

  // Departments
  departments: {
    list: {
      method: 'GET' as const,
      path: '/api/departments' as const,
      responses: {
        200: z.array(z.custom<typeof departments.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/departments' as const,
      input: insertDepartmentSchema,
      responses: {
        201: z.custom<typeof departments.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    update: {
      method: 'PUT' as const,
      path: '/api/departments/:id' as const,
      input: insertDepartmentSchema.partial(),
      responses: {
        200: z.custom<typeof departments.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/departments/:id' as const,
      responses: {
        204: z.void(),
        404: errorSchemas.notFound,
      },
    },
  },

  // User Management
  users: {
    list: {
      method: 'GET' as const,
      path: '/api/users' as const,
      responses: {
        200: z.array(z.object({
          id: z.string(),
          email: z.string().nullable(),
          firstName: z.string().nullable(),
          lastName: z.string().nullable(),
          role: z.string().nullable(),
        })),
      },
    },
    updateRole: {
      method: 'PUT' as const,
      path: '/api/users/:id/role' as const,
      input: z.object({ role: z.enum(['admin', 'manager', 'class_admin', 'viewer']) }),
      responses: {
        200: z.custom<typeof userRoles.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    invite: {
      method: 'POST' as const,
      path: '/api/users/invite' as const,
      input: insertInvitationSchema,
      responses: {
        201: z.custom<typeof invitations.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    listInvitations: {
      method: 'GET' as const,
      path: '/api/users/invitations' as const,
      responses: {
        200: z.array(z.custom<typeof invitations.$inferSelect>()),
      },
    },
    deleteRole: {
      method: 'DELETE' as const,
      path: '/api/users/:id/role' as const,
      responses: {
        204: z.void(),
        404: errorSchemas.notFound,
      },
    },
    deleteUser: {
      method: 'DELETE' as const,
      path: '/api/users/:id' as const,
      responses: {
        204: z.void(),
        404: errorSchemas.notFound,
      },
    },
    deleteInvitation: {
      method: 'DELETE' as const,
      path: '/api/users/invitations/:id' as const,
      responses: {
        204: z.void(),
        404: errorSchemas.notFound,
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
