import { pgTable, text, serial, integer, boolean, timestamp, time, varchar, date } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";
import { users } from "./models/auth";

export * from "./models/auth";

// Departments
export const departments = pgTable("departments", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description"),
  headOfDepartment: text("head_of_department"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertDepartmentSchema = createInsertSchema(departments).omit({ id: true, createdAt: true });
export type Department = typeof departments.$inferSelect;
export type InsertDepartment = z.infer<typeof insertDepartmentSchema>;

// Classes Management
export const classes = pgTable("classes", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  instructor: text("instructor"),
  scheduleType: text("schedule_type").notNull(), // 'morning' | 'evening'
  startTime: time("start_time").notNull(),
  endTime: time("end_time").notNull(),
  lateTime: time("late_time"),
  sessionStartDate: date("session_start_date"),
  sessionEndDate: date("session_end_date"),
  teacherId: varchar("teacher_id").references(() => users.id),
  departmentId: integer("department_id").references(() => departments.id),
  inviteCode: text("invite_code").unique(),
});

export const classesRelations = relations(classes, ({ one, many }) => ({
  students: many(students),
  teacher: one(users, {
    fields: [classes.teacherId],
    references: [users.id],
  }),
  department: one(departments, {
    fields: [classes.departmentId],
    references: [departments.id],
  }),
}));

export const insertClassSchema = createInsertSchema(classes).omit({ id: true });

// Students Management
export const students = pgTable("students", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  rollNumber: text("roll_number").unique().notNull(),
  fingerprintId: integer("fingerprint_id").unique(), // ID stored in R307
  classId: integer("class_id").references(() => classes.id),
  departmentId: integer("department_id").references(() => departments.id),
  userId: varchar("user_id").references(() => users.id),
  status: text("status").notNull().default("active"), // 'active' | 'pending' | 'rejected'
  createdAt: timestamp("created_at").defaultNow(),
});

export const studentsRelations = relations(students, ({ one, many }) => ({
  class: one(classes, {
    fields: [students.classId],
    references: [classes.id],
  }),
  department: one(departments, {
    fields: [students.departmentId],
    references: [departments.id],
  }),
  user: one(users, {
    fields: [students.userId],
    references: [users.id],
  }),
  attendance: many(attendance),
}));

export const insertStudentSchema = createInsertSchema(students).omit({ id: true, createdAt: true });

// Devices Management (ESP32)
export const devices = pgTable("devices", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  location: text("location"),
  apiKey: text("api_key").notNull().unique(),
  isActive: boolean("is_active").default(true),
  mode: text("mode").notNull().default("attendance"), // 'attendance' | 'enroll'
  departmentId: integer("department_id").references(() => departments.id),
  lastSeen: timestamp("last_seen"),
});

export const insertDeviceSchema = createInsertSchema(devices).omit({ id: true, lastSeen: true });

// Attendance Records
export const attendance = pgTable("attendance", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id").references(() => students.id).notNull(),
  classId: integer("class_id").references(() => classes.id), // Snapshot of class at time of attendance
  deviceId: integer("device_id").references(() => devices.id),
  date: timestamp("date").defaultNow(),
  status: text("status").notNull(), // 'present', 'absent', 'late', 'excused'
  markedBy: varchar("marked_by").references(() => users.id), // User ID if manual, null if device
});

export const attendanceRelations = relations(attendance, ({ one }) => ({
  student: one(students, {
    fields: [attendance.studentId],
    references: [students.id],
  }),
  class: one(classes, {
    fields: [attendance.classId],
    references: [classes.id],
  }),
  device: one(devices, {
    fields: [attendance.deviceId],
    references: [devices.id],
  }),
  marker: one(users, {
    fields: [attendance.markedBy],
    references: [users.id],
  }),
}));

export const insertAttendanceSchema = createInsertSchema(attendance).omit({ id: true, date: true });

// Scanned Fingerprints (from ESP32, not yet assigned to a student)
export const scannedFingerprints = pgTable("scanned_fingerprints", {
  id: serial("id").primaryKey(),
  fingerprintId: integer("fingerprint_id").notNull(),
  deviceId: integer("device_id").references(() => devices.id),
  scannedAt: timestamp("scanned_at").defaultNow(),
  assigned: boolean("assigned").default(false),
});

export const scannedFingerprintsRelations = relations(scannedFingerprints, ({ one }) => ({
  device: one(devices, {
    fields: [scannedFingerprints.deviceId],
    references: [devices.id],
  }),
}));

export const insertScannedFingerprintSchema = createInsertSchema(scannedFingerprints).omit({ id: true, scannedAt: true, assigned: true });

// User Roles / Access Management
export const userRoles = pgTable("user_roles", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id).unique().notNull(),
  role: text("role").notNull().default("viewer"), // 'admin', 'manager', 'class_admin', 'viewer'
  createdAt: timestamp("created_at").defaultNow(),
});

export const userRolesRelations = relations(userRoles, ({ one }) => ({
  user: one(users, {
    fields: [userRoles.userId],
    references: [users.id],
  }),
}));

export const insertUserRoleSchema = createInsertSchema(userRoles).omit({ id: true, createdAt: true });

// App Settings (key-value store for SMTP config etc.)
export const appSettings = pgTable("app_settings", {
  id: serial("id").primaryKey(),
  key: text("key").notNull().unique(),
  value: text("value").notNull(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertAppSettingSchema = createInsertSchema(appSettings).omit({ id: true, updatedAt: true });

// Pending Email Verifications (OTP)
export const pendingVerifications = pgTable("pending_verifications", {
  id: serial("id").primaryKey(),
  email: text("email").notNull(),
  code: text("code").notNull(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  hashedPassword: text("hashed_password").notNull(),
  classId: integer("class_id"),
  rollNumber: text("roll_number"),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Password Resets (OTP)
export const passwordResets = pgTable("password_resets", {
  id: serial("id").primaryKey(),
  email: text("email").notNull(),
  code: text("code").notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// User Invitations
export const invitations = pgTable("invitations", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  role: text("role").notNull().default("viewer"),
  invitedBy: varchar("invited_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  expiresAt: timestamp("expires_at"),
});

export const insertInvitationSchema = createInsertSchema(invitations).omit({ id: true, createdAt: true });

// Types
export type Class = typeof classes.$inferSelect;
export type InsertClass = z.infer<typeof insertClassSchema>;

export type Student = typeof students.$inferSelect;
export type InsertStudent = z.infer<typeof insertStudentSchema>;

export type Device = typeof devices.$inferSelect;
export type InsertDevice = z.infer<typeof insertDeviceSchema>;

export type Attendance = typeof attendance.$inferSelect;
export type InsertAttendance = z.infer<typeof insertAttendanceSchema>;

export type UserRole = typeof userRoles.$inferSelect;
export type InsertUserRole = z.infer<typeof insertUserRoleSchema>;

export type Invitation = typeof invitations.$inferSelect;
export type InsertInvitation = z.infer<typeof insertInvitationSchema>;

export type ScannedFingerprint = typeof scannedFingerprints.$inferSelect;
export type InsertScannedFingerprint = z.infer<typeof insertScannedFingerprintSchema>;

export type AppSetting = typeof appSettings.$inferSelect;
export type InsertAppSetting = z.infer<typeof insertAppSettingSchema>;
